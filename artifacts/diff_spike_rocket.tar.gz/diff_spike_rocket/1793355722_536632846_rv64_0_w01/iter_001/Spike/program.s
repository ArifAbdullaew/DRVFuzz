# 0 "/home/fuzz/runs/diff_spike_rocket/1793355722_536632846_rv64_0_w01/iter_001/Spike/program.S"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/home/fuzz/runs/diff_spike_rocket/1793355722_536632846_rv64_0_w01/iter_001/Spike/program.S"
    .section .text
    .globl _start

_start:
    la t0, trap_handler
    csrw mtvec, t0

    csrr t0, mstatus
    li t1, 0x00003000 # set FS field to Dirty (0b11) so FP regs usable
    or t0, t0, t1
    csrw mstatus, t0
    csrw fcsr, x0 # clear floating-point status

    # Relax PMP: one NAPOT entry covers the full address space to allow S-mode fetch/load/store
    li t0, -1
    csrw pmpaddr0, t0
    li t0, 0x1f # R|W|X | A=NAPOT
    csrw pmpcfg0, t0

    j user_code

user_code:
li x13, 0xa285ccceb095c6fc
li x14, 0x2d3d18b0366fecf
li x15, 0x170e5d6e15a68509
li x16, 0x91437414c565d2b5
li x17, 0x21429bab57c04895
li x18, 0x664734ed9cda4caa
li x19, 0x20448cc96180742d
li x20, 0xbe24bfb0b2429766
li x8, 0x17d8bcca4ef81617
fmv.d.x f13, x8
li x8, 0xd8f6a57b17ff774d
fmv.d.x f14, x8
li x8, 0x705aa753a677abb6
fmv.d.x f15, x8
li x8, 0x8628d9c280d311a4
fmv.d.x f16, x8
li x8, 0xb5587366f83830e9
fmv.d.x f17, x8
li x8, 0x75994ad3001b667d
fmv.d.x f18, x8
li x8, 0xb7265d83e803edf1
fmv.d.x f19, x8
li x8, 0x136c403c70877be0
fmv.d.x f20, x8
li x9, 0x8fffffb8
li x10, 0xaf38d14e58c35ff7
sd x10, 0(x9)
li x10, 0x41502daa3f81fe2e
sd x10, 8(x9)
li x10, 0x3f21b06057129f52
sd x10, 16(x9)
li x10, 0xbf0698c7db908f1c
sd x10, 24(x9)
li x10, 0xe2c964174324f917
sd x10, 32(x9)
li x10, 0xa926162ddc6099ba
sd x10, 40(x9)
li x10, 0xb8298c8919e952b1
sd x10, 48(x9)
li x10, 0xdf121df725f20b31
sd x10, 56(x9)
li x8, 0
li x9, 0
li x10, 0
li x11, 0
li x12, 0
srlw x14, x19, x17
slli x19, x13, 15
fcvt.w.d x20, f15, rup
csrrs x16, fflags, x0
slli.uw x18, x15, 43
csrrs x16, fflags, x0
subw x15, x20, x18
fcvt.s.w f17, x20, rne
csrrs x16, fflags, x0
li x12, 2415919050
c.sd x15, 8(x12)
li x11, 2415919062
fsw f15, 14(x11)
csrrs x20, fflags, x0
fsgnjn.h f15, f15, f13
csrrs x13, fflags, x0
fnmsub.h f20, f13, f19, f20, rtz
csrrs x17, fflags, x0
bext x15, x15, x15
fcvt.h.s f14, f16, rdn
csrrs x19, fflags, x0
fcvt.s.wu f13, x20, rtz
csrrs x14, fflags, x0
xor x18, x16, x20
fsub.s f15, f17, f17, rup
csrrs x16, fflags, x0
slt x19, x20, x13
min x20, x19, x14
c.andi x15, -2
fcvt.s.d f19, f20, rne
csrrs x15, fflags, x0
fcvt.h.w f19, x20, rmm
csrrs x15, fflags, x0
fcvt.s.h f19, f19
csrrs x19, fflags, x0
fcvt.w.d x14, f18, rtz
csrrs x16, fflags, x0
sh3add.uw x13, x17, x17
sra x16, x15, x15
add.uw x17, x13, x19
fmax.s f17, f14, f16
csrrs x16, fflags, x0
fmul.d f20, f13, f15, rne
csrrs x20, fflags, x0
bseti x14, x16, 0
sh1add x15, x19, x16
li x12, 2415919032
amominu.d x14, x15, (x12)
binvi x20, x18, 19
c.addiw x19, -9
fcvt.h.lu f13, x15, rdn
csrrs x16, fflags, x0
binvi x18, x16, 17
slliw x20, x20, 12
fsub.h f14, f15, f15, dyn
csrrs x16, fflags, x0
li x11, 2415919049
sd x17, 12(x11)
li x11, 2415919064
amoadd.w.rl x14, x20, (x11)
remuw x18, x20, x20
fnmadd.h f20, f16, f19, f17, rmm
csrrs x20, fflags, x0
li x8, 2415919067
amoand.w.aqrl x20, x19, (x8)
c.ebreak
fcvt.d.lu f13, x15, rtz
csrrs x19, fflags, x0
li x11, 2415919047
lbu x15, 12(x11)
csrrs x16, fflags, x0
divuw x14, x17, x20
sext.b x20, x18
remw x20, x18, x14
slli x14, x17, 6
fnmadd.h f13, f19, f19, f19, rmm
csrrs x16, fflags, x0
csrrs x15, fflags, x0
c.and x15, x15
fsgnjx.s f19, f14, f14
csrrs x14, fflags, x0
li x2, 2415919041
c.sdsp x15, 8(sp)
remu x16, x15, x13
fence.i
li x12, 2415919057
lbu x17, 7(x12)
fcvt.wu.s x19, f19, dyn
csrrs x19, fflags, x0
fcvt.l.h x14, f14, rup
csrrs x19, fflags, x0
binv x17, x18, x20
fmv.w.x f15, x15
csrrs x19, fflags, x0
fmin.s f19, f20, f13
csrrs x16, fflags, x0
fcvt.s.h f14, f13
csrrs x19, fflags, x0
fcvt.w.h x15, f17, rtz
csrrs x19, fflags, x0
csrrs x14, fflags, x0
fcvt.d.h f20, f19
csrrs x20, fflags, x0
srli x20, x14, 29
csrrs x17, fflags, x0
fcvt.s.w f15, x17, rne
csrrs x17, fflags, x0
fcvt.wu.s x17, f17, dyn
csrrs x20, fflags, x0
fcvt.d.wu f14, x13
csrrs x19, fflags, x0
li x9, 2415919056
flh f19, 12(x9)
csrrs x15, fflags, x0
csrrs x20, fflags, x0
li x9, 2415919056
fld f13, 12(x9)
csrrs x15, fflags, x0
li x10, 2415919038
amoand.d x13, x18, (x10)
addi x15, x19, 1326
fsub.s f15, f13, f15, rup
csrrs x19, fflags, x0
c.sub x15, x14
li x9, 2415919053
c.ld x15, 16(x9)
fcvt.h.lu f15, x19, rdn
csrrs x17, fflags, x0
fmv.x.w x20, f17
csrrs x20, fflags, x0
sll x18, x20, x20
fsgnjx.d f15, f13, f15
csrrs x15, fflags, x0
csrrs x17, fflags, x0
fcvt.w.h x13, f13, rne
csrrs x13, fflags, x0
divw x14, x15, x16
fcvt.d.lu f16, x20, rne
csrrs x16, fflags, x0
fmadd.s f14, f18, f16, f14, rup
csrrs x18, fflags, x0
sh1add x19, x13, x16
flt.d x15, f16, f16
csrrs x13, fflags, x0
sh2add x19, x13, x16
li x11, 2415919068
amoadd.d.aqrl x19, x15, (x11)
slti x20, x13, 1664
c.subw x14, x14
remw x16, x14, x20
andi x18, x20, 618
fcvt.wu.s x14, f15, rtz
csrrs x19, fflags, x0
fence w, iow
fsqrt.d f15, f20, dyn
csrrs x16, fflags, x0
divu x13, x14, x19
c.slli x16, 55
csrrs x14, fflags, x0
c.li x18, 12
li x10, 2415919052
amomin.w.aqrl x20, x15, (x10)
fcvt.s.d f14, f14, rmm
csrrs x20, fflags, x0
li x10, 2415919072
amomin.w.aqrl x18, x13, (x10)
sraiw x19, x16, 0
czero.eqz x17, x17, x18
fsub.h f15, f16, f20, rtz
csrrs x19, fflags, x0
li x9, 2415919056
lhu x19, 16(x9)
fmsub.d f15, f15, f20, f14, rmm
csrrs x16, fflags, x0
cpop x17, x17
li x2, 2415919063
c.ldsp x15, 16(sp)
divu x15, x13, x15
add.uw x13, x17, x14
remw x20, x16, x16
li x12, 2415919055
lh x20, 8(x12)
bclr x16, x17, x15
and x16, x13, x19
li x2, 2415919042
c.lwsp x14, 8(sp)
divuw x19, x19, x14
csrrs x20, fflags, x0
fcvt.l.h x16, f15, dyn
csrrs x14, fflags, x0
czero.eqz x16, x18, x19
slti x13, x14, 1173
orc.b x15, x15
addiw x17, x20, -949
bclri x13, x16, 25
c.nop
li x8, 2415919040
sw x15, 11(x8)
csrrs x19, fflags, x0
fcvt.w.s x20, f14, rdn
csrrs x14, fflags, x0
fcvt.h.l f19, x17, rdn
csrrs x14, fflags, x0
flt.s x13, f19, f15
csrrs x17, fflags, x0
fcvt.w.h x19, f19, rmm
csrrs x20, fflags, x0
rem x15, x15, x20
fcvt.wu.h x15, f19, rne
csrrs x13, fflags, x0
fcvt.h.w f13, x16, dyn
csrrs x18, fflags, x0
fcvt.h.l f20, x14, rmm
csrrs x15, fflags, x0
li x2, 2415919070
c.lwsp x20, 8(sp)
remw x17, x20, x13
li x10, 2415919061
lh x20, 7(x10)
csrrs x20, fflags, x0
orc.b x14, x17
li x12, 2415919069
amoswap.d.aqrl x13, x18, (x12)
fmin.d f17, f20, f18
csrrs x18, fflags, x0
clz x13, x20
fcvt.lu.s x15, f17, rdn
csrrs x17, fflags, x0
bseti x19, x20, 29
csrrs x18, fflags, x0
sh1add x19, x15, x13
li x10, 2415919065
lbu x18, 5(x10)
fdiv.d f13, f16, f17, dyn
csrrs x16, fflags, x0
divw x18, x17, x16
fsgnjx.h f19, f20, f15
csrrs x16, fflags, x0
fmv.x.w x19, f15
csrrs x14, fflags, x0
fence.tso
ctz x14, x20
czero.eqz x13, x17, x13
fcvt.h.wu f14, x17, rne
csrrs x15, fflags, x0
fcvt.h.wu f18, x18, rup
csrrs x15, fflags, x0
fmul.d f15, f18, f16, rne
csrrs x15, fflags, x0
csrrs x15, fflags, x0
csrrs x19, fflags, x0
sh1add x18, x20, x19
c.sub x14, x13
fsgnjn.s f20, f14, f20
csrrs x13, fflags, x0
sllw x15, x14, x17
fcvt.wu.h x20, f17, dyn
csrrs x17, fflags, x0
csrrsi x18, fcsr, 0
c.ebreak
sh1add.uw x16, x14, x14
max x18, x20, x19
divu x14, x14, x20
li x10, 2415919055
lb x14, 7(x10)
fcvt.h.lu f14, x17, rne
csrrs x20, fflags, x0
li x12, 2415919057
amoor.w.aqrl x19, x19, (x12)
bext x16, x16, x18
fence.i
fcvt.wu.h x18, f16, rtz
csrrs x20, fflags, x0
csrrs x15, fflags, x0
li x9, 2415919067
amoadd.d x19, x19, (x9)
fsgnjn.h f14, f20, f13
csrrs x20, fflags, x0
li x9, 2415919067
amomin.d.aqrl x19, x18, (x9)
fmax.s f14, f17, f18
csrrs x17, fflags, x0
slt x20, x15, x16
li x2, 2415919037
c.swsp x16, 0(sp)
fsqrt.s f18, f17, rne
csrrs x14, fflags, x0
li x2, 2415919062
c.lwsp x18, 12(sp)
fmadd.h f14, f15, f13, f19, dyn
csrrs x16, fflags, x0
csrrs x15, fflags, x0
fcvt.w.s x15, f18, rup
csrrs x14, fflags, x0
fcvt.w.s x17, f19, dyn
csrrs x16, fflags, x0
fcvt.h.d f16, f15, dyn
csrrs x15, fflags, x0
li x12, 2415919055
amomin.d x18, x13, (x12)
fmul.d f13, f19, f19, rne
csrrs x20, fflags, x0
fmin.d f15, f13, f14
csrrs x20, fflags, x0
sll x19, x14, x15
zext.h x19, x15
bexti x15, x13, 6
c.srli x13, 57
fcvt.s.lu f17, x20, rup
csrrs x13, fflags, x0
fsub.d f13, f19, f16, dyn
csrrs x20, fflags, x0
fdiv.d f16, f14, f14, dyn
csrrs x19, fflags, x0
li x10, 2415919053
lh x14, 3(x10)
mulhsu x20, x20, x16
zext.h x13, x20
li x11, 2415919039
amoor.w.aq x19, x19, (x11)
csrrs x17, fflags, x0
sext.h x17, x19
li x8, 2415919055
amoadd.w x18, x16, (x8)
fcvt.wu.h x13, f13, dyn
csrrs x14, fflags, x0
csrrs x16, fflags, x0
c.srli x14, 9
fcvt.d.s f13, f16
csrrs x15, fflags, x0
max x18, x13, x17
li x8, 2415919068
amomin.w x15, x14, (x8)
fence.i
c.mv x17, x14
fmsub.d f16, f13, f14, f16, rne
csrrs x20, fflags, x0
li x2, 2415919069
c.ldsp x16, 0(sp)
orc.b x18, x15
srli x19, x19, 23
li x12, 2415919061
ld x16, 8(x12)
feq.d x15, f13, f15
csrrs x13, fflags, x0
fle.s x13, f15, f15
csrrs x19, fflags, x0
fmin.d f17, f16, f15
csrrs x15, fflags, x0
slt x17, x14, x14
fle.h x19, f13, f13
csrrs x16, fflags, x0
remu x13, x17, x20
li x17, -9223372036854775791
csrrc x19, mcause, x17
fle.h x18, f16, f14
csrrs x16, fflags, x0
csrrs x14, fflags, x0
fcvt.lu.s x13, f18, rmm
csrrs x14, fflags, x0
fence.i
sh3add x14, x14, x13
srlw x18, x15, x19
bclr x18, x14, x16
fmadd.s f13, f14, f18, f20, rmm
csrrs x14, fflags, x0
fnmadd.s f16, f19, f13, f17, rmm
csrrs x13, fflags, x0
csrrs x19, fflags, x0
li x8, 2415919069
amomax.d.rl x13, x16, (x8)
li x2, 2415919066
c.lwsp x15, 12(sp)
fnmadd.s f16, f20, f18, f14, rdn
csrrs x14, fflags, x0
fcvt.l.d x19, f18, rmm
csrrs x15, fflags, x0
fmsub.d f15, f20, f15, f18, dyn
csrrs x13, fflags, x0
li x8, 2415919066
amoswap.d.aq x14, x18, (x8)
csrrs x15, fflags, x0
fcvt.h.wu f14, x17, rne
csrrs x17, fflags, x0
fcvt.lu.d x20, f20, rmm
csrrs x20, fflags, x0
fclass.s x20, f18
csrrs x20, fflags, x0
fmax.s f19, f18, f18
csrrs x14, fflags, x0
li x9, 2415919055
fsh f19, 10(x9)
csrrs x13, fflags, x0
fdiv.h f17, f20, f17, dyn
csrrs x13, fflags, x0
fmin.s f14, f13, f17
csrrs x13, fflags, x0
fmadd.d f17, f18, f16, f16, dyn
csrrs x19, fflags, x0
fence.i
li x9, 2415919066
lw x18, 7(x9)
fence.i
li x14, 10
csrrw x16, mcause, x14
fsgnjn.h f14, f19, f18
csrrs x20, fflags, x0
divw x18, x14, x14
c.nop
li x8, 2415919069
amoswap.d x20, x18, (x8)
fadd.d f19, f18, f19, rmm
csrrs x19, fflags, x0
li x2, 2415919034
c.swsp x19, 8(sp)
fcvt.wu.d x20, f20, rtz
csrrs x14, fflags, x0
li x8, 2415919062
amominu.d.rl x15, x19, (x8)
csrrs x19, fflags, x0
fclass.d x14, f19
csrrs x14, fflags, x0
fmv.d.x f15, x13
csrrs x15, fflags, x0
li x8, 2415919064
c.lw x15, 8(x8)
bseti x20, x15, 19
sraw x17, x19, x20
csrrs x13, fflags, x0
sh2add x19, x18, x16
czero.eqz x13, x17, x19
remu x14, x15, x19
fle.d x14, f20, f17
csrrs x20, fflags, x0
fsqrt.d f15, f15, rup
csrrs x14, fflags, x0
li x9, 2415919072
amoand.w.rl x14, x20, (x9)
addi x18, x14, 1053
sh3add.uw x17, x16, x15
c.addw x15, x13
remuw x16, x15, x19
fcvt.d.s f18, f14
csrrs x19, fflags, x0
fcvt.h.s f15, f13, dyn
csrrs x15, fflags, x0
c.xor x13, x14
li x8, 2415919054
amoor.d.rl x17, x20, (x8)
flt.s x13, f13, f20
csrrs x15, fflags, x0
fsqrt.d f15, f18, rtz
csrrs x13, fflags, x0
c.xor x14, x13
c.li x19, 9
li x10, 2415919058
amoand.d.aq x14, x15, (x10)
fence.i
fcvt.d.s f14, f18
csrrs x16, fflags, x0
flt.d x17, f16, f14
csrrs x15, fflags, x0
fnmadd.d f13, f14, f18, f13, rtz
csrrs x13, fflags, x0
cpop x17, x19
fcvt.d.w f18, x15
csrrs x20, fflags, x0
li x12, 2415919052
amominu.d.aq x18, x15, (x12)
li x8, 2415919058
amoand.d.rl x18, x19, (x8)
maxu x17, x17, x15
c.addi16sp sp, 16
csrrs x14, fflags, x0
fcvt.s.l f16, x17, dyn
csrrs x18, fflags, x0
fnmsub.h f19, f19, f19, f13, dyn
csrrs x17, fflags, x0
fmv.h.x f16, x14
csrrs x14, fflags, x0
fnmsub.d f17, f16, f13, f20, dyn
csrrs x20, fflags, x0
bclr x20, x19, x13
c.andi x14, 18
li x8, 2415919033
amomax.w.rl x19, x15, (x8)
fence rw, i
csrrs x15, fflags, x0
cpopw x18, x14
czero.nez x17, x13, x13
li x9, 2415919039
lbu x18, 12(x9)
fmv.w.x f18, x15
csrrs x13, fflags, x0
csrrs x16, fflags, x0
flt.h x15, f19, f15
csrrs x19, fflags, x0
li x8, 2415919065
flh f19, 15(x8)
csrrs x14, fflags, x0
csrrs x16, fflags, x0
li x9, 2415919072
flh f16, 1(x9)
csrrs x13, fflags, x0
li x2, 2415919034
c.sdsp x20, 0(sp)
fmin.d f17, f13, f18
csrrs x15, fflags, x0
fmsub.s f14, f19, f14, f17, dyn
csrrs x16, fflags, x0
fsgnj.s f20, f19, f16
csrrs x18, fflags, x0
fsub.h f14, f20, f13, rtz
csrrs x14, fflags, x0
fsgnj.s f15, f14, f14
csrrs x13, fflags, x0
remw x16, x15, x14
sra x16, x14, x18
li x2, 2415919048
c.lwsp x15, 16(sp)
li x11, 2415919038
c.sw x13, 12(x11)
bclr x19, x14, x19
li x9, 2415919038
amoadd.w.aqrl x13, x14, (x9)
fmax.h f14, f20, f19
csrrs x17, fflags, x0
fcvt.l.h x19, f19, rne
csrrs x18, fflags, x0
czero.eqz x14, x20, x20
li x8, 2415919059
amoswap.w.rl x17, x19, (x8)
fcvt.lu.h x14, f18, rtz
csrrs x13, fflags, x0
csrrs x19, fflags, x0
fmadd.s f20, f16, f18, f20, dyn
csrrs x15, fflags, x0
fsgnjn.s f19, f13, f15
csrrs x20, fflags, x0
fence.i
fcvt.h.wu f18, x13, dyn
csrrs x18, fflags, x0
fcvt.d.lu f20, x16, rmm
csrrs x17, fflags, x0
srl x19, x15, x19
slt x16, x20, x17
binvi x19, x20, 53
fcvt.w.d x20, f18, dyn
csrrs x16, fflags, x0
li x11, 2415919047
amomaxu.w x13, x13, (x11)
csrrs x13, fflags, x0
fcvt.h.d f16, f14, dyn
csrrs x18, fflags, x0
csrrwi x16, cycle, 16
fmax.s f19, f13, f19
csrrs x20, fflags, x0
fcvt.h.lu f19, x17, rtz
csrrs x20, fflags, x0
csrrs x14, fflags, x0
fsqrt.d f20, f14, rup
csrrs x14, fflags, x0
li x11, 2415919035
lh x19, 9(x11)
fle.d x20, f15, f18
csrrs x14, fflags, x0
addi x19, x17, -56
czero.nez x17, x16, x16
li x8, 2415919044
fsd f19, 10(x8)
csrrs x13, fflags, x0
czero.nez x17, x20, x19
fcvt.lu.d x13, f14, rup
csrrs x14, fflags, x0
csrrs x16, fflags, x0
fsgnj.d f19, f18, f20
csrrs x18, fflags, x0
csrrs x18, fflags, x0
csrrs x13, fflags, x0
srl x16, x15, x17
srl x20, x16, x16
csrrs x16, fflags, x0
fmadd.s f18, f16, f19, f14, rne
csrrs x13, fflags, x0
clzw x19, x13
li x12, 2415919047
lw x19, 16(x12)
c.xor x13, x13
andi x19, x14, -1446
czero.nez x18, x13, x17
fsgnjn.s f13, f20, f20
csrrs x20, fflags, x0
csrrs x15, fflags, x0
fclass.d x13, f15
csrrs x19, fflags, x0
li x11, 2415919041
amoand.d.aq x16, x19, (x11)
divw x14, x17, x17
c.andi x15, -7
li x10, 2415919058
lh x17, 9(x10)
czero.nez x17, x14, x17
bexti x15, x14, 53
fcvt.s.w f13, x16, rmm
csrrs x17, fflags, x0
csrrs x14, fflags, x0
li x11, 2415919053
amomin.w.rl x14, x20, (x11)
li x8, 2415919066
ld x18, 4(x8)
fmin.d f20, f14, f19
csrrs x14, fflags, x0
fcvt.w.s x15, f13, dyn
csrrs x14, fflags, x0
li x10, 2415919071
lwu x13, 9(x10)
slli x16, x18, 62
czero.nez x15, x17, x13
fnmadd.h f13, f14, f19, f17, dyn
csrrs x14, fflags, x0
li x12, 2415919067
c.sw x15, 12(x12)
csrrs x18, fflags, x0
czero.eqz x13, x19, x16
li x11, 2415919053
fsd f13, 1(x11)
csrrs x13, fflags, x0
clz x15, x19
c.and x13, x14
rem x20, x13, x18
fcvt.d.l f18, x19, rdn
csrrs x16, fflags, x0
fmadd.h f14, f20, f17, f15, rne
csrrs x18, fflags, x0
c.li x14, -5
addiw x18, x17, -464
c.addi16sp sp, 16
li x11, 2415919057
lbu x17, 10(x11)
li x9, 2415919040
lhu x17, 16(x9)
fmsub.h f13, f15, f19, f13, dyn
csrrs x20, fflags, x0
li x9, 2415919058
amominu.w x16, x17, (x9)
fadd.h f13, f18, f15, rup
csrrs x16, fflags, x0
srliw x19, x20, 24
li x8, 2415919037
amoadd.d.rl x19, x19, (x8)
csrrs x15, fflags, x0
li x9, 2415919061
lhu x18, 8(x9)
feq.h x20, f15, f18
csrrs x19, fflags, x0
li x11, 2415919037
fsd f15, 4(x11)
csrrs x20, fflags, x0
li x11, 2415919053
amoxor.w.rl x15, x18, (x11)
li x11, 2415919032
lb x16, 16(x11)
c.addiw x20, 6
li x11, 2415919052
amominu.w x15, x16, (x11)
c.subw x15, x15
zext.h x13, x15
fsqrt.s f13, f17, rne
csrrs x19, fflags, x0
li x8, 2415919041
c.ld x14, 0(x8)
fsgnj.d f13, f15, f14
csrrs x17, fflags, x0
slliw x17, x14, 16
binv x16, x20, x13
orc.b x16, x14
fence.i
srlw x15, x13, x18
csrrs x13, fflags, x0
srlw x13, x19, x19
fmv.x.d x18, f18
csrrs x16, fflags, x0
fcvt.s.h f16, f19
csrrs x20, fflags, x0
fsgnjx.d f20, f17, f18
csrrs x16, fflags, x0
fcvt.h.l f18, x16, rdn
csrrs x20, fflags, x0
csrrs x14, fflags, x0
li x10, 2415919045
amomaxu.w.aq x15, x17, (x10)
slliw x13, x15, 30
li x11, 2415919043
amoxor.d x20, x19, (x11)
fcvt.w.d x18, f20, rdn
csrrs x16, fflags, x0
c.subw x13, x15
fcvt.s.l f18, x15, dyn
csrrs x15, fflags, x0
c.sub x13, x13
fle.d x20, f19, f19
csrrs x16, fflags, x0
ctz x14, x14
sltu x18, x17, x13
fclass.s x20, f18
csrrs x14, fflags, x0
li x17, 49
csrrs x19, fcsr, x17
li x11, 2415919032
amoor.w x17, x19, (x11)
li x14, -843205444096419634
csrrs x13, cycle, x14
minu x20, x17, x15
fsub.d f19, f14, f18, dyn
csrrs x18, fflags, x0
fcvt.h.w f16, x14, rne
csrrs x18, fflags, x0
fmin.s f13, f19, f20
csrrs x14, fflags, x0
add.uw x17, x14, x20
fsgnj.h f19, f13, f19
csrrs x13, fflags, x0
csrrs x14, fflags, x0
addw x18, x17, x20
sext.b x20, x15
fdiv.s f13, f18, f16, rup
csrrs x15, fflags, x0
csrrs x14, fflags, x0
feq.s x14, f16, f14
csrrs x20, fflags, x0
fcvt.h.lu f17, x13, dyn
csrrs x17, fflags, x0
fcvt.d.l f18, x13, rne
csrrs x15, fflags, x0
fcvt.h.w f13, x16, rdn
csrrs x15, fflags, x0
fcvt.s.l f17, x16, rup
csrrs x20, fflags, x0
fsqrt.h f20, f20, dyn
csrrs x18, fflags, x0
fcvt.wu.d x20, f14, dyn
csrrs x20, fflags, x0
slliw x13, x20, 22
fcvt.lu.s x18, f18, dyn
csrrs x14, fflags, x0
fence.i
fcvt.w.s x20, f19, rne
csrrs x19, fflags, x0
remuw x20, x17, x15
c.nop
csrrs x20, fflags, x0
fmax.s f14, f18, f20
csrrs x13, fflags, x0
li x8, 2415919057
amomax.d.aqrl x18, x19, (x8)
remuw x15, x16, x17
subw x17, x19, x20
sh3add.uw x20, x18, x19
fle.h x18, f14, f14
csrrs x13, fflags, x0
c.slli x16, 1
fmax.d f13, f19, f17
csrrs x15, fflags, x0
fnmsub.d f15, f16, f16, f19, rtz
csrrs x15, fflags, x0
csrrs x19, fflags, x0
sh1add.uw x15, x17, x16
li x9, 2415919046
amomax.w.rl x19, x19, (x9)
li x11, 2415919059
lwu x18, 5(x11)
fcvt.h.lu f13, x17, rtz
csrrs x15, fflags, x0
csrrs x15, fflags, x0
fmax.d f18, f18, f17
csrrs x17, fflags, x0
c.and x13, x15
fmsub.h f14, f13, f15, f19, rmm
csrrs x16, fflags, x0
min x20, x20, x17
fmin.s f16, f19, f17
csrrs x18, fflags, x0
li x8, 2415919041
sh x19, 6(x8)
sext.h x17, x13
feq.d x18, f19, f13
csrrs x15, fflags, x0
slt x16, x14, x15
fcvt.s.w f15, x17, rmm
csrrs x14, fflags, x0
fmul.d f20, f14, f19, rtz
csrrs x16, fflags, x0
csrrs x13, fflags, x0
c.srli x15, 43
li x12, 2415919055
lhu x16, 10(x12)
fnmadd.d f18, f17, f17, f18, rmm
csrrs x20, fflags, x0
remu x15, x13, x20
addw x19, x18, x17
srl x18, x20, x20
fcvt.lu.d x17, f17, dyn
csrrs x14, fflags, x0
addw x20, x18, x18
srli x14, x16, 21
orc.b x17, x13
c.srli x15, 8
fsub.s f19, f16, f15, dyn
csrrs x18, fflags, x0
srlw x19, x19, x18
c.subw x13, x15
c.srli x15, 56
fdiv.d f19, f20, f20, rmm
csrrs x13, fflags, x0
c.add x18, x15
fmv.x.d x13, f18
csrrs x13, fflags, x0
xor x16, x14, x17
fmax.d f18, f15, f19
csrrs x15, fflags, x0
li x18, -7034454017453905412
csrrs x18, dscratch0, x18
fsub.s f16, f20, f19, rup
csrrs x18, fflags, x0
fle.s x19, f16, f20
csrrs x16, fflags, x0
fmin.h f19, f14, f17
csrrs x18, fflags, x0
sh1add x19, x17, x19
fsub.h f16, f16, f14, dyn
csrrs x13, fflags, x0
li x2, 2415919050
c.swsp x15, 0(sp)
czero.nez x14, x16, x18
clz x16, x17
czero.eqz x20, x15, x17
bset x13, x16, x14
fence.i
fsub.d f16, f16, f18, rmm
csrrs x17, fflags, x0
li x8, 2415919047
fsd f14, 15(x8)
csrrs x20, fflags, x0
csrrs x15, fflags, x0
fcvt.s.lu f15, x16, rtz
csrrs x18, fflags, x0
li x12, 2415919040
sd x14, 6(x12)
slt x16, x16, x17
czero.eqz x20, x13, x19
fmsub.d f17, f18, f18, f19, dyn
csrrs x16, fflags, x0
fnmadd.h f15, f13, f19, f16, rne
csrrs x16, fflags, x0
fence.i
fadd.s f16, f13, f20, dyn
csrrs x13, fflags, x0
fnmsub.h f13, f17, f14, f15, rmm
csrrs x19, fflags, x0
fle.s x13, f17, f20
csrrs x15, fflags, x0
fclass.d x15, f16
csrrs x17, fflags, x0
li x9, 2415919051
amomaxu.d.rl x19, x13, (x9)
c.slli x20, 39
mulhsu x14, x16, x16
li x9, 2415919063
amoxor.d.aq x18, x18, (x9)
srai x20, x16, 23
csrrs x17, fflags, x0
fcvt.d.h f14, f14
csrrs x15, fflags, x0
li x10, 2415919052
amomaxu.d.aq x18, x17, (x10)
slt x16, x20, x18
li x8, 2415919048
flh f15, 9(x8)
csrrs x17, fflags, x0
li x8, 2415919049
lh x18, 5(x8)
fsgnjx.s f20, f14, f14
csrrs x14, fflags, x0
fclass.h x17, f19
csrrs x14, fflags, x0
div x19, x15, x19
srl x16, x13, x15
sra x13, x15, x17
fsgnjx.s f18, f17, f20
csrrs x15, fflags, x0
c.srai x13, 12
fmsub.h f13, f14, f14, f16, dyn
csrrs x15, fflags, x0
fsgnjx.d f14, f16, f13
csrrs x14, fflags, x0
fcvt.s.l f16, x16, rtz
csrrs x17, fflags, x0
fcvt.l.s x16, f19, dyn
csrrs x15, fflags, x0
bclri x16, x19, 44
c.lui x16, 0xffff3
fnmadd.s f19, f19, f15, f18, dyn
csrrs x20, fflags, x0
li x9, 2415919070
amomaxu.w x19, x16, (x9)
sub x16, x18, x19
bseti x16, x17, 45
csrrs x18, fflags, x0
addiw x18, x14, 1694
fcvt.wu.h x14, f13, rup
csrrs x13, fflags, x0
czero.nez x15, x14, x13
li x10, 2415919061
lh x20, 3(x10)
fsqrt.h f18, f20, rdn
csrrs x20, fflags, x0
fcvt.l.s x13, f15, rne
csrrs x15, fflags, x0
li x8, 2415919072
c.sd x13, 0(x8)
mulhsu x16, x14, x19
li x2, 2415919040
c.sdsp x15, 8(sp)
czero.eqz x16, x19, x14
bexti x14, x16, 61
fnmsub.h f20, f20, f18, f13, rup
csrrs x17, fflags, x0
sub x19, x16, x13
srl x19, x14, x16
li x9, 2415919042
amoswap.w.aqrl x15, x15, (x9)
fsub.d f18, f16, f13, rdn
csrrs x20, fflags, x0
zext.h x16, x17
slt x20, x16, x15
fdiv.s f20, f15, f16, rmm
csrrs x13, fflags, x0
ori x14, x14, 1077
li x9, 2415919032
amoswap.d.rl x20, x17, (x9)
fcvt.l.d x16, f13, rne
csrrs x19, fflags, x0
c.addi x20, -3
sh1add x15, x17, x15
li x2, 2415919052
c.swsp x19, 4(sp)
fcvt.wu.h x19, f20, rtz
csrrs x14, fflags, x0
fsgnj.d f17, f13, f16
csrrs x15, fflags, x0
fle.h x18, f19, f15
csrrs x13, fflags, x0
fmsub.h f19, f20, f15, f18, rne
csrrs x18, fflags, x0
slli.uw x16, x19, 42
sh2add.uw x13, x14, x20
fcvt.s.lu f16, x15, rmm
csrrs x18, fflags, x0
fmsub.s f15, f17, f19, f16, dyn
csrrs x18, fflags, x0
czero.nez x20, x16, x15
feq.s x17, f20, f16
csrrs x13, fflags, x0
csrrs x13, fflags, x0
c.srli x14, 17
slliw x16, x14, 24
li x11, 2415919062
amomax.w.aqrl x16, x15, (x11)
mulhsu x14, x19, x18
xori x18, x18, 2025
fcvt.d.lu f19, x20, rdn
csrrs x16, fflags, x0
li x11, 2415919045
amoand.d.aqrl x14, x17, (x11)
fsqrt.d f19, f16, rne
csrrs x18, fflags, x0
addw x13, x13, x20
feq.s x19, f13, f20
csrrs x16, fflags, x0
fsqrt.d f18, f18, rmm
csrrs x17, fflags, x0
czero.nez x16, x17, x15
li x11, 2415919065
sd x19, 15(x11)
sll x18, x14, x18
fence.i
fmax.h f19, f19, f19
csrrs x14, fflags, x0
fdiv.h f20, f19, f14, rup
csrrs x15, fflags, x0
c.xor x15, x15
fle.s x14, f15, f19
csrrs x16, fflags, x0
sext.b x15, x20
li x12, 2415919050
lb x15, 6(x12)
fle.d x18, f15, f18
csrrs x13, fflags, x0
fmul.h f17, f20, f18, rmm
csrrs x15, fflags, x0
remuw x15, x13, x18
fence.i
li x8, 2415919032
flw f17, 12(x8)
csrrs x16, fflags, x0
fsgnjx.h f20, f20, f20
csrrs x14, fflags, x0
add x19, x20, x16
fsqrt.h f14, f15, rdn
csrrs x15, fflags, x0
li x2, 2415919038
c.sdsp x15, 8(sp)
csrrs x13, fflags, x0
mulh x14, x15, x16
c.andi x13, 8
fmv.w.x f18, x18
csrrs x14, fflags, x0
c.li x13, -6
fle.s x13, f13, f14
csrrs x17, fflags, x0
fmul.h f20, f14, f18, dyn
csrrs x15, fflags, x0
li x15, 0
csrrc x16, frm, x15
csrrs x20, fflags, x0
c.li x15, -5
fdiv.d f20, f17, f16, rmm
csrrs x15, fflags, x0
divu x13, x20, x20
fmax.s f16, f16, f13
csrrs x18, fflags, x0
fcvt.d.wu f18, x13
csrrs x20, fflags, x0
min x14, x18, x15
flt.h x13, f19, f17
csrrs x13, fflags, x0
csrrs x16, fflags, x0
fnmadd.h f20, f15, f17, f19, dyn
csrrs x14, fflags, x0
minu x18, x18, x16
fcvt.l.h x16, f13, dyn
csrrs x19, fflags, x0
li x12, 2415919070
amominu.d.aq x20, x17, (x12)
sh1add x19, x19, x13
fence.i
addiw x16, x14, 364
c.andi x14, 16
fnmadd.d f16, f18, f13, f16, dyn
csrrs x18, fflags, x0
fcvt.lu.s x16, f13, rmm
csrrs x17, fflags, x0
sh3add x16, x18, x20
divuw x18, x20, x20
and x13, x18, x17
fcvt.l.d x17, f14, rdn
csrrs x20, fflags, x0
fcvt.s.lu f19, x18, rne
csrrs x19, fflags, x0
sh3add x16, x13, x15
fsub.d f18, f20, f15, dyn
csrrs x13, fflags, x0
fcvt.h.s f20, f15, rne
csrrs x19, fflags, x0
csrrs x15, fflags, x0
cpop x17, x20
fcvt.s.w f18, x19, rne
csrrs x17, fflags, x0
srli x20, x14, 20
fsgnjx.s f13, f18, f13
csrrs x13, fflags, x0
min x16, x15, x20
sll x17, x17, x17
csrrs x14, fflags, x0
c.addiw x13, 0
li x12, 2415919034
amoswap.d.aq x16, x19, (x12)
c.or x15, x14
sllw x17, x14, x18
fcvt.lu.s x14, f13, dyn
csrrs x16, fflags, x0
c.addi x17, -24
fcvt.h.d f15, f13, rne
csrrs x17, fflags, x0
and x16, x17, x13
feq.h x15, f15, f16
csrrs x20, fflags, x0
li x10, 2415919059
sh x15, 10(x10)
mul x19, x16, x20
fsub.s f14, f15, f20, dyn
csrrs x15, fflags, x0
addiw x15, x20, 1691
ctzw x18, x16
cpopw x14, x19
fcvt.s.l f14, x15, rne
csrrs x16, fflags, x0
li x11, 2415919058
amoadd.d.aqrl x17, x16, (x11)
mulhsu x19, x14, x16
xor x13, x14, x15
fence.i
fsgnj.d f18, f18, f18
csrrs x15, fflags, x0
fence.i
cpop x17, x13
bexti x15, x15, 13
li x9, 2415919037
amominu.d x20, x19, (x9)
csrrci x18, fcsr, 22
remu x15, x18, x17
slli.uw x16, x19, 59
fdiv.s f16, f17, f18, rtz
csrrs x19, fflags, x0
and x19, x13, x17
fsgnjx.h f17, f19, f14
csrrs x16, fflags, x0
csrrs x18, fflags, x0
fcvt.s.w f13, x15, rtz
csrrs x19, fflags, x0
fcvt.w.h x20, f15, dyn
csrrs x14, fflags, x0
li x9, 2415919042
lwu x14, 4(x9)
li x8, 2415919070
lh x17, 2(x8)
li x2, 2415919065
c.sdsp x15, 16(sp)
csrrs x16, fflags, x0
li x9, 2415919063
amoadd.w.aq x14, x14, (x9)
srliw x16, x16, 4
csrrs x20, fflags, x0
c.or x13, x13
fsgnjn.d f14, f14, f18
csrrs x13, fflags, x0
cpopw x19, x15
li x8, 2415919037
flh f17, 2(x8)
csrrs x15, fflags, x0
ori x17, x16, -606
fmul.s f14, f19, f14, rmm
csrrs x15, fflags, x0
li x12, 2415919059
sd x20, 2(x12)
c.andi x14, 19
remw x16, x17, x18
fcvt.s.l f19, x17, rne
csrrs x16, fflags, x0
fmsub.d f14, f14, f14, f14, rmm
csrrs x18, fflags, x0
max x15, x16, x19
fmadd.s f19, f16, f15, f15, rup
csrrs x19, fflags, x0
fmv.w.x f15, x15
csrrs x18, fflags, x0
fmax.s f14, f13, f15
csrrs x16, fflags, x0
sra x18, x20, x13
fence.i
ctzw x13, x15
csrrs x16, fflags, x0
li x2, 2415919057
c.swsp x19, 4(sp)
fadd.d f13, f19, f13, dyn
csrrs x14, fflags, x0
li x9, 2415919041
c.sd x15, 16(x9)
fence.i
c.sub x13, x15
li x8, 2415919053
c.sw x13, 8(x8)
sraiw x20, x18, 16
c.add x15, x20
c.subw x15, x13
fcvt.l.d x13, f14, dyn
csrrs x14, fflags, x0
csrrs x16, fflags, x0
feq.s x16, f15, f13
csrrs x20, fflags, x0
li x19, 15
csrrs x19, mcause, x19
mulhsu x19, x17, x14
mul x14, x14, x19
csrrs x19, fflags, x0
fsgnjx.d f18, f20, f18
csrrs x20, fflags, x0
fdiv.s f14, f18, f18, rup
csrrs x16, fflags, x0
li x12, 2415919047
sw x13, 0(x12)
li x12, 2415919055
amoswap.d.rl x20, x14, (x12)
c.addiw x20, -15
fle.s x17, f20, f16
csrrs x19, fflags, x0
clz x15, x16
orc.b x17, x13
fmax.s f16, f16, f16
csrrs x15, fflags, x0
srlw x20, x17, x13
fnmsub.h f17, f15, f13, f16, rtz
csrrs x15, fflags, x0
fmadd.s f16, f14, f16, f15, dyn
csrrs x19, fflags, x0
li x10, 2415919056
amoor.d x17, x20, (x10)
czero.eqz x18, x16, x18
ctz x14, x14
fence.i
li x8, 2415919041
sw x16, 11(x8)
fmax.d f16, f14, f18
csrrs x17, fflags, x0
fsgnj.d f20, f15, f13
csrrs x17, fflags, x0
binvi x15, x18, 33
add x19, x17, x20
li x11, 2415919067
lwu x17, 15(x11)
bexti x16, x20, 17

exit:
    li t0, 1 # report success
    la t1, tohost
    sd t0, 0(t1)
1:
    j 1b


.align 2
switch_to_s_mode:
    # Set up the page table: identity-map the 1GB region containing 0x80000000
    la t0, pgtbl
    li t1, (0x80000 << 10) | 0xCF # PPN=0x80000, full permissions
    sd t1, 16(t0)

    # Write satp to enable paging (Sv39)
    li t2, 8
    slli t2, t2, 60
    srli t1, t0, 12
    or t2, t2, t1
    csrw satp, t2
    sfence.vma

    # Set MPP to S-mode (1) and prepare for mret
    li t0, ~(3 << 11)
    csrr t1, mstatus
    and t1, t1, t0
    li t2, (1 << 11)
    or t1, t1, t2
    csrw mstatus, t1

    csrw mepc, ra
    mret

.align 2
exit_s_mode:
    ecall # Trigger Environment Call (Cause 9)
    ret # Handler will actually adjust mepc to skip this spot


    .align 2
trap_handler:
    csrr t0, mepc # faulting PC
    csrr t1, mcause # trap cause
    csrr t4, mtval

    # Extract the exception code
    slli t5, t1, 1
    srli t1, t5, 1

    # --- Added: handle requests to return to M-mode ---
    li t3, 9 # Ecall from S-mode
    bne t1, t3, check_page_fault
    # If it is an ecall, set MPP so mret returns to M-mode
    li t2, 3 << 11
    csrs mstatus, t2 # Set MPP to 3 (Machine)
    li t2, 4 # Skip the ecall instruction
    j update_mepc

check_page_fault:
    # --- Added: detect page faults (13 or 15) ---
    li t3, 13
    beq t1, t3, handle_as_normal_fault
    li t3, 15
    beq t1, t3, handle_as_normal_fault

    # If it's neither a page fault nor an ecall, fall back to the original logic
    j original_logic

handle_as_normal_fault:
    # Page faults still need instruction-length decoding and skipping; reuse the original logic
    j original_logic

original_logic:
    # Original logic: decode instruction length
    li t2, 2
    li t3, 2
    beq t1, t3, illegal_len
    li t3, 1
    beq t1, t3, instr_fault_len
    li t3, 12
    beq t1, t3, instr_fault_len

    lhu t4, 0(t0)
    j decode_length

other_len:
    lhu t4, 0(t0)
    j decode_length

illegal_len:
    beqz t4, other_len
    j decode_length

instr_fault_len:
    li t2, 4
    j update_mepc

decode_length:
    andi t4, t4, 3
    li t3, 3
    bne t4, t3, compressed_len
    li t2, 4
    j update_mepc

compressed_len:
    li t2, 2

update_mepc:
    add t0, t0, t2
    csrw mepc, t0
    csrw mcause, x0
    csrw mtval, x0
    mret

    .section .data
    .balign 4096
pgtbl:
    .zero 4096


    .section .tohost,"aw",@progbits
    .align 6
    .globl tohost
    .globl fromhost
tohost:
    .dword 0
fromhost:
    .dword 0
