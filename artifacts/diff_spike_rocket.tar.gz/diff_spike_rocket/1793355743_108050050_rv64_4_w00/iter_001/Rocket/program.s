# 0 "/home/fuzz/runs/diff_spike_rocket/1793355743_108050050_rv64_4_w00/iter_001/Rocket/program.S"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/home/fuzz/runs/diff_spike_rocket/1793355743_108050050_rv64_4_w00/iter_001/Rocket/program.S"
    .section .text
    .globl _start

_start:
    la t0, trap_handler
    csrw mtvec, t0

    csrr t0, mstatus
    li t1, 0x00003000 # set FS field to Dirty (0b11) so FP regs usable
    or t0, t0, t1
    csrw mstatus, t0
    csrw fcsr, x0 # clear floating-point status

    j user_code

user_code:
li x13, 0x9d129a9c0c91acd1
li x14, 0x97355d73bc22566a
li x15, 0x1b7e83edabab96ad
li x16, 0x6ad4074a14ccb0d9
li x17, 0xea351fe9266aa8f
li x18, 0xdfcd1c336722ed8f
li x19, 0xee8a187ae1add5f1
li x20, 0xc1546d458c99043e
li x8, 0x143e7178ee86cf8f
fmv.d.x f13, x8
li x8, 0x496a3057e82f436
fmv.d.x f14, x8
li x8, 0x71f0084de5e37239
fmv.d.x f15, x8
li x8, 0x30038c68d214fde1
fmv.d.x f16, x8
li x8, 0x30b7f4ac15b65ddb
fmv.d.x f17, x8
li x8, 0xd7e39751554ed414
fmv.d.x f18, x8
li x8, 0x3d3bccc71bf5b05b
fmv.d.x f19, x8
li x8, 0x2069eeb655bc82b8
fmv.d.x f20, x8
li x9, 0x8fffffb8
li x10, 0xed037a8c00bc4bcf
sd x10, 0(x9)
li x10, 0x30088d6b4e2c74ff
sd x10, 8(x9)
li x10, 0xb684e0a7338817b1
sd x10, 16(x9)
li x10, 0x9bb020967bb2b72f
sd x10, 24(x9)
li x10, 0x4c71ad9f3814f8d
sd x10, 32(x9)
li x10, 0x5497065ed207a494
sd x10, 40(x9)
li x10, 0x2e8d6a454821963f
sd x10, 48(x9)
li x10, 0xaa735d2a78f506fa
sd x10, 56(x9)
li x8, 0
li x9, 0
li x10, 0
li x11, 0
li x12, 0
flt.h x20, f20, f20
csrrs x13, fflags, x0
bset x18, x20, x13
fsgnj.d f18, f16, f19
csrrs x15, fflags, x0
li x11, 2415919040
c.sw x15, 16(x11)
li x9, 2415919068
amomin.d.aqrl x20, x16, (x9)
fsub.d f13, f16, f14, dyn
csrrs x17, fflags, x0
csrrs x13, fflags, x0
czero.eqz x14, x14, x16
srlw x19, x15, x19
fnmsub.d f13, f15, f16, f16, rtz
csrrs x17, fflags, x0
fcvt.s.h f20, f19
csrrs x20, fflags, x0
fsgnjx.h f14, f18, f15
csrrs x13, fflags, x0
fence.i
fsub.h f16, f13, f13, rmm
csrrs x19, fflags, x0
fsgnjn.s f17, f17, f19
csrrs x13, fflags, x0
li x11, 2415919067
amominu.w x16, x20, (x11)
csrrs x14, fflags, x0
li x10, 2415919067
amoadd.d x16, x13, (x10)
fsgnjn.s f13, f20, f14
csrrs x13, fflags, x0
fsgnjx.d f17, f13, f19
csrrs x15, fflags, x0
li x9, 2415919067
sd x17, 2(x9)
li x11, 2415919045
lhu x16, 9(x11)
sext.b x17, x13
or x13, x14, x14
fnmsub.h f13, f13, f19, f13, dyn
csrrs x17, fflags, x0
add x13, x13, x17
slliw x13, x20, 26
fadd.h f18, f17, f20, rup
csrrs x13, fflags, x0
c.addi x15, -22
c.ebreak
li x9, 2415919033
amoand.d.aq x18, x17, (x9)
fcvt.s.d f17, f18, rne
csrrs x20, fflags, x0
feq.h x17, f15, f20
csrrs x14, fflags, x0
fclass.d x20, f20
csrrs x14, fflags, x0
fsub.s f20, f17, f19, rne
csrrs x14, fflags, x0
li x9, 2415919061
amoadd.w.aq x18, x20, (x9)
c.lui x17, 0xfffec
li x12, 2415919054
sb x19, 10(x12)
li x10, 2415919046
fsh f14, 12(x10)
csrrs x19, fflags, x0
c.slli x20, 5
li x10, 2415919063
amomin.w x13, x15, (x10)
xor x16, x15, x15
add x19, x17, x16
fmsub.s f19, f15, f13, f18, rne
csrrs x19, fflags, x0
fmadd.d f17, f20, f17, f19, dyn
csrrs x16, fflags, x0
li x12, 2415919054
amomaxu.w x13, x15, (x12)
fnmsub.s f17, f20, f20, f13, rmm
csrrs x16, fflags, x0
mulhsu x19, x19, x14
li x8, 2415919038
amoxor.d.rl x17, x19, (x8)
li x2, 2415919054
c.ldsp x16, 16(sp)
li x14, 28
csrrc x18, fflags, x14
srli x19, x19, 17
binv x14, x16, x20
fcvt.w.h x18, f16, dyn
csrrs x15, fflags, x0
li x12, 2415919045
amomaxu.d x14, x14, (x12)
bext x13, x17, x13
li x12, 2415919035
amominu.w.rl x17, x16, (x12)
flt.h x14, f13, f18
csrrs x15, fflags, x0
fcvt.h.w f17, x16, rtz
csrrs x14, fflags, x0
c.and x15, x13
sraw x17, x16, x17
slt x14, x13, x20
c.ebreak
fmul.s f17, f15, f15, rmm
csrrs x16, fflags, x0
fle.h x19, f19, f14
csrrs x17, fflags, x0
sh1add.uw x19, x15, x18
fcvt.l.d x14, f19, rtz
csrrs x17, fflags, x0
fsgnjx.h f18, f15, f15
csrrs x15, fflags, x0
fsgnjx.d f19, f20, f20
csrrs x14, fflags, x0
li x2, 2415919062
c.ldsp x20, 0(sp)
fle.s x20, f19, f16
csrrs x19, fflags, x0
fmin.s f16, f20, f15
csrrs x15, fflags, x0
fle.s x13, f14, f17
csrrs x17, fflags, x0
slli x15, x20, 22
li x2, 2415919066
c.ldsp x18, 8(sp)
csrrs x17, fflags, x0
fence.i
fdiv.d f19, f20, f20, dyn
csrrs x17, fflags, x0
fcvt.l.h x17, f17, dyn
csrrs x14, fflags, x0
fdiv.s f19, f19, f16, dyn
csrrs x20, fflags, x0
ori x17, x16, -235
csrrs x20, fflags, x0
divw x20, x19, x18
fnmadd.s f14, f14, f20, f13, rdn
csrrs x19, fflags, x0
li x11, 2415919034
fsd f18, 10(x11)
csrrs x15, fflags, x0
fcvt.w.d x16, f19, dyn
csrrs x15, fflags, x0
fcvt.s.d f16, f13, dyn
csrrs x18, fflags, x0
fcvt.lu.d x14, f14, dyn
csrrs x17, fflags, x0
li x8, 2415919057
fsw f17, 16(x8)
csrrs x13, fflags, x0
fcvt.s.lu f18, x13, dyn
csrrs x20, fflags, x0
fle.h x16, f19, f13
csrrs x20, fflags, x0
czero.nez x13, x15, x17
csrrs x16, fflags, x0
li x2, 2415919060
c.swsp x17, 12(sp)
fmin.s f20, f17, f17
csrrs x15, fflags, x0
fcvt.d.wu f18, x14
csrrs x19, fflags, x0
fmsub.s f20, f15, f13, f16, rdn
csrrs x19, fflags, x0
fcvt.h.lu f20, x15, rne
csrrs x17, fflags, x0
fcvt.h.w f19, x16, rup
csrrs x19, fflags, x0
fle.h x14, f20, f19
csrrs x15, fflags, x0
fadd.d f18, f14, f19, dyn
csrrs x18, fflags, x0
bclr x17, x19, x13
sh1add.uw x18, x17, x18
lui x18, 425984
fcvt.d.lu f13, x16, rmm
csrrs x19, fflags, x0
ori x15, x19, -1361
slli x16, x19, 21
slliw x19, x18, 11
bset x20, x14, x13
sltiu x15, x15, 1103
csrrs x16, fflags, x0
addiw x14, x14, 1410
xori x19, x13, 1567
ctzw x14, x15
flt.s x15, f14, f20
csrrs x18, fflags, x0
csrrs x19, fflags, x0
li x9, 2415919067
sb x16, 7(x9)
fcvt.l.d x20, f20, rup
csrrs x18, fflags, x0
fcvt.l.h x20, f20, rtz
csrrs x19, fflags, x0
fence.i
fadd.h f17, f13, f15, dyn
csrrs x17, fflags, x0
fmsub.d f13, f20, f18, f18, rmm
csrrs x20, fflags, x0
c.subw x15, x14
fcvt.h.wu f16, x14, rmm
csrrs x17, fflags, x0
feq.h x14, f15, f17
csrrs x20, fflags, x0
fle.s x20, f16, f17
csrrs x16, fflags, x0
li x9, 2415919069
amoor.d.aq x17, x14, (x9)
fdiv.s f18, f20, f20, rmm
csrrs x13, fflags, x0
fcvt.d.wu f14, x14
csrrs x15, fflags, x0
fcvt.lu.h x17, f17, dyn
csrrs x13, fflags, x0
fsub.h f15, f13, f20, dyn
csrrs x17, fflags, x0
remuw x16, x18, x17
flt.h x13, f20, f19
csrrs x16, fflags, x0
fsgnjx.d f14, f19, f19
csrrs x16, fflags, x0
binv x20, x19, x19
fmsub.d f16, f17, f15, f14, dyn
csrrs x13, fflags, x0
li x8, 2415919043
amoand.d x18, x14, (x8)
fcvt.h.l f14, x16, rne
csrrs x20, fflags, x0
fence.i
feq.d x14, f20, f13
csrrs x18, fflags, x0
csrrs x15, fflags, x0
csrrwi x16, frm, 1
c.li x16, -2
li x2, 2415919035
c.swsp x20, 0(sp)
mulw x13, x17, x13
min x20, x14, x16
csrrs x15, fflags, x0
fnmsub.d f20, f15, f20, f18, dyn
csrrs x14, fflags, x0
fmadd.h f13, f15, f19, f13, rup
csrrs x19, fflags, x0
li x11, 2415919037
lwu x19, 6(x11)
minu x20, x18, x15
li x10, 2415919069
sw x13, 8(x10)
fsgnjn.s f15, f18, f19
csrrs x17, fflags, x0
li x9, 2415919063
c.ld x15, 16(x9)
li x8, 2415919037
lw x14, 4(x8)
fcvt.wu.d x18, f16, rtz
csrrs x14, fflags, x0
li x8, 2415919042
c.ld x15, 8(x8)
csrrs x14, fflags, x0
fmax.s f14, f16, f17
csrrs x15, fflags, x0
csrrs x15, fflags, x0
fsgnjx.s f17, f18, f16
csrrs x18, fflags, x0
li x8, 2415919070
sh x16, 6(x8)
fcvt.d.l f15, x13, dyn
csrrs x17, fflags, x0
c.slli x19, 33
fsgnjn.s f18, f15, f19
csrrs x16, fflags, x0
c.addi16sp sp, 16
csrrs x16, fflags, x0
li x9, 2415919061
lw x17, 15(x9)
fdiv.d f15, f18, f18, rup
csrrs x13, fflags, x0
sllw x19, x18, x13
li x10, 2415919065
lhu x20, 15(x10)
li x9, 2415919068
sd x15, 10(x9)
fmv.d.x f17, x19
csrrs x19, fflags, x0
csrrs x15, fflags, x0
bext x14, x19, x16
c.srli x14, 35
feq.h x16, f15, f13
csrrs x15, fflags, x0
csrrs x15, fflags, x0
fsgnjx.d f18, f14, f18
csrrs x19, fflags, x0
li x9, 2415919037
sh x15, 4(x9)
fcvt.s.lu f13, x14, rmm
csrrs x16, fflags, x0
li x11, 2415919059
sd x19, 3(x11)
fmadd.h f17, f13, f13, f14, rne
csrrs x14, fflags, x0
binvi x16, x17, 43
c.add x13, x13
li x12, 2415919033
amoand.w.aqrl x16, x13, (x12)
c.and x13, x14
fnmsub.d f19, f14, f15, f13, dyn
csrrs x14, fflags, x0
fmsub.h f13, f19, f13, f17, rmm
csrrs x19, fflags, x0
bclri x20, x16, 54
fcvt.w.d x17, f14, rup
csrrs x18, fflags, x0
fcvt.s.wu f15, x15, rmm
csrrs x14, fflags, x0
csrrs x19, fflags, x0
li x8, 2415919067
amoor.d.aqrl x15, x19, (x8)
slliw x17, x15, 5
fmsub.s f19, f19, f17, f17, dyn
csrrs x14, fflags, x0
csrrs x20, fflags, x0
fcvt.h.lu f19, x16, dyn
csrrs x15, fflags, x0
csrrs x15, fflags, x0
c.or x13, x14
fnmsub.h f14, f19, f18, f17, rmm
csrrs x17, fflags, x0
li x10, 2415919061
ld x20, 8(x10)
addiw x13, x16, -898
fmul.d f16, f16, f19, rdn
csrrs x16, fflags, x0
fcvt.h.d f20, f18, rup
csrrs x13, fflags, x0
ctzw x16, x14
fcvt.d.lu f17, x18, rup
csrrs x19, fflags, x0
mulh x14, x15, x16
fmadd.d f13, f18, f16, f15, dyn
csrrs x13, fflags, x0
li x11, 2415919065
amomaxu.d x14, x13, (x11)
and x17, x17, x13
li x12, 2415919054
amomaxu.w.aqrl x19, x19, (x12)
li x11, 2415919051
c.sd x13, 8(x11)
sh2add.uw x14, x19, x14
csrrs x15, fflags, x0
czero.eqz x13, x18, x15
fdiv.d f19, f20, f14, dyn
csrrs x16, fflags, x0
fcvt.wu.d x17, f14, rne
csrrs x13, fflags, x0
li x11, 2415919040
flw f16, 13(x11)
csrrs x19, fflags, x0
sltiu x15, x15, -212
li x8, 2415919070
amomaxu.w.rl x20, x13, (x8)
binv x15, x19, x14
csrrs x19, fflags, x0
csrrs x15, fflags, x0
slti x14, x13, 77
li x8, 2415919068
amoadd.w.aq x20, x14, (x8)
fcvt.d.h f14, f15
csrrs x14, fflags, x0
csrrs x16, fflags, x0
or x13, x16, x14
mulw x15, x20, x20
fmax.d f13, f13, f18
csrrs x19, fflags, x0
csrrs x14, fflags, x0
bset x18, x19, x19
li x2, 2415919055
c.sdsp x15, 0(sp)
fsgnj.d f14, f18, f14
csrrs x13, fflags, x0
li x12, 2415919043
c.ld x13, 0(x12)
fcvt.w.d x13, f20, dyn
csrrs x19, fflags, x0
csrrs x17, fflags, x0
csrrs x15, fflags, x0
flt.d x18, f19, f16
csrrs x17, fflags, x0
fcvt.h.lu f13, x17, rtz
csrrs x20, fflags, x0
csrrs x18, fflags, x0
fmax.h f20, f15, f19
csrrs x20, fflags, x0
sltiu x16, x20, 1410
fcvt.s.l f17, x15, rdn
csrrs x17, fflags, x0
fcvt.s.h f18, f15
csrrs x13, fflags, x0
fcvt.w.h x16, f16, rtz
csrrs x15, fflags, x0
fmv.x.d x17, f20
csrrs x18, fflags, x0
li x8, 2415919056
fsh f17, 2(x8)
csrrs x18, fflags, x0
csrrs x14, fflags, x0
sub x15, x13, x18
remuw x14, x17, x14
fdiv.d f19, f20, f13, rdn
csrrs x16, fflags, x0
srlw x20, x16, x18
maxu x16, x15, x20
slli.uw x15, x18, 54
li x9, 2415919044
amominu.w.aq x20, x14, (x9)
li x12, 2415919047
c.ld x13, 16(x12)
czero.eqz x20, x13, x18
li x10, 2415919040
amoadd.d x20, x17, (x10)
fence.tso
li x2, 2415919032
c.lwsp x14, 4(sp)
cpop x18, x16
czero.eqz x17, x16, x19
cpop x17, x20
li x12, 2415919037
amoadd.d.aq x20, x17, (x12)
srai x17, x17, 56
fclass.d x13, f20
csrrs x17, fflags, x0
fmv.w.x f15, x17
csrrs x14, fflags, x0
bclr x18, x14, x20
max x20, x20, x16
fcvt.l.d x20, f19, rdn
csrrs x20, fflags, x0
sh1add x14, x16, x19
bset x13, x14, x13
li x9, 2415919033
sw x20, 11(x9)
fcvt.s.lu f19, x14, dyn
csrrs x15, fflags, x0
fsgnj.d f14, f16, f14
csrrs x14, fflags, x0
c.xor x13, x14
lui x14, 262144
fmadd.h f13, f13, f17, f15, rdn
csrrs x19, fflags, x0
feq.h x15, f16, f18
csrrs x13, fflags, x0
fclass.s x13, f16
csrrs x20, fflags, x0
minu x14, x16, x13
fmsub.h f16, f17, f19, f17, dyn
csrrs x14, fflags, x0
fclass.h x17, f15
csrrs x17, fflags, x0
sltu x13, x13, x18
fle.h x13, f16, f16
csrrs x16, fflags, x0
bset x15, x16, x13
mulhsu x18, x20, x13
li x10, 2415919060
amoadd.w.aqrl x17, x19, (x10)
ctz x15, x16
li x8, 2415919062
c.lw x15, 8(x8)
li x2, 2415919053
c.swsp x13, 4(sp)
li x8, 2415919035
fsw f18, 3(x8)
csrrs x13, fflags, x0
clz x20, x15
remuw x13, x13, x17
fmadd.h f15, f15, f18, f18, rne
csrrs x13, fflags, x0
fcvt.d.w f18, x20
csrrs x19, fflags, x0
fcvt.s.lu f15, x19, dyn
csrrs x19, fflags, x0
fcvt.s.l f18, x19, rmm
csrrs x16, fflags, x0
srlw x13, x16, x16
li x12, 2415919070
amoor.w.rl x20, x17, (x12)
add.uw x14, x16, x14
fmin.h f18, f14, f18
csrrs x19, fflags, x0
fmax.h f17, f14, f16
csrrs x18, fflags, x0
fmul.h f18, f15, f15, rmm
csrrs x18, fflags, x0
li x11, 2415919042
c.ld x13, 16(x11)
fcvt.s.lu f19, x18, rne
csrrs x15, fflags, x0
feq.s x17, f14, f19
csrrs x17, fflags, x0
csrrs x17, fflags, x0
fsgnjx.h f15, f14, f16
csrrs x18, fflags, x0
fence.i
lui x13, 606208
fence.i
czero.eqz x16, x15, x16
li x8, 2415919043
ld x17, 5(x8)
fmv.d.x f15, x19
csrrs x14, fflags, x0
sh2add x17, x13, x18
csrrs x14, fflags, x0
li x11, 2415919052
amoswap.d.aq x16, x16, (x11)
li x9, 2415919069
flw f19, 4(x9)
csrrs x15, fflags, x0
li x10, 2415919049
amomaxu.w.aq x16, x18, (x10)
remw x19, x20, x16
bexti x14, x15, 54
bexti x17, x19, 53
csrrs x15, fflags, x0
li x12, 2415919045
c.lw x13, 12(x12)
divw x17, x18, x20
lui x14, 888832
srl x14, x17, x14
li x2, 2415919045
c.lwsp x18, 12(sp)
csrrs x15, fflags, x0
sltu x17, x17, x16
li x11, 2415919049
sb x20, 0(x11)
li x10, 2415919038
lh x19, 7(x10)
fle.s x15, f19, f20
csrrs x17, fflags, x0
feq.h x14, f14, f19
csrrs x19, fflags, x0
c.subw x14, x15
maxu x15, x20, x13
divu x15, x17, x17
sh2add.uw x15, x20, x17
fence.i
li x11, 2415919059
fsh f13, 11(x11)
csrrs x13, fflags, x0
li x10, 2415919055
c.lw x14, 8(x10)
li x12, 2415919062
sb x17, 9(x12)
fsub.d f15, f20, f19, dyn
csrrs x18, fflags, x0
csrrs x19, fflags, x0
c.and x15, x15
fsgnj.d f16, f18, f13
csrrs x15, fflags, x0
fmv.x.h x14, f15
csrrs x15, fflags, x0
max x13, x16, x14
li x9, 2415919037
lw x20, 9(x9)
fcvt.s.wu f17, x17, rdn
csrrs x13, fflags, x0
feq.s x19, f19, f18
csrrs x20, fflags, x0
fcvt.l.d x19, f17, dyn
csrrs x13, fflags, x0
sllw x18, x19, x17
li x10, 2415919066
amomax.d.aqrl x18, x17, (x10)
binvi x16, x15, 50
li x10, 2415919050
amominu.w x19, x18, (x10)
fence.i
fdiv.h f20, f13, f17, rmm
csrrs x15, fflags, x0
slli.uw x18, x13, 17
c.slli x19, 46
sh2add.uw x18, x17, x20
c.srli x13, 36
sll x13, x18, x15
czero.nez x14, x20, x18
fnmsub.d f19, f17, f20, f19, dyn
csrrs x19, fflags, x0
csrrs x17, fflags, x0
c.ebreak
csrrs x19, fflags, x0
c.mv x17, x14
li x8, 2415919053
sd x17, 4(x8)
fcvt.wu.h x13, f15, rmm
csrrs x14, fflags, x0
li x9, 2415919070
amoand.d.aq x18, x18, (x9)
fmsub.s f20, f13, f13, f13, dyn
csrrs x17, fflags, x0
orc.b x17, x14
czero.nez x16, x14, x14
fsgnjn.h f14, f16, f19
csrrs x15, fflags, x0
slli.uw x18, x14, 56
czero.eqz x13, x14, x13
li x9, 2415919038
lh x18, 0(x9)
li x10, 2415919067
amoxor.w.aq x14, x17, (x10)
li x10, 2415919047
lh x16, 1(x10)
fcvt.h.w f19, x19, rdn
csrrs x14, fflags, x0
li x11, 2415919054
amominu.d.aq x14, x16, (x11)
flt.s x13, f18, f14
csrrs x13, fflags, x0
fence.i
li x9, 2415919068
amominu.d.aq x20, x14, (x9)
li x11, 2415919044
amoswap.w.aqrl x18, x13, (x11)
fcvt.lu.s x13, f19, rup
csrrs x16, fflags, x0
li x11, 2415919070
flh f13, 7(x11)
csrrs x19, fflags, x0
fcvt.d.w f20, x15
csrrs x13, fflags, x0
fdiv.s f13, f20, f17, rmm
csrrs x15, fflags, x0
li x10, 2415919037
amoswap.d.rl x15, x17, (x10)
remu x17, x20, x13
fcvt.s.l f13, x15, rdn
csrrs x13, fflags, x0
fcvt.w.d x20, f16, dyn
csrrs x15, fflags, x0
add x15, x14, x20
c.ebreak
fmadd.s f19, f15, f17, f17, rdn
csrrs x17, fflags, x0
csrrs x16, fflags, x0
li x9, 2415919054
flw f18, 3(x9)
csrrs x20, fflags, x0
csrrs x18, fflags, x0
lui x15, 1019904
fcvt.s.lu f20, x14, rtz
csrrs x13, fflags, x0
csrrs x20, fflags, x0
fcvt.l.d x14, f18, rtz
csrrs x13, fflags, x0
csrrs x20, fflags, x0
add x17, x20, x18
mulhsu x16, x13, x13
srl x19, x16, x15
sext.b x16, x16
li x10, 2415919065
amoor.d x20, x19, (x10)
feq.h x15, f18, f16
csrrs x14, fflags, x0
rem x16, x20, x19
max x18, x15, x18
add x14, x19, x18
fsqrt.s f16, f19, dyn
csrrs x19, fflags, x0
fcvt.l.d x15, f13, dyn
csrrs x13, fflags, x0
fadd.s f17, f18, f20, rup
csrrs x19, fflags, x0
fmsub.h f19, f18, f15, f19, rup
csrrs x13, fflags, x0
ctzw x16, x18
fle.h x14, f15, f18
csrrs x13, fflags, x0
flt.s x14, f20, f17
csrrs x20, fflags, x0
li x8, 2415919066
c.lw x13, 12(x8)
c.andi x14, -1
li x8, 2415919069
amoxor.w.aqrl x14, x17, (x8)
li x8, 2415919056
sw x18, 13(x8)
flt.d x17, f19, f14
csrrs x16, fflags, x0
li x9, 2415919057
amominu.w.aq x19, x20, (x9)
fcvt.lu.s x19, f14, dyn
csrrs x15, fflags, x0
sh1add x15, x19, x16
fmsub.h f17, f15, f20, f15, rmm
csrrs x19, fflags, x0
fmsub.s f19, f18, f16, f16, dyn
csrrs x16, fflags, x0
fdiv.d f14, f14, f15, rne
csrrs x20, fflags, x0
mulhsu x18, x13, x18
fcvt.h.w f18, x16, rdn
csrrs x17, fflags, x0
c.addi x13, 1
addiw x16, x17, 1741
csrrs x14, fflags, x0
li x10, 2415919068
amoand.d x16, x20, (x10)
srl x16, x20, x15
fcvt.h.l f18, x16, rup
csrrs x14, fflags, x0
fmadd.d f14, f17, f17, f17, rdn
csrrs x20, fflags, x0
c.lui x15, 0xffff9
flt.d x19, f19, f18
csrrs x19, fflags, x0
fsqrt.h f17, f16, rne
csrrs x20, fflags, x0
fcvt.s.wu f16, x17, rmm
csrrs x13, fflags, x0
fmadd.h f17, f14, f13, f13, rmm
csrrs x20, fflags, x0
c.or x14, x14
fsgnj.s f14, f16, f14
csrrs x15, fflags, x0
fnmsub.h f15, f18, f20, f18, rtz
csrrs x14, fflags, x0
sh1add.uw x20, x13, x20
fcvt.h.d f14, f14, dyn
csrrs x20, fflags, x0
csrrs x13, fflags, x0
li x10, 2415919040
sb x18, 14(x10)
ori x14, x18, 72
fcvt.s.lu f13, x18, rup
csrrs x20, fflags, x0
c.or x13, x14
bclri x20, x14, 55
mulhsu x13, x20, x14
mulhu x14, x19, x13
orc.b x17, x13
fcvt.s.d f18, f19, rmm
csrrs x15, fflags, x0
c.or x13, x14
li x12, 2415919072
amoor.d.aq x19, x17, (x12)
fcvt.s.d f18, f17, dyn
csrrs x16, fflags, x0
li x11, 2415919035
lb x17, 5(x11)
li x12, 2415919049
lb x14, 5(x12)
fcvt.lu.h x18, f14, rdn
csrrs x16, fflags, x0
li x10, 2415919066
sw x15, 9(x10)
czero.nez x18, x16, x17
sllw x17, x13, x15
li x12, 2415919064
c.sd x13, 16(x12)
csrrs x16, fflags, x0
li x11, 2415919049
amomax.d.aqrl x18, x18, (x11)
divw x15, x19, x14
subw x17, x18, x18
slt x20, x19, x18
cpop x14, x18
fclass.s x17, f13
csrrs x16, fflags, x0
li x10, 2415919061
amoswap.w.rl x20, x20, (x10)
sh3add x20, x18, x19
fence.i
fmin.s f18, f13, f20
csrrs x19, fflags, x0
fnmsub.s f18, f15, f16, f17, rup
csrrs x20, fflags, x0
fcvt.s.lu f13, x17, rdn
csrrs x15, fflags, x0
li x10, 2415919054
lwu x19, 7(x10)
mulw x14, x20, x18
sll x19, x18, x17
li x9, 2415919070
amomaxu.d x19, x18, (x9)
fcvt.lu.d x16, f14, dyn
csrrs x18, fflags, x0
fsgnjn.s f14, f17, f14
csrrs x13, fflags, x0
sext.h x13, x13
fmul.s f14, f13, f15, dyn
csrrs x18, fflags, x0
mulh x19, x17, x13
c.addi16sp sp, 16
srl x14, x14, x13
fmadd.s f19, f13, f19, f19, rtz
csrrs x14, fflags, x0
subw x15, x14, x14
csrrs x16, fflags, x0
fcvt.d.lu f17, x15, rmm
csrrs x16, fflags, x0
ctzw x13, x13
csrrs x18, fflags, x0
c.mv x13, x17
fnmadd.d f14, f14, f19, f19, dyn
csrrs x14, fflags, x0
feq.h x13, f18, f15
csrrs x16, fflags, x0
slti x13, x18, -170
and x20, x17, x17
sh2add.uw x18, x14, x18
fcvt.d.lu f17, x14, rtz
csrrs x14, fflags, x0
divw x13, x13, x15
mulw x19, x14, x19
csrrci x16, time, 29
c.addi x13, -12
czero.nez x16, x18, x15
feq.d x17, f13, f20
csrrs x17, fflags, x0
li x11, 2415919041
amoor.w.aq x16, x14, (x11)
csrrs x14, fflags, x0
li x11, 2415919062
lh x17, 15(x11)
li x10, 2415919047
sw x18, 2(x10)
czero.nez x16, x16, x14
csrrs x17, fflags, x0
clzw x20, x14
csrrs x16, fflags, x0
li x9, 2415919054
lw x18, 4(x9)
fcvt.lu.s x19, f17, rdn
csrrs x17, fflags, x0
fmv.d.x f17, x20
csrrs x19, fflags, x0
fence.i
fcvt.wu.d x18, f18, rmm
csrrs x16, fflags, x0
c.addiw x14, -32
csrrs x15, fflags, x0
bseti x15, x19, 52
c.srli x13, 17
c.subw x14, x15
add x13, x17, x18
flt.h x20, f20, f20
csrrs x13, fflags, x0
fcvt.wu.h x15, f16, rne
csrrs x17, fflags, x0
fcvt.wu.h x19, f15, dyn
csrrs x17, fflags, x0
c.addw x15, x15
fsgnjx.s f17, f14, f13
csrrs x16, fflags, x0
rem x13, x17, x18
sh3add.uw x20, x16, x19
sra x19, x16, x14
fmadd.d f17, f19, f19, f17, dyn
csrrs x13, fflags, x0
fcvt.s.w f14, x13, rup
csrrs x17, fflags, x0
bclr x16, x20, x18
or x16, x19, x17
li x11, 2415919067
amoxor.d x13, x14, (x11)
fcvt.s.d f19, f17, dyn
csrrs x16, fflags, x0
c.addw x14, x15
fcvt.d.w f15, x18
csrrs x13, fflags, x0
fence.i
li x2, 2415919067
c.ldsp x14, 16(sp)
fmax.d f15, f18, f17
csrrs x13, fflags, x0
czero.nez x14, x18, x18
csrrs x17, fflags, x0
li x12, 2415919037
c.lw x13, 12(x12)
csrrs x19, fflags, x0
sh1add x20, x14, x13
c.andi x15, 8
fadd.s f20, f20, f15, rtz
csrrs x20, fflags, x0
fdiv.s f14, f16, f19, rdn
csrrs x18, fflags, x0
li x10, 2415919070
amomin.d.aq x18, x15, (x10)
sh1add x14, x13, x18
divuw x19, x13, x14
fle.s x16, f19, f13
csrrs x17, fflags, x0
fence.i
czero.eqz x20, x14, x18
fsgnj.h f19, f13, f16
csrrs x15, fflags, x0
fcvt.l.d x18, f13, dyn
csrrs x20, fflags, x0
slli.uw x19, x15, 5
li x2, 2415919050
c.lwsp x13, 16(sp)
feq.s x13, f14, f16
csrrs x13, fflags, x0
fcvt.h.s f15, f19, dyn
csrrs x15, fflags, x0
csrrs x14, fflags, x0
flt.d x13, f19, f18
csrrs x15, fflags, x0
mul x20, x16, x20
c.srli x15, 53
csrrs x15, fflags, x0
divw x14, x17, x18
li x12, 2415919049
lbu x16, 11(x12)
fdiv.s f20, f19, f17, rup
csrrs x14, fflags, x0
fcvt.lu.s x18, f18, dyn
csrrs x16, fflags, x0
c.addi x15, 9
or x18, x15, x20
fcvt.d.l f18, x19, dyn
csrrs x19, fflags, x0
mul x20, x18, x20
fmv.w.x f15, x17
csrrs x14, fflags, x0
fcvt.h.lu f19, x13, rtz
csrrs x15, fflags, x0
cpopw x20, x13
fsgnj.d f15, f15, f19
csrrs x13, fflags, x0
fdiv.d f17, f17, f19, rne
csrrs x20, fflags, x0
add x18, x13, x16
srlw x17, x14, x19
c.ebreak
sra x18, x16, x20
mul x18, x18, x20
mulh x13, x19, x15
rem x17, x14, x20
cpopw x15, x18
csrrs x17, fflags, x0
fsgnj.d f19, f17, f13
csrrs x20, fflags, x0
c.or x13, x15
fcvt.s.w f15, x18, rne
csrrs x13, fflags, x0
csrrs x20, fflags, x0
ctz x16, x16
c.addw x13, x15
li x2, 2415919042
c.sdsp x16, 8(sp)
fadd.h f15, f20, f18, dyn
csrrs x20, fflags, x0
clz x14, x15
addiw x15, x20, -595
fcvt.d.l f19, x18, dyn
csrrs x15, fflags, x0
fmsub.d f14, f18, f18, f16, dyn
csrrs x13, fflags, x0
li x8, 2415919065
amoand.w x15, x20, (x8)
li x8, 2415919040
fsw f20, 8(x8)
csrrs x16, fflags, x0
fsqrt.h f20, f18, dyn
csrrs x20, fflags, x0
li x9, 2415919070
amominu.w.aqrl x20, x19, (x9)
fle.d x18, f18, f13
csrrs x20, fflags, x0
srli x13, x15, 57
csrrci x15, dscratch0, 9
c.mv x20, x18
mul x13, x19, x14
or x15, x14, x17
li x9, 2415919067
c.ld x13, 8(x9)
max x13, x13, x16
div x14, x20, x15
fsgnjx.d f20, f17, f15
csrrs x17, fflags, x0
li x9, 2415919044
c.sd x15, 16(x9)
slli.uw x14, x17, 53
slli.uw x18, x17, 62
fence.i
c.or x13, x13
fcvt.l.s x20, f15, rtz
csrrs x18, fflags, x0
or x13, x20, x14
clz x15, x19
li x11, 2415919070
ld x13, 2(x11)
csrrs x14, fflags, x0
csrrs x16, fflags, x0
fnmadd.s f18, f17, f17, f20, rup
csrrs x16, fflags, x0
fcvt.s.w f19, x20, rtz
csrrs x14, fflags, x0
fmadd.d f13, f19, f13, f19, rtz
csrrs x15, fflags, x0
fnmsub.h f18, f17, f18, f17, rup
csrrs x18, fflags, x0
fcvt.wu.s x19, f19, dyn
csrrs x16, fflags, x0
czero.eqz x17, x20, x18
czero.eqz x20, x20, x19
flt.h x16, f13, f13
csrrs x15, fflags, x0
c.addi16sp sp, 16
fence.i
fsgnjx.h f18, f15, f13
csrrs x14, fflags, x0
fmadd.s f14, f13, f19, f19, dyn
csrrs x19, fflags, x0
sll x17, x18, x18
fmadd.h f17, f13, f20, f19, rup
csrrs x16, fflags, x0
fnmadd.d f17, f13, f14, f18, rmm
csrrs x15, fflags, x0
fcvt.wu.s x13, f20, rmm
csrrs x17, fflags, x0
slliw x16, x15, 9
li x11, 2415919057
sh x19, 15(x11)
li x10, 2415919066
c.sd x13, 16(x10)
c.lui x18, 0xfffe8
fcvt.s.h f13, f13
csrrs x17, fflags, x0
li x10, 2415919046
sb x14, 0(x10)
zext.h x14, x15
clzw x20, x13
li x8, 2415919055
ld x19, 12(x8)
li x12, 2415919034
flw f18, 2(x12)
csrrs x14, fflags, x0
csrrs x18, fflags, x0
fmadd.s f20, f14, f16, f20, rdn
csrrs x17, fflags, x0
fmsub.h f16, f20, f13, f19, rup
csrrs x20, fflags, x0
fmadd.d f17, f16, f20, f14, dyn
csrrs x13, fflags, x0
fmsub.s f20, f15, f17, f18, rup
csrrs x14, fflags, x0
slli x13, x13, 13
fdiv.d f20, f16, f17, rne
csrrs x19, fflags, x0
li x11, 2415919041
sw x13, 15(x11)
li x11, 2415919045
amomaxu.w x17, x19, (x11)
li x11, 2415919051
c.lw x14, 16(x11)
fsqrt.s f20, f16, rmm
csrrs x20, fflags, x0
c.add x20, x16
fsgnj.h f14, f19, f18
csrrs x13, fflags, x0
czero.eqz x17, x19, x16
fsub.h f14, f14, f13, rtz
csrrs x17, fflags, x0
maxu x18, x16, x16
c.srai x15, 20
flt.d x17, f20, f14
csrrs x15, fflags, x0
fmul.h f19, f19, f19, rdn
csrrs x20, fflags, x0
sext.h x13, x18
ctz x18, x19
fcvt.h.w f17, x18, dyn
csrrs x20, fflags, x0
c.xor x14, x13
fcvt.d.s f20, f17
csrrs x17, fflags, x0
bclr x19, x16, x18
sh2add x15, x16, x19
fence.i
fence.i
csrrs x14, fflags, x0
fmin.d f18, f13, f18
csrrs x17, fflags, x0
c.mv x14, x17
fmv.x.h x18, f18
csrrs x19, fflags, x0
fence.i
subw x14, x15, x16
fcvt.d.h f15, f20
csrrs x14, fflags, x0
fclass.d x15, f16
csrrs x19, fflags, x0
li x9, 2415919069
amomax.d.rl x15, x20, (x9)
fsgnjn.d f14, f20, f13
csrrs x18, fflags, x0
sub x16, x15, x19
csrrs x19, fflags, x0
bexti x16, x14, 63
sraw x14, x15, x16
c.and x14, x14
czero.eqz x17, x16, x18
fcvt.h.lu f18, x14, rdn
csrrs x17, fflags, x0
fcvt.d.h f20, f20
csrrs x14, fflags, x0
csrrsi x15, dscratch0, 12
add x18, x19, x17
fle.d x16, f18, f18
csrrs x17, fflags, x0
bext x16, x15, x13
fmadd.h f14, f18, f17, f14, rne
csrrs x13, fflags, x0
czero.eqz x14, x16, x19
li x12, 2415919068
sw x17, 11(x12)
fmax.d f15, f16, f17
csrrs x18, fflags, x0
fmv.w.x f18, x20
csrrs x17, fflags, x0
fmsub.h f19, f13, f15, f13, rmm
csrrs x17, fflags, x0
csrrs x19, fflags, x0
li x11, 2415919040
fsw f13, 6(x11)
csrrs x18, fflags, x0
fence.i
clzw x18, x18
remw x14, x19, x16
xor x16, x15, x15
divuw x18, x17, x13
fsub.d f16, f16, f15, dyn
csrrs x19, fflags, x0
fcvt.wu.d x20, f18, dyn
csrrs x13, fflags, x0
maxu x17, x20, x16
max x13, x18, x19
fcvt.l.h x19, f16, rdn
csrrs x17, fflags, x0
fsgnjn.d f14, f15, f20
csrrs x18, fflags, x0
sltu x18, x17, x13
li x9, 2415919045
sh x18, 7(x9)
fsqrt.s f16, f16, dyn
csrrs x14, fflags, x0
xori x19, x20, 277
sext.b x19, x13
csrrs x19, fflags, x0
fmv.x.d x18, f17
csrrs x19, fflags, x0
li x9, 2415919047
amomax.d x16, x14, (x9)
fcvt.s.h f17, f17
csrrs x19, fflags, x0
c.slli x14, 60
maxu x18, x16, x15
feq.h x15, f14, f19
csrrs x19, fflags, x0
sh1add.uw x19, x16, x16
li x11, 2415919037
amomaxu.w.rl x17, x15, (x11)
c.nop
srlw x15, x20, x15
mulh x19, x15, x20
fmin.h f16, f15, f17
csrrs x18, fflags, x0
li x9, 2415919039
sb x14, 2(x9)
li x2, 2415919043
c.lwsp x17, 0(sp)
sh1add.uw x15, x17, x15
li x8, 2415919041
amoor.w x18, x19, (x8)
fence.i
sext.h x14, x20
li x10, 2415919066
amomax.d.aqrl x13, x19, (x10)
c.add x19, x14
li x10, 2415919039
lw x20, 9(x10)
ctzw x20, x19
li x12, 2415919061
lb x19, 9(x12)
c.li x16, 29
fcvt.h.lu f18, x17, dyn
csrrs x16, fflags, x0
c.and x13, x14
fcvt.d.lu f17, x20, rtz
csrrs x14, fflags, x0
fsgnj.s f15, f18, f13
csrrs x13, fflags, x0
csrrs x18, fflags, x0
fclass.h x20, f15
csrrs x20, fflags, x0
li x9, 2415919064
amoswap.d.aq x20, x14, (x9)
rem x19, x16, x20
or x13, x14, x17
fle.d x14, f20, f19
csrrs x16, fflags, x0
clzw x20, x20
fcvt.h.s f16, f18, rtz
csrrs x17, fflags, x0
fdiv.d f16, f18, f16, rne
csrrs x14, fflags, x0
fmv.w.x f18, x20
csrrs x13, fflags, x0
c.xor x14, x15
xori x18, x20, -425
fclass.h x17, f18
csrrs x19, fflags, x0
bclri x13, x19, 22
flt.s x13, f19, f19
csrrs x13, fflags, x0
mulw x13, x20, x13
czero.eqz x18, x17, x14
fmadd.d f18, f14, f13, f19, rup
csrrs x20, fflags, x0
fcvt.d.s f13, f16
csrrs x13, fflags, x0
csrrs x17, fflags, x0
li x2, 2415919061
c.swsp x20, 16(sp)
li x9, 2415919035
amoand.d.aq x14, x18, (x9)
rem x14, x17, x19

exit:
    li t0, 1 # report success
    la t1, tohost
    sd t0, 0(t1)
1:
    j 1b

    .align 2
trap_handler:
    csrr t0, mepc # faulting PC
    csrr t1, mcause # trap cause
    csrr t4, mtval

    slli t5, t1, 1 # strip interrupt bit
    srli t1, t5, 1

    li t2, 2 # default length assumes compressed
    li t3, 2 # illegal instruction -> mtval holds encoding
    beq t1, t3, use_mtval
    li t3, 1 # instruction access fault
    beq t1, t3, update_mepc
    li t3, 12 # instruction page fault
    beq t1, t3, update_mepc

    lhu t4, 0(t0)
    j decode_length

use_mtval:
    j decode_length

decode_length:
    andi t4, t4, 3
    li t3, 3
    bne t4, t3, compressed_len
    li t2, 4 # standard 32-bit instruction
    j update_mepc

compressed_len:
    li t2, 2 # compressed instruction

update_mepc:
    add t0, t0, t2 # skip offending instruction
    csrw mepc, t0
    csrw mcause, x0
    csrw mtval, x0
    mret

    .section .tohost,"aw",@progbits
    .align 6
    .globl tohost
    .globl fromhost
tohost:
    .dword 0
fromhost:
    .dword 0
