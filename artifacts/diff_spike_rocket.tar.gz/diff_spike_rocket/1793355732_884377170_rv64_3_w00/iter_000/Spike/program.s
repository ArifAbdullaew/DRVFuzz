# 0 "/home/fuzz/runs/diff_spike_rocket/1793355732_884377170_rv64_3_w00/iter_000/Spike/program.S"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/home/fuzz/runs/diff_spike_rocket/1793355732_884377170_rv64_3_w00/iter_000/Spike/program.S"
    .section .text
    .globl _start

_start:
    la t0, trap_handler
    csrw mtvec, t0

    csrr t0, mstatus
    li t1, 0x00003000 # set FS field to Dirty (0b11) so FP regs usable
    or t0, t0, t1
    csrw mstatus, t0
    csrw fcsr, x0 # clear floating-point status

    # Relax PMP: one NAPOT entry covers the full address space to allow S-mode fetch/load/store
    li t0, -1
    csrw pmpaddr0, t0
    li t0, 0x1f # R|W|X | A=NAPOT
    csrw pmpcfg0, t0

    j user_code

user_code:
li x13, 0xfc03fd1b6ff6a53b
li x14, 0x7cf41092c2ae228b
li x15, 0x95863f22335e72e5
li x16, 0x1d2a7d1d7a0e8e30
li x17, 0xed9eb69254a45e6e
li x18, 0x3e5bb2958cd22bc4
li x19, 0x70f543dc2bd19172
li x20, 0xf15f5fceea8a6a4d
li x8, 0x2012456da9a4c9ad
fmv.d.x f13, x8
li x8, 0xeb65d86137c4c2f6
fmv.d.x f14, x8
li x8, 0x952a080a44374d3d
fmv.d.x f15, x8
li x8, 0x750477f65c464926
fmv.d.x f16, x8
li x8, 0xc11b139c317ec7c6
fmv.d.x f17, x8
li x8, 0x2bce2f6cff8ad606
fmv.d.x f18, x8
li x8, 0x88afa51ef76c2611
fmv.d.x f19, x8
li x8, 0xc8ee0345d4a456d
fmv.d.x f20, x8
li x9, 0x8fffffb8
li x10, 0x3828dac8d8ea5595
sd x10, 0(x9)
li x10, 0xc6be89c9c7abf59a
sd x10, 8(x9)
li x10, 0x7372ca154cb21c42
sd x10, 16(x9)
li x10, 0x658520fdf6368713
sd x10, 24(x9)
li x10, 0x619bc07180ad57cc
sd x10, 32(x9)
li x10, 0x297cfbddd10d2cf6
sd x10, 40(x9)
li x10, 0x33fafa243b7957c
sd x10, 48(x9)
li x10, 0xca8c7b1f0af38f55
sd x10, 56(x9)
li x8, 0
li x9, 0
li x10, 0
li x11, 0
li x12, 0
fclass.d x20, f13
csrrs x15, fflags, x0
fmv.h.x f14, x14
csrrs x20, fflags, x0
andi x17, x19, -1654
c.li x20, 3
li x9, 2415919059
ld x19, 1(x9)
binv x14, x18, x20
csrrsi x18, frm, 7
fcvt.l.h x20, f16, rtz
csrrs x16, fflags, x0
fdiv.s f20, f13, f19, rdn
csrrs x13, fflags, x0
sraw x20, x17, x13
fcvt.h.d f16, f19, dyn
csrrs x16, fflags, x0
c.slli x14, 59
fmv.d.x f18, x18
csrrs x16, fflags, x0
slliw x16, x17, 22
fmin.h f13, f15, f15
csrrs x13, fflags, x0
fle.h x14, f19, f14
csrrs x17, fflags, x0
cpopw x15, x18
li x8, 2415919053
amoand.w x17, x13, (x8)
fmv.d.x f14, x20
csrrs x20, fflags, x0
addiw x16, x16, -105
mulh x13, x16, x15
clz x14, x14
c.and x13, x14
fcvt.l.h x15, f18, dyn
csrrs x20, fflags, x0
li x8, 2415919064
amominu.w x20, x17, (x8)
czero.nez x13, x19, x18
fmadd.s f14, f19, f19, f18, rdn
csrrs x19, fflags, x0
fmin.d f14, f19, f13
csrrs x15, fflags, x0
feq.d x13, f19, f14
csrrs x19, fflags, x0
fle.s x17, f13, f15
csrrs x14, fflags, x0
bclri x20, x15, 15
slti x13, x13, 328
li x11, 2415919056
lbu x13, 3(x11)
li x2, 2415919057
c.swsp x17, 12(sp)
ori x17, x20, -1029
sub x16, x20, x20
fle.d x16, f13, f17
csrrs x18, fflags, x0
li x8, 2415919056
lh x17, 8(x8)
fence.i
fmin.d f17, f18, f13
csrrs x20, fflags, x0
c.slli x16, 50
slli x13, x17, 22
fltq.h x13, f14, f17
csrrs x20, fflags, x0
fmsub.s f16, f19, f19, f16, rmm
csrrs x17, fflags, x0
and x19, x16, x18
remu x13, x20, x20
sltiu x14, x18, 885
li x11, 2415919043
lw x15, 11(x11)
zext.h x14, x20
bexti x19, x15, 39
li x8, 2415919038
sh x14, 8(x8)
fence.tso
csrrwi x18, mscratch, 3
fence.i
fcvt.h.d f19, f18, rdn
csrrs x16, fflags, x0
li x12, 2415919058
amomin.d.rl x18, x15, (x12)
fsub.s f18, f19, f18, rtz
csrrs x14, fflags, x0
c.subw x14, x14
addw x20, x14, x14
fcvtmod.w.d x17, f18, rtz
csrrs x17, fflags, x0
li x9, 2415919057
flh f16, 16(x9)
csrrs x19, fflags, x0
fence orw, io
fcvt.s.l f13, x20, rne
csrrs x16, fflags, x0
fmaxm.d f17, f17, f14
csrrs x20, fflags, x0
bext x13, x16, x19
li x8, 2415919070
lbu x15, 10(x8)
fmax.d f20, f13, f16
csrrs x17, fflags, x0
fsgnjn.h f13, f18, f15
csrrs x17, fflags, x0
li x11, 2415919038
amominu.w.rl x20, x14, (x11)
bexti x13, x17, 26
bset x18, x15, x16
fmv.x.w x14, f13
csrrs x13, fflags, x0
sub x16, x18, x13
czero.eqz x13, x16, x19
fsgnjx.s f14, f15, f13
csrrs x15, fflags, x0
li x9, 2415919054
fsw f16, 6(x9)
csrrs x16, fflags, x0
fdiv.h f15, f16, f20, dyn
csrrs x14, fflags, x0
xori x17, x17, -563
div x20, x16, x13
li x8, 2415919063
fsh f16, 8(x8)
csrrs x20, fflags, x0
fcvt.s.l f13, x17, rmm
csrrs x18, fflags, x0
li x13, 1645271088393713500
csrrs x17, cycle, x13
li x8, 2415919037
fsd f14, 1(x8)
csrrs x17, fflags, x0
c.addiw x15, -4
fsqrt.d f16, f13, rne
csrrs x20, fflags, x0
fcvt.s.d f15, f18, rdn
csrrs x15, fflags, x0
fence.i
fmin.d f19, f17, f17
csrrs x20, fflags, x0
ctzw x18, x14
li x8, 2415919043
fld f17, 1(x8)
csrrs x20, fflags, x0
fmin.d f16, f16, f20
csrrs x14, fflags, x0
fence ior, iow
fcvt.h.w f16, x17, rmm
csrrs x20, fflags, x0
fcvt.wu.h x14, f16, dyn
csrrs x18, fflags, x0
li x12, 2415919047
amoadd.d.rl x17, x20, (x12)
maxu x20, x14, x18
li x11, 2415919044
lw x17, 4(x11)
li x10, 2415919064
amoor.w x15, x20, (x10)
or x18, x15, x20
binv x17, x20, x15
fdiv.d f15, f20, f16, rdn
csrrs x13, fflags, x0
fsgnjn.d f20, f13, f13
csrrs x19, fflags, x0
fleq.h x18, f19, f15
csrrs x17, fflags, x0
fmadd.d f17, f17, f19, f20, dyn
csrrs x19, fflags, x0
sll x14, x17, x14
li x12, 2415919045
fld f17, 15(x12)
csrrs x15, fflags, x0
li x12, 2415919054
fsh f18, 4(x12)
csrrs x20, fflags, x0
or x15, x14, x17
add.uw x19, x13, x17
li x11, 2415919053
c.sw x13, 12(x11)
fcvt.lu.s x16, f15, rdn
csrrs x16, fflags, x0
sra x19, x17, x13
slt x15, x14, x17
sltu x16, x17, x13
addiw x17, x13, -640
fmin.d f18, f20, f16
csrrs x15, fflags, x0
fmin.d f17, f15, f20
csrrs x19, fflags, x0
li x10, 2415919034
c.ld x14, 8(x10)
fmax.h f14, f14, f16
csrrs x13, fflags, x0
sext.b x14, x16
fcvtmod.w.d x17, f16, rtz
csrrs x20, fflags, x0
c.add x13, x18
sraw x20, x18, x18
fli.h f18, min
csrrs x19, fflags, x0
fsgnjx.s f19, f13, f17
csrrs x19, fflags, x0
c.or x15, x15
fle.s x16, f18, f13
csrrs x19, fflags, x0
li x10, 2415919042
amoand.d.aqrl x20, x19, (x10)
remw x18, x20, x18
fsgnjx.s f18, f14, f20
csrrs x19, fflags, x0
add.uw x16, x17, x19
divuw x17, x14, x18
fsgnjx.h f16, f20, f15
csrrs x17, fflags, x0
and x20, x15, x15
flt.d x14, f18, f18
csrrs x20, fflags, x0
li x2, 2415919039
c.lwsp x16, 16(sp)
divu x17, x19, x13
addw x19, x19, x15
bset x16, x14, x18
csrrwi x15, mtval2, 19
fcvt.d.w f14, x17
csrrs x15, fflags, x0
bexti x14, x19, 24
srliw x14, x15, 13
fsgnjx.h f20, f14, f15
csrrs x18, fflags, x0
feq.s x20, f15, f16
csrrs x14, fflags, x0
fnmadd.s f20, f17, f17, f20, dyn
csrrs x19, fflags, x0
fence.i
fli.s f16, 0x1.0p-7
csrrs x19, fflags, x0
li x16, -1058364974767095391
csrrc x18, mtval, x16
li x9, 2415919039
amoswap.w x16, x20, (x9)
fsqrt.d f18, f17, rtz
csrrs x14, fflags, x0
fclass.s x20, f20
csrrs x13, fflags, x0
fminm.s f17, f18, f15
csrrs x16, fflags, x0
fclass.d x13, f19
csrrs x19, fflags, x0
fmax.s f14, f13, f15
csrrs x15, fflags, x0
fmv.x.h x17, f14
csrrs x15, fflags, x0
sub x15, x14, x18
li x8, 2415919032
amoxor.w.aq x16, x15, (x8)
fmsub.h f19, f14, f16, f17, rne
csrrs x20, fflags, x0
fsqrt.s f20, f19, dyn
csrrs x19, fflags, x0
fmv.x.w x15, f20
csrrs x20, fflags, x0
fmin.d f19, f14, f17
csrrs x20, fflags, x0
divuw x19, x19, x17
fsgnjx.s f14, f20, f14
csrrs x18, fflags, x0
fmsub.d f13, f16, f13, f14, rne
csrrs x14, fflags, x0
fltq.s x13, f16, f14
csrrs x20, fflags, x0
slliw x16, x19, 0
li x8, 2415919041
amoxor.w.aqrl x20, x15, (x8)
addw x15, x15, x14
fdiv.d f14, f18, f17, dyn
csrrs x13, fflags, x0
c.lui x20, 0xffff1
fmv.w.x f15, x20
csrrs x20, fflags, x0
fmin.s f13, f13, f18
csrrs x16, fflags, x0
c.srai x13, 36
fcvt.s.w f18, x16, rne
csrrs x16, fflags, x0
fcvt.w.s x15, f16, rmm
csrrs x16, fflags, x0
li x9, 2415919039
amoor.d.aq x17, x20, (x9)
fdiv.s f15, f19, f14, rne
csrrs x17, fflags, x0
fence.i
fsqrt.d f16, f15, dyn
csrrs x18, fflags, x0
fmaxm.h f18, f20, f18
csrrs x16, fflags, x0
li x11, 2415919033
amoor.w.aqrl x18, x20, (x11)
c.addi x15, 22
c.sub x15, x15
li x12, 2415919040
c.sw x13, 12(x12)
li x11, 2415919071
amoand.w.aq x19, x13, (x11)
bexti x14, x19, 7
c.addi16sp sp, 16
fdiv.d f18, f20, f14, dyn
csrrs x20, fflags, x0
li x8, 2415919072
fsh f19, 16(x8)
csrrs x13, fflags, x0
fcvt.h.wu f13, x19, dyn
csrrs x20, fflags, x0
li x10, 2415919052
amomaxu.w x13, x14, (x10)
fsqrt.h f15, f18, rup
csrrs x19, fflags, x0
fmul.s f18, f19, f20, dyn
csrrs x15, fflags, x0
fminm.h f14, f17, f19
csrrs x20, fflags, x0
flt.h x15, f20, f16
csrrs x17, fflags, x0
mulhu x13, x14, x14
fcvt.lu.d x18, f19, rmm
csrrs x17, fflags, x0
fmax.d f18, f17, f13
csrrs x20, fflags, x0
rem x16, x14, x18
fltq.d x19, f17, f16
csrrs x19, fflags, x0
fleq.d x17, f19, f19
csrrs x15, fflags, x0
fmv.x.w x18, f18
csrrs x15, fflags, x0
zext.h x18, x19
fadd.d f18, f19, f18, dyn
csrrs x18, fflags, x0
froundnx.s f19, f13, dyn
csrrs x19, fflags, x0
fnmsub.d f17, f18, f13, f17, rne
csrrs x18, fflags, x0
c.srai x13, 47
ctzw x13, x20
c.addiw x20, -4
srl x15, x17, x18
fcvt.h.l f17, x15, rdn
csrrs x16, fflags, x0
or x16, x14, x15
srli x17, x17, 59
slli x14, x18, 14
or x13, x15, x15
li x10, 2415919033
lhu x14, 4(x10)
sraiw x20, x17, 14
fcvt.l.h x16, f17, dyn
csrrs x14, fflags, x0
fle.d x16, f15, f16
csrrs x13, fflags, x0
slli.uw x20, x13, 57
li x9, 2415919063
lhu x14, 4(x9)
li x2, 2415919063
c.swsp x18, 0(sp)
froundnx.d f15, f18, dyn
csrrs x17, fflags, x0
fcvt.h.w f13, x14, rup
csrrs x17, fflags, x0
minu x13, x18, x20
fcvt.h.w f14, x16, dyn
csrrs x13, fflags, x0
fcvt.h.wu f20, x13, rne
csrrs x15, fflags, x0
fcvt.s.d f16, f20, dyn
csrrs x15, fflags, x0
fle.s x18, f15, f16
csrrs x19, fflags, x0
c.add x15, x13
c.or x13, x15
ori x19, x13, -1230
clz x19, x13
fdiv.s f20, f16, f15, rne
csrrs x20, fflags, x0
fsgnj.h f19, f19, f13
csrrs x18, fflags, x0
fsgnjx.d f17, f19, f16
csrrs x18, fflags, x0
fcvt.wu.h x17, f14, rne
csrrs x17, fflags, x0
czero.eqz x13, x17, x16
li x18, 2397322670677851205
csrrw x13, mtval, x18
c.xor x14, x13
c.addiw x15, 29
minu x20, x15, x19
li x8, 2415919071
lh x13, 6(x8)
li x8, 2415919041
fsw f14, 8(x8)
csrrs x17, fflags, x0
li x8, 2415919063
sb x19, 8(x8)
c.andi x15, 5
c.addi16sp sp, 16
froundnx.s f17, f20, rne
csrrs x14, fflags, x0
lui x14, 401408
binvi x20, x17, 36
li x10, 2415919045
amoxor.w.aqrl x13, x13, (x10)
li x9, 2415919039
sd x14, 0(x9)
fence.i
fsub.h f19, f19, f19, dyn
csrrs x20, fflags, x0
li x11, 2415919067
amoadd.d.aqrl x14, x19, (x11)
csrrci x14, frm, 6
clz x20, x20
fmsub.d f17, f19, f19, f17, rdn
csrrs x16, fflags, x0
fsub.h f19, f17, f19, rup
csrrs x17, fflags, x0
froundnx.h f20, f15, rup
csrrs x13, fflags, x0
fmv.x.h x13, f19
csrrs x13, fflags, x0
fcvt.l.s x18, f18, dyn
csrrs x15, fflags, x0
fltq.s x20, f17, f16
csrrs x19, fflags, x0
fle.s x15, f19, f17
csrrs x19, fflags, x0
li x8, 2415919064
amoxor.d.rl x15, x20, (x8)
fadd.d f20, f17, f18, dyn
csrrs x16, fflags, x0
fcvt.lu.d x15, f13, dyn
csrrs x18, fflags, x0
fence.i
fminm.h f18, f18, f13
csrrs x17, fflags, x0
fclass.h x17, f15
csrrs x14, fflags, x0
froundnx.s f16, f13, rmm
csrrs x18, fflags, x0
slti x14, x14, 771
fcvtmod.w.d x13, f13, rtz
csrrs x15, fflags, x0
li x10, 2415919032
amoadd.d.aq x19, x17, (x10)
fclass.h x17, f14
csrrs x14, fflags, x0
froundnx.s f16, f14, rne
csrrs x13, fflags, x0
fdiv.h f17, f15, f17, rdn
csrrs x18, fflags, x0
sext.b x14, x13
slliw x18, x16, 4
remw x17, x13, x17
addi x16, x13, -1450
fsgnj.h f14, f13, f18
csrrs x19, fflags, x0
czero.eqz x18, x17, x18
fnmadd.d f19, f13, f13, f14, rmm
csrrs x15, fflags, x0
andi x19, x13, -469
fminm.d f14, f14, f20
csrrs x16, fflags, x0
li x8, 2415919042
lh x18, 6(x8)
li x11, 2415919041
c.ld x13, 8(x11)
lui x14, 364544
czero.nez x17, x17, x15
sh1add.uw x15, x16, x18
fleq.d x17, f13, f13
csrrs x16, fflags, x0
li x10, 2415919055
amoswap.w.aq x20, x13, (x10)
fcvt.wu.h x16, f18, rtz
csrrs x20, fflags, x0
sltu x18, x17, x17
remu x13, x19, x20
clz x14, x18
czero.eqz x14, x13, x19
fcvt.h.wu f15, x18, rup
csrrs x16, fflags, x0
div x14, x14, x17
fltq.h x18, f19, f17
csrrs x14, fflags, x0
fcvt.l.d x18, f19, dyn
csrrs x15, fflags, x0
sh1add x20, x15, x13
li x16, -4686203871370916751
csrrw x20, dscratch1, x16
sext.b x13, x19
fcvt.h.s f20, f13, dyn
csrrs x18, fflags, x0
fcvt.h.s f14, f18, dyn
csrrs x20, fflags, x0
czero.nez x19, x14, x15
bseti x16, x17, 52
sltiu x17, x14, 587
fmv.x.w x18, f13
csrrs x16, fflags, x0
fnmsub.h f13, f14, f20, f19, rmm
csrrs x14, fflags, x0
li x9, 2415919042
fld f16, 8(x9)
csrrs x14, fflags, x0
c.or x14, x15
li x15, 0
csrrw x13, mcause, x15
fsgnjx.d f16, f20, f17
csrrs x19, fflags, x0
li x11, 2415919050
fsw f14, 0(x11)
csrrs x15, fflags, x0
fsgnjn.h f13, f20, f15
csrrs x13, fflags, x0
fcvt.s.d f20, f19, rne
csrrs x19, fflags, x0
fcvt.d.wu f15, x19
csrrs x16, fflags, x0
fcvt.s.d f15, f17, rtz
csrrs x13, fflags, x0
fli.s f15, 0x1.0p-4
csrrs x15, fflags, x0
fcvt.s.wu f16, x20, dyn
csrrs x18, fflags, x0
sh1add x18, x18, x14
sub x17, x20, x15
li x12, 2415919048
fld f16, 4(x12)
csrrs x13, fflags, x0
li x8, 2415919070
amoswap.w.aqrl x17, x13, (x8)
c.add x17, x13
fcvt.d.w f14, x19
csrrs x14, fflags, x0
fcvt.s.h f16, f20
csrrs x16, fflags, x0
divuw x14, x14, x16
czero.eqz x19, x15, x18
fadd.d f15, f15, f13, rtz
csrrs x18, fflags, x0
flt.s x20, f14, f16
csrrs x19, fflags, x0
fcvt.w.s x16, f14, dyn
csrrs x15, fflags, x0
sh2add.uw x13, x14, x14
fsgnjn.d f15, f17, f16
csrrs x15, fflags, x0
fclass.h x18, f14
csrrs x14, fflags, x0
fence ior, iw
li x2, 2415919041
c.swsp x19, 16(sp)
cpopw x15, x15
fclass.s x17, f15
csrrs x15, fflags, x0
li x10, 2415919062
amoand.d.rl x13, x18, (x10)
fsqrt.s f13, f18, rup
csrrs x14, fflags, x0
sext.h x17, x15
fli.s f13, 0x1.0p-16
csrrs x19, fflags, x0
fmsub.d f19, f16, f19, f18, rdn
csrrs x17, fflags, x0
lui x17, 753664
fmsub.s f19, f17, f14, f16, rmm
csrrs x20, fflags, x0
fminm.h f14, f19, f20
csrrs x15, fflags, x0
fcvt.w.s x14, f19, dyn
csrrs x13, fflags, x0
li x10, 2415919063
lb x17, 1(x10)
fcvt.d.w f13, x20
csrrs x19, fflags, x0
andi x20, x14, -559
fmaxm.d f20, f20, f13
csrrs x14, fflags, x0
remu x17, x14, x14
bclr x15, x18, x14
li x12, 2415919065
amomin.w.aq x18, x20, (x12)
fadd.d f19, f19, f18, rdn
csrrs x19, fflags, x0
srl x15, x14, x17
li x10, 2415919035
amomax.w.aq x17, x20, (x10)
c.srli x13, 62
c.add x15, x17
li x10, 2415919042
sb x16, 5(x10)
fence.i
li x8, 2415919048
c.lw x14, 8(x8)
sh1add x19, x17, x16
fcvt.d.l f13, x19, rup
csrrs x13, fflags, x0
c.ebreak
fadd.h f17, f14, f15, dyn
csrrs x17, fflags, x0
fcvt.d.lu f20, x14, dyn
csrrs x16, fflags, x0
fcvt.h.l f20, x19, rne
csrrs x14, fflags, x0
divw x14, x13, x16
bext x13, x13, x14
zext.h x15, x13
fmsub.h f17, f19, f16, f20, rmm
csrrs x13, fflags, x0
fcvt.s.h f19, f15
csrrs x17, fflags, x0
fdiv.s f18, f14, f15, dyn
csrrs x20, fflags, x0
li x9, 2415919058
lhu x16, 16(x9)
fmul.d f13, f20, f18, rne
csrrs x17, fflags, x0
fadd.h f14, f17, f15, rne
csrrs x17, fflags, x0
add x18, x13, x16
fcvt.h.w f20, x19, rne
csrrs x14, fflags, x0
bext x15, x18, x13
czero.nez x19, x17, x16
li x9, 2415919058
sw x20, 11(x9)
fmin.s f19, f18, f17
csrrs x18, fflags, x0
sraw x16, x18, x19
sll x16, x17, x13
remu x19, x16, x17
fcvt.d.w f13, x15
csrrs x16, fflags, x0
mulhu x19, x17, x20
clz x20, x17
li x10, 2415919056
fsd f19, 4(x10)
csrrs x20, fflags, x0
li x2, 2415919032
c.sdsp x18, 0(sp)
froundnx.h f15, f20, rdn
csrrs x17, fflags, x0
li x12, 2415919047
fsw f15, 8(x12)
csrrs x17, fflags, x0
divw x16, x15, x19
srl x18, x14, x15
fcvt.d.wu f20, x16
csrrs x17, fflags, x0
fmax.d f17, f16, f13
csrrs x19, fflags, x0
fmv.d.x f20, x14
csrrs x18, fflags, x0
li x8, 2415919053
amoand.w.rl x14, x18, (x8)
c.addi x17, 3
mulw x16, x20, x15
li x11, 2415919069
amoor.w.aq x18, x16, (x11)
fmul.s f17, f17, f14, rmm
csrrs x17, fflags, x0
fsgnjx.d f16, f15, f19
csrrs x16, fflags, x0
fdiv.h f16, f19, f20, dyn
csrrs x18, fflags, x0
fcvt.w.d x18, f18, rup
csrrs x17, fflags, x0
min x19, x20, x16
fcvt.h.s f16, f16, dyn
csrrs x19, fflags, x0
li x11, 2415919035
c.ld x14, 0(x11)
fcvt.l.s x14, f19, rne
csrrs x18, fflags, x0
mulhsu x15, x18, x15
bexti x17, x18, 27
sh2add x15, x15, x19
fmv.h.x f15, x13
csrrs x15, fflags, x0
c.subw x15, x14
fsgnjx.d f17, f13, f13
csrrs x19, fflags, x0
li x2, 2415919055
c.swsp x13, 12(sp)
slliw x18, x15, 25
slti x17, x15, -1020
sraw x15, x19, x20
li x9, 2415919045
lhu x20, 11(x9)
divw x14, x15, x14
li x9, 2415919067
c.sd x14, 16(x9)
sext.b x19, x15
orc.b x14, x18
fence.i
clzw x13, x13
srliw x20, x16, 25
fclass.s x16, f19
csrrs x18, fflags, x0
fence w, ow
c.sub x13, x14
fcvt.h.d f19, f15, rdn
csrrs x15, fflags, x0
fdiv.h f14, f18, f16, rne
csrrs x13, fflags, x0
li x8, 2415919044
amomaxu.d.rl x18, x13, (x8)
feq.s x13, f16, f18
csrrs x17, fflags, x0
fcvt.lu.h x13, f15, rmm
csrrs x13, fflags, x0
fcvt.d.s f19, f17
csrrs x13, fflags, x0
ctz x17, x20
fence.i
bclr x18, x14, x14
fmin.s f17, f14, f14
csrrs x13, fflags, x0
li x8, 2415919072
c.lw x15, 8(x8)
c.slli x20, 58
add.uw x19, x18, x18
srli x18, x18, 22
li x9, 2415919054
fld f15, 13(x9)
csrrs x20, fflags, x0
li x10, 2415919043
ld x15, 1(x10)
froundnx.h f13, f14, dyn
csrrs x17, fflags, x0
fsgnjn.d f14, f14, f20
csrrs x19, fflags, x0
fsgnjx.h f14, f15, f13
csrrs x20, fflags, x0
fmaxm.h f13, f15, f17
csrrs x20, fflags, x0
slli.uw x16, x15, 23
fcvt.l.d x17, f13, dyn
csrrs x13, fflags, x0
fli.s f13, -1.0
csrrs x14, fflags, x0
czero.eqz x20, x18, x14
fleq.h x14, f14, f17
csrrs x14, fflags, x0
c.sub x14, x14
li x9, 2415919053
amoadd.d.aqrl x19, x14, (x9)
fcvt.d.wu f19, x16
csrrs x17, fflags, x0
fsgnjx.s f20, f17, f16
csrrs x14, fflags, x0
ctz x17, x14
fli.h f18, 3.0
csrrs x17, fflags, x0
fence.i
slli x19, x15, 23
sub x13, x17, x15
fmin.h f16, f20, f19
csrrs x18, fflags, x0
c.ebreak
li x11, 2415919035
lwu x13, 12(x11)
li x12, 2415919070
flh f13, 6(x12)
csrrs x19, fflags, x0
fmv.x.d x20, f13
csrrs x17, fflags, x0
fcvt.d.h f13, f17
csrrs x17, fflags, x0
sh3add.uw x16, x13, x15
c.or x15, x14
fsgnjn.s f19, f18, f15
csrrs x19, fflags, x0
li x9, 2415919065
sh x14, 11(x9)
li x9, 2415919054
amoadd.d.aq x18, x16, (x9)
li x12, 2415919072
sb x18, 16(x12)
flt.h x17, f16, f18
csrrs x18, fflags, x0
fmax.h f15, f13, f19
csrrs x19, fflags, x0
czero.nez x13, x19, x17
c.slli x16, 52
fmadd.d f17, f18, f14, f13, rtz
csrrs x19, fflags, x0
fcvt.s.wu f17, x16, rtz
csrrs x19, fflags, x0
fcvt.lu.h x18, f16, dyn
csrrs x17, fflags, x0
remw x18, x16, x19
bexti x17, x17, 47
fround.s f18, f18, dyn
csrrs x14, fflags, x0
c.lui x16, 0xffff7
fmadd.s f16, f18, f15, f17, dyn
csrrs x16, fflags, x0
li x8, 2415919051
amomin.d.aq x13, x18, (x8)
li x9, 2415919053
amoand.w.rl x15, x15, (x9)
czero.eqz x17, x17, x19
bclr x17, x20, x18
li x8, 2415919055
fsw f15, 1(x8)
csrrs x18, fflags, x0
fltq.d x16, f20, f17
csrrs x19, fflags, x0
slt x16, x15, x20
remw x19, x17, x19
srli x17, x20, 4
zext.h x17, x20
fmaxm.d f19, f13, f13
csrrs x19, fflags, x0
czero.eqz x13, x16, x16
li x2, 2415919038
c.swsp x16, 8(sp)
li x10, 2415919051
sw x16, 6(x10)
c.addi16sp sp, 16
li x12, 2415919051
lw x17, 14(x12)
fcvt.h.wu f18, x16, dyn
csrrs x17, fflags, x0
mul x14, x19, x17
fclass.h x13, f18
csrrs x17, fflags, x0
li x10, 2415919063
amoxor.d.aqrl x17, x14, (x10)
li x2, 2415919063
c.lwsp x15, 0(sp)
fcvtmod.w.d x13, f15, rtz
csrrs x20, fflags, x0
fcvtmod.w.d x19, f16, rtz
csrrs x20, fflags, x0
fence.i
fltq.s x18, f17, f16
csrrs x14, fflags, x0
li x8, 2415919042
amominu.d.aq x14, x18, (x8)
fsgnjx.h f18, f15, f15
csrrs x19, fflags, x0
sra x18, x18, x14
fcvt.h.s f17, f18, rmm
csrrs x15, fflags, x0
fmsub.h f18, f15, f17, f14, dyn
csrrs x20, fflags, x0
c.srli x14, 15
fcvt.s.w f17, x13, dyn
csrrs x15, fflags, x0
li x10, 2415919037
sw x18, 8(x10)
czero.nez x13, x16, x19
c.addiw x19, -13
fmul.h f17, f19, f16, dyn
csrrs x19, fflags, x0
fmax.d f13, f20, f16
csrrs x18, fflags, x0
fmv.x.h x16, f17
csrrs x18, fflags, x0
fcvt.h.wu f17, x14, dyn
csrrs x16, fflags, x0
sll x20, x16, x15
c.addw x13, x13
remuw x13, x18, x20
li x8, 2415919062
lwu x17, 8(x8)
fcvt.s.h f18, f18
csrrs x13, fflags, x0
sh2add.uw x18, x20, x18
fcvt.d.h f18, f13
csrrs x16, fflags, x0
fsub.s f17, f19, f16, rup
csrrs x16, fflags, x0
fnmsub.h f19, f17, f16, f13, rup
csrrs x20, fflags, x0
fsgnjx.h f13, f15, f17
csrrs x13, fflags, x0
c.li x17, -32
fence.i
fminm.d f16, f14, f16
csrrs x19, fflags, x0
fence.i
fmv.h.x f16, x20
csrrs x18, fflags, x0
cpopw x18, x18
fmin.d f20, f14, f18
csrrs x16, fflags, x0
fcvt.w.h x13, f18, rdn
csrrs x19, fflags, x0
fltq.d x20, f18, f17
csrrs x19, fflags, x0
li x12, 2415919064
flw f15, 15(x12)
csrrs x14, fflags, x0
fcvt.wu.s x14, f13, dyn
csrrs x17, fflags, x0
sext.h x15, x13
li x11, 2415919063
amomin.d.aqrl x17, x17, (x11)
addw x19, x17, x19
c.ebreak
fmax.h f17, f16, f13
csrrs x19, fflags, x0
froundnx.s f19, f19, rup
csrrs x18, fflags, x0
czero.nez x13, x17, x14
fmsub.h f15, f15, f13, f14, dyn
csrrs x17, fflags, x0
rem x15, x20, x18
li x10, 2415919059
fsw f18, 2(x10)
csrrs x17, fflags, x0
li x11, 2415919072
amomin.d.aq x20, x16, (x11)
fnmsub.s f13, f13, f19, f14, rne
csrrs x20, fflags, x0
mulw x18, x16, x16
clz x20, x19
fle.s x18, f18, f13
csrrs x20, fflags, x0
sll x15, x17, x18
fmadd.d f18, f20, f17, f19, rup
csrrs x14, fflags, x0
fcvt.h.s f19, f19, rdn
csrrs x20, fflags, x0
fence.i
fnmadd.d f16, f19, f17, f14, dyn
csrrs x13, fflags, x0
li x10, 2415919054
amoxor.d.aq x17, x15, (x10)
minu x19, x16, x14
li x12, 2415919052
sd x16, 6(x12)
fcvt.h.l f18, x14, rmm
csrrs x13, fflags, x0
fcvt.wu.s x20, f18, dyn
csrrs x18, fflags, x0
c.andi x13, 14
c.subw x15, x15
li x2, 2415919057
c.swsp x18, 0(sp)
li x11, 2415919061
fsd f13, 12(x11)
csrrs x17, fflags, x0
andi x19, x13, -1516
fsgnj.d f14, f17, f17
csrrs x17, fflags, x0
froundnx.d f20, f14, dyn
csrrs x15, fflags, x0
czero.nez x18, x19, x15
li x11, 2415919039
c.sd x13, 0(x11)
min x13, x14, x20
fence.i
fminm.d f16, f18, f16
csrrs x13, fflags, x0
feq.s x17, f16, f20
csrrs x20, fflags, x0
add.uw x15, x20, x13
add.uw x14, x16, x19
c.srli x14, 9
bclr x17, x20, x17
slt x17, x13, x14
li x12, 2415919041
ld x18, 12(x12)
divu x13, x19, x15
fcvt.d.h f16, f14
csrrs x15, fflags, x0
minu x13, x15, x20
fence.i
c.addi16sp sp, 16
li x10, 2415919046
amoswap.d x19, x19, (x10)
fcvt.s.h f18, f14
csrrs x13, fflags, x0
sh3add x16, x20, x20
fcvt.h.wu f20, x15, dyn
csrrs x17, fflags, x0
li x12, 2415919060
amoxor.w.aq x13, x19, (x12)
fmaxm.s f17, f19, f19
csrrs x13, fflags, x0
fclass.h x20, f16
csrrs x14, fflags, x0
li x10, 2415919032
amoadd.w x16, x18, (x10)
li x2, 2415919071
c.lwsp x18, 16(sp)
mulhsu x15, x13, x19
c.srai x13, 51
andi x18, x17, -1575
c.addw x14, x14
sext.b x19, x13
fclass.s x19, f14
csrrs x17, fflags, x0
fdiv.h f19, f19, f20, rne
csrrs x16, fflags, x0
fmul.h f17, f15, f15, dyn
csrrs x16, fflags, x0
sh3add x17, x17, x16
fmaxm.h f16, f15, f16
csrrs x14, fflags, x0
fcvt.d.h f15, f20
csrrs x13, fflags, x0
li x9, 2415919035
c.sd x15, 16(x9)
fmadd.d f13, f19, f20, f17, dyn
csrrs x14, fflags, x0
mulhsu x19, x13, x15
fence.i
srl x16, x18, x19
fmax.d f17, f16, f18
csrrs x16, fflags, x0
fcvt.l.s x19, f15, rmm
csrrs x16, fflags, x0
slti x16, x13, 523
remuw x19, x13, x19
sh1add.uw x15, x13, x20
slt x14, x16, x18
binv x14, x16, x15
li x12, 2415919032
fsw f15, 16(x12)
csrrs x17, fflags, x0
li x10, 2415919065
amomin.w x20, x19, (x10)
fltq.s x20, f17, f20
csrrs x14, fflags, x0
sext.h x13, x19
fmv.w.x f13, x13
csrrs x14, fflags, x0
fcvt.h.l f18, x14, dyn
csrrs x14, fflags, x0
froundnx.h f19, f18, rne
csrrs x18, fflags, x0
bset x15, x15, x20
fadd.s f16, f17, f18, rmm
csrrs x20, fflags, x0
li x9, 2415919043
lbu x16, 9(x9)
mulhu x17, x16, x14
fround.h f18, f20, rmm
csrrs x17, fflags, x0
fcvt.w.h x14, f14, rdn
csrrs x15, fflags, x0
fli.h f14, 0.375
csrrs x17, fflags, x0
fmadd.h f14, f18, f17, f19, rne
csrrs x13, fflags, x0
li x8, 2415919041
amomax.w.aqrl x19, x19, (x8)
sh3add x19, x20, x15
srlw x14, x16, x18
fcvt.s.l f18, x15, rmm
csrrs x19, fflags, x0
li x8, 2415919065
amomaxu.w x15, x16, (x8)
fsgnj.h f18, f17, f15
csrrs x14, fflags, x0
li x8, 2415919045
amoadd.w.aqrl x19, x18, (x8)
sh1add.uw x14, x13, x19
li x2, 2415919057
c.lwsp x15, 16(sp)
li x12, 2415919046
amominu.w.aq x16, x17, (x12)
fle.h x16, f19, f18
csrrs x14, fflags, x0
fnmadd.d f16, f14, f16, f16, rup
csrrs x19, fflags, x0
fmax.s f18, f13, f19
csrrs x14, fflags, x0
remw x16, x15, x15
fclass.d x17, f20
csrrs x18, fflags, x0
fnmadd.h f15, f17, f16, f15, rtz
csrrs x14, fflags, x0
fround.h f19, f17, dyn
csrrs x13, fflags, x0
fcvtmod.w.d x20, f14, rtz
csrrs x13, fflags, x0
fmv.x.w x19, f16
csrrs x16, fflags, x0
fsgnjn.h f19, f13, f18
csrrs x19, fflags, x0
li x9, 2415919044
fsw f15, 11(x9)
csrrs x15, fflags, x0
fsgnjn.s f18, f20, f15
csrrs x20, fflags, x0
fleq.s x19, f13, f20
csrrs x18, fflags, x0
fclass.s x19, f18
csrrs x19, fflags, x0
fsgnj.s f17, f17, f14
csrrs x15, fflags, x0
li x11, 2415919068
amomin.w.rl x14, x20, (x11)
clz x17, x19
fmul.s f19, f18, f17, rtz
csrrs x18, fflags, x0
fcvt.d.lu f19, x13, rmm
csrrs x18, fflags, x0
remuw x15, x15, x13
fsgnjn.d f15, f17, f15
csrrs x13, fflags, x0
fsqrt.s f16, f16, rtz
csrrs x19, fflags, x0
li x12, 2415919069
c.sw x13, 12(x12)
c.srai x13, 58
fmsub.s f20, f20, f16, f14, rmm
csrrs x18, fflags, x0
fsub.s f18, f20, f13, rup
csrrs x13, fflags, x0
fmul.s f16, f18, f15, dyn
csrrs x14, fflags, x0
maxu x20, x17, x15
li x11, 2415919050
amoswap.d.rl x20, x15, (x11)
czero.nez x19, x19, x17
fltq.d x18, f20, f14
csrrs x17, fflags, x0
fleq.h x18, f19, f15
csrrs x13, fflags, x0
mulhu x18, x16, x20
fmul.d f16, f19, f14, rdn
csrrs x20, fflags, x0
fcvt.s.w f20, x16, dyn
csrrs x14, fflags, x0
mulh x14, x18, x15
li x2, 2415919037
c.lwsp x19, 16(sp)
fcvt.d.w f20, x14
csrrs x19, fflags, x0
czero.nez x13, x18, x19
fcvt.h.lu f18, x20, dyn
csrrs x15, fflags, x0
mulhu x15, x15, x17
fmul.d f13, f17, f19, rdn
csrrs x13, fflags, x0
csrrsi x13, dcsr, 14
feq.d x13, f16, f14
csrrs x19, fflags, x0
fsgnjx.s f16, f15, f17
csrrs x20, fflags, x0
fcvt.s.l f18, x18, dyn
csrrs x20, fflags, x0
fsub.s f19, f13, f14, rtz
csrrs x14, fflags, x0
li x12, 2415919064
ld x16, 8(x12)
fence.i
li x8, 2415919038
amomin.d x15, x19, (x8)
fcvt.s.wu f18, x18, rmm
csrrs x15, fflags, x0
fminm.d f20, f13, f16
csrrs x15, fflags, x0
orc.b x15, x20
fadd.s f20, f20, f15, rtz
csrrs x15, fflags, x0
fsub.s f15, f16, f17, rup
csrrs x18, fflags, x0
li x10, 2415919050
fld f16, 5(x10)
csrrs x20, fflags, x0
xor x13, x13, x17
li x2, 2415919034
c.lwsp x16, 12(sp)
li x8, 2415919054
sb x15, 16(x8)
bclr x16, x13, x18
li x10, 2415919045
amoxor.w.aqrl x15, x20, (x10)
ctz x19, x13
fsgnj.s f16, f13, f14
csrrs x13, fflags, x0
sllw x14, x14, x20
c.nop
li x8, 2415919066
sb x16, 13(x8)
li x12, 2415919049
amoand.w.aq x13, x16, (x12)
mulw x16, x14, x18
fsgnjn.d f19, f19, f19
csrrs x15, fflags, x0
li x2, 2415919051
c.lwsp x18, 4(sp)
li x8, 2415919044
amoswap.w.aqrl x18, x19, (x8)
fltq.s x19, f16, f19
csrrs x16, fflags, x0
fadd.h f16, f19, f19, rtz
csrrs x17, fflags, x0
minu x19, x20, x20
li x8, 2415919056
flh f20, 7(x8)
csrrs x18, fflags, x0
c.li x14, -20
c.ebreak
fcvt.d.w f15, x14
csrrs x15, fflags, x0
xori x15, x15, -1130
sh1add.uw x15, x13, x13
fminm.s f19, f16, f13
csrrs x17, fflags, x0
or x16, x13, x18
froundnx.d f17, f14, rup
csrrs x16, fflags, x0
czero.nez x15, x18, x20
sh2add x13, x20, x20
fdiv.s f18, f16, f16, rup
csrrs x15, fflags, x0
czero.eqz x17, x19, x16
fence.i
fcvt.s.wu f13, x18, rdn
csrrs x13, fflags, x0
li x11, 2415919033
lbu x15, 14(x11)
li x2, 2415919048
c.swsp x17, 4(sp)
fence r, iorw
c.li x17, 9
fadd.d f13, f15, f16, dyn
csrrs x17, fflags, x0
fli.d f15, 0.875
csrrs x19, fflags, x0
srli x19, x13, 20
li x10, 2415919062
lbu x18, 13(x10)
li x10, 2415919036
amominu.w.rl x15, x18, (x10)
fcvt.d.wu f16, x20
csrrs x18, fflags, x0
ctzw x15, x20
ori x14, x16, 1840
li x8, 2415919038
lh x17, 14(x8)
li x10, 2415919037
amomax.d x15, x17, (x10)
fli.d f15, 2.0
csrrs x15, fflags, x0
froundnx.s f13, f13, rdn
csrrs x20, fflags, x0
fmax.d f18, f16, f18
csrrs x17, fflags, x0
fmv.x.d x16, f19
csrrs x13, fflags, x0
c.subw x13, x13
sll x16, x20, x13
clzw x16, x15
fsgnjn.h f15, f20, f17
csrrs x17, fflags, x0
li x11, 2415919036
amoand.d.aq x17, x14, (x11)
c.ebreak
li x9, 2415919061
lhu x14, 15(x9)
fadd.d f13, f17, f20, rtz
csrrs x17, fflags, x0
binv x17, x14, x16
li x12, 2415919036
amoxor.w x19, x15, (x12)
ctzw x18, x18
slli.uw x17, x16, 47
sh2add.uw x18, x13, x15
li x8, 2415919046
amomax.d.aq x14, x18, (x8)
remu x15, x18, x13
c.slli x17, 11
c.subw x13, x14
fmsub.h f20, f19, f15, f17, rmm
csrrs x20, fflags, x0
slt x16, x14, x20
fcvt.d.lu f18, x13, dyn
csrrs x15, fflags, x0
fcvt.h.lu f15, x13, rne
csrrs x13, fflags, x0
fnmsub.h f14, f15, f17, f17, rdn
csrrs x14, fflags, x0

exit:
    li t0, 1 # report success
    la t1, tohost
    sd t0, 0(t1)
1:
    j 1b


.align 2
switch_to_s_mode:
    # Set up the page table: identity-map the 1GB region containing 0x80000000
    la t0, pgtbl
    li t1, (0x80000 << 10) | 0xCF # PPN=0x80000, full permissions
    sd t1, 16(t0)

    # Write satp to enable paging (Sv39)
    li t2, 8
    slli t2, t2, 60
    srli t1, t0, 12
    or t2, t2, t1
    csrw satp, t2
    sfence.vma

    # Set MPP to S-mode (1) and prepare for mret
    li t0, ~(3 << 11)
    csrr t1, mstatus
    and t1, t1, t0
    li t2, (1 << 11)
    or t1, t1, t2
    csrw mstatus, t1

    csrw mepc, ra
    mret

.align 2
exit_s_mode:
    ecall # Trigger Environment Call (Cause 9)
    ret # Handler will actually adjust mepc to skip this spot


    .align 2
trap_handler:
    csrr t0, mepc # faulting PC
    csrr t1, mcause # trap cause
    csrr t4, mtval

    # Extract the exception code
    slli t5, t1, 1
    srli t1, t5, 1

    # --- Added: handle requests to return to M-mode ---
    li t3, 9 # Ecall from S-mode
    bne t1, t3, check_page_fault
    # If it is an ecall, set MPP so mret returns to M-mode
    li t2, 3 << 11
    csrs mstatus, t2 # Set MPP to 3 (Machine)
    li t2, 4 # Skip the ecall instruction
    j update_mepc

check_page_fault:
    # --- Added: detect page faults (13 or 15) ---
    li t3, 13
    beq t1, t3, handle_as_normal_fault
    li t3, 15
    beq t1, t3, handle_as_normal_fault

    # If it's neither a page fault nor an ecall, fall back to the original logic
    j original_logic

handle_as_normal_fault:
    # Page faults still need instruction-length decoding and skipping; reuse the original logic
    j original_logic

original_logic:
    # Original logic: decode instruction length
    li t2, 2
    li t3, 2
    beq t1, t3, illegal_len
    li t3, 1
    beq t1, t3, instr_fault_len
    li t3, 12
    beq t1, t3, instr_fault_len

    lhu t4, 0(t0)
    j decode_length

other_len:
    lhu t4, 0(t0)
    j decode_length

illegal_len:
    beqz t4, other_len
    j decode_length

instr_fault_len:
    li t2, 4
    j update_mepc

decode_length:
    andi t4, t4, 3
    li t3, 3
    bne t4, t3, compressed_len
    li t2, 4
    j update_mepc

compressed_len:
    li t2, 2

update_mepc:
    add t0, t0, t2
    csrw mepc, t0
    csrw mcause, x0
    csrw mtval, x0
    mret

    .section .data
    .balign 4096
pgtbl:
    .zero 4096


    .section .tohost,"aw",@progbits
    .align 6
    .globl tohost
    .globl fromhost
tohost:
    .dword 0
fromhost:
    .dword 0
