# 0 "/home/fuzz/runs/diff_spike_rocket/1793355732_690824753_rv64_2_w01/iter_002/Rocket/program.S"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/home/fuzz/runs/diff_spike_rocket/1793355732_690824753_rv64_2_w01/iter_002/Rocket/program.S"
    .section .text
    .globl _start

_start:
    la t0, trap_handler
    csrw mtvec, t0

    csrr t0, mstatus
    li t1, 0x00003000 # set FS field to Dirty (0b11) so FP regs usable
    or t0, t0, t1
    csrw mstatus, t0
    csrw fcsr, x0 # clear floating-point status

    j user_code

user_code:
li x13, 0x9b3f54e642a07f60
li x14, 0xe021650b1ab431ac
li x15, 0xd6d95d17a31e8d98
li x16, 0x46b48dd2e96279b2
li x17, 0x75d087798ee559ab
li x18, 0xc4dadbfb64046053
li x19, 0x3fb0f93d67fa3811
li x20, 0xb1b9bae3a6386de6
li x8, 0x5b416fde800accac
fmv.d.x f13, x8
li x8, 0x152533645dc98538
fmv.d.x f14, x8
li x8, 0xc68809fcec5d3138
fmv.d.x f15, x8
li x8, 0xf15d4dee128a5f99
fmv.d.x f16, x8
li x8, 0xfc0c561bff784c17
fmv.d.x f17, x8
li x8, 0xa8cf763d0847b3ca
fmv.d.x f18, x8
li x8, 0x96515947ead337ff
fmv.d.x f19, x8
li x8, 0x6f3220525b6fad33
fmv.d.x f20, x8
li x9, 0x8fffffb8
li x10, 0x8ed555c8ae431533
sd x10, 0(x9)
li x10, 0xa285506981eeed60
sd x10, 8(x9)
li x10, 0xd8ddd7a6c278e321
sd x10, 16(x9)
li x10, 0x752318bdeb30eeb8
sd x10, 24(x9)
li x10, 0x9486cfd4dd70ff08
sd x10, 32(x9)
li x10, 0xcd6f33a4fcddf25d
sd x10, 40(x9)
li x10, 0xf610a547ff69e6be
sd x10, 48(x9)
li x10, 0xb7125dee69d4f252
sd x10, 56(x9)
li x8, 0
li x9, 0
li x10, 0
li x11, 0
li x12, 0
li x2, 2415919055
c.sdsp x17, 0(sp)
csrrs x17, fflags, x0
orc.b x13, x17
fmv.x.d x18, f18
csrrs x19, fflags, x0
c.sub x13, x14
srliw x19, x20, 0
fle.h x17, f19, f19
csrrs x19, fflags, x0
fdiv.s f18, f15, f13, rmm
csrrs x16, fflags, x0
divuw x20, x14, x17
sh1add x13, x13, x18
czero.eqz x19, x17, x17
fence.i
fdiv.h f19, f20, f16, dyn
csrrs x16, fflags, x0
li x12, 2415919063
c.ld x13, 0(x12)
fcvt.d.w f19, x16
csrrs x15, fflags, x0
fcvt.h.w f17, x15, rne
csrrs x15, fflags, x0
li x12, 2415919063
sw x13, 6(x12)
fcvt.d.wu f20, x16
csrrs x19, fflags, x0
fnmadd.d f13, f15, f19, f15, dyn
csrrs x19, fflags, x0
divuw x18, x17, x16
li x8, 2415919056
amoor.w.aqrl x17, x18, (x8)
sext.b x16, x19
bext x19, x14, x17
li x11, 2415919033
amoand.d.aq x14, x14, (x11)
bclri x17, x18, 46
fsgnjx.d f18, f16, f19
csrrs x16, fflags, x0
bseti x16, x20, 24
fnmsub.h f16, f13, f19, f18, dyn
csrrs x19, fflags, x0
csrrs x14, fflags, x0
add.uw x13, x18, x17
csrrs x20, fflags, x0
li x10, 2415919058
lhu x17, 13(x10)
fcvt.lu.s x13, f14, rup
csrrs x19, fflags, x0
cpopw x15, x14
fence.i
slliw x14, x14, 7
xori x18, x16, 45
fnmadd.h f20, f20, f14, f19, rne
csrrs x15, fflags, x0
fence.i
li x10, 2415919033
c.sd x15, 0(x10)
csrrs x13, fflags, x0
fsgnj.d f17, f17, f13
csrrs x20, fflags, x0
csrrs x18, fflags, x0
csrrs x14, fflags, x0
fadd.h f14, f19, f15, rup
csrrs x15, fflags, x0
fence.tso
li x8, 2415919067
amoswap.d.rl x16, x18, (x8)
zext.h x13, x19
sraiw x13, x20, 24
flt.h x13, f16, f16
csrrs x20, fflags, x0
li x10, 2415919050
amoswap.d.aqrl x13, x16, (x10)
li x2, 2415919067
c.swsp x13, 12(sp)
li x10, 2415919063
amomaxu.d.aqrl x18, x16, (x10)
li x11, 2415919054
amoor.d.rl x20, x14, (x11)
fmin.h f17, f20, f20
csrrs x19, fflags, x0
fcvt.d.h f13, f20
csrrs x18, fflags, x0
fsgnj.s f18, f15, f18
csrrs x18, fflags, x0
bext x15, x16, x13
fdiv.h f15, f14, f14, rup
csrrs x17, fflags, x0
li x10, 2415919039
sw x20, 5(x10)
c.xor x15, x15
czero.eqz x16, x19, x16
slliw x15, x18, 2
orc.b x19, x15
fsqrt.d f13, f14, dyn
csrrs x19, fflags, x0
fcvt.l.s x13, f20, dyn
csrrs x18, fflags, x0
sra x17, x15, x17
sh2add.uw x19, x16, x14
c.addi16sp sp, 16
sh2add.uw x16, x18, x14
xori x17, x18, -282
c.addi x18, -6
fence.i
fence.i
fmsub.h f14, f13, f19, f17, rne
csrrs x18, fflags, x0
fsgnjn.h f17, f15, f19
csrrs x18, fflags, x0
c.subw x13, x15
fmv.x.d x18, f13
csrrs x16, fflags, x0
c.nop
fcvt.wu.h x16, f19, rtz
csrrs x20, fflags, x0
clzw x18, x13
sltiu x16, x18, -1638
slli x14, x18, 6
fsub.d f13, f13, f14, rmm
csrrs x18, fflags, x0
li x10, 2415919059
amoxor.w x14, x16, (x10)
csrrs x14, fflags, x0
fcvt.h.w f20, x13, rtz
csrrs x17, fflags, x0
fence.i
csrrs x20, fflags, x0
bclr x15, x16, x20
li x8, 2415919040
amoadd.d x18, x13, (x8)
csrrs x17, fflags, x0
c.subw x14, x13
fle.h x14, f18, f13
csrrs x17, fflags, x0
fclass.d x18, f19
csrrs x18, fflags, x0
csrrs x14, fflags, x0
li x8, 2415919045
amoand.w.aq x17, x19, (x8)
fsgnjx.d f15, f20, f17
csrrs x15, fflags, x0
li x8, 2415919055
lw x16, 12(x8)
fclass.d x19, f20
csrrs x20, fflags, x0
li x11, 2415919057
fld f16, 14(x11)
csrrs x20, fflags, x0
add.uw x13, x13, x19
li x9, 2415919063
fsh f13, 8(x9)
csrrs x16, fflags, x0
addw x15, x13, x17
remuw x13, x19, x18
fclass.d x20, f14
csrrs x13, fflags, x0
fmv.x.w x13, f19
csrrs x20, fflags, x0
fcvt.d.w f15, x20
csrrs x14, fflags, x0
fmv.x.d x19, f15
csrrs x15, fflags, x0
fmv.x.h x18, f19
csrrs x16, fflags, x0
li x11, 2415919041
c.ld x15, 0(x11)
sllw x19, x16, x18
fmul.s f17, f16, f18, rtz
csrrs x16, fflags, x0
fcvt.h.d f17, f14, rne
csrrs x16, fflags, x0
div x16, x13, x18
li x8, 2415919050
amominu.w.aqrl x15, x14, (x8)
fcvt.wu.h x15, f19, rne
csrrs x14, fflags, x0
fsgnjx.d f13, f18, f19
csrrs x15, fflags, x0
fsgnj.d f16, f18, f16
csrrs x17, fflags, x0
cpopw x18, x16
fmax.d f16, f13, f13
csrrs x17, fflags, x0
li x8, 2415919034
ld x20, 15(x8)
fsgnjn.h f13, f16, f17
csrrs x17, fflags, x0
fdiv.d f14, f15, f16, dyn
csrrs x16, fflags, x0
csrrs x15, fflags, x0
c.or x13, x13
sltiu x16, x16, -620
binv x13, x20, x17
fcvt.h.l f19, x18, dyn
csrrs x13, fflags, x0
fence.tso
fcvt.s.lu f19, x13, dyn
csrrs x18, fflags, x0
li x12, 2415919066
lhu x20, 5(x12)
li x9, 2415919055
flw f19, 5(x9)
csrrs x19, fflags, x0
csrrs x13, fflags, x0
remw x18, x16, x20
fcvt.w.h x13, f19, rne
csrrs x19, fflags, x0
zext.h x15, x16
li x8, 2415919055
amoswap.d.rl x17, x20, (x8)
csrrs x17, fflags, x0
fence.i
li x11, 2415919041
amoand.w.aq x13, x14, (x11)
c.mv x15, x18
fmadd.s f19, f13, f17, f18, dyn
csrrs x15, fflags, x0
csrrs x16, fflags, x0
czero.nez x18, x19, x16
slti x16, x14, -1912
fmul.h f16, f15, f20, dyn
csrrs x18, fflags, x0
li x12, 2415919048
fsw f17, 11(x12)
csrrs x14, fflags, x0
csrrs x19, fflags, x0
mul x20, x20, x15
c.addiw x19, 5
sext.h x15, x20
fnmsub.d f20, f18, f16, f19, dyn
csrrs x20, fflags, x0
sh2add.uw x19, x18, x18
li x2, 2415919068
c.sdsp x16, 0(sp)
fclass.h x16, f18
csrrs x20, fflags, x0
fcvt.lu.h x14, f19, dyn
csrrs x14, fflags, x0
li x12, 2415919049
lhu x19, 16(x12)
fsgnjx.h f17, f20, f13
csrrs x14, fflags, x0
li x8, 2415919057
fsw f17, 5(x8)
csrrs x20, fflags, x0
slli x15, x16, 21
slt x14, x18, x18
li x11, 2415919066
amoor.d.rl x13, x18, (x11)
c.subw x14, x15
fmv.x.d x16, f16
csrrs x15, fflags, x0
fence.i
fadd.s f18, f15, f16, dyn
csrrs x13, fflags, x0
sll x15, x18, x20
ctzw x20, x17
and x14, x16, x18
li x2, 2415919057
c.sdsp x13, 8(sp)
bext x20, x20, x20
li x9, 2415919058
lh x13, 9(x9)
csrrs x13, fflags, x0
sraw x17, x19, x14
csrrs x18, fflags, x0
mulh x16, x20, x13
sh2add x17, x19, x16
fcvt.h.lu f19, x18, rmm
csrrs x17, fflags, x0
min x13, x17, x20
li x9, 2415919053
fsh f17, 8(x9)
csrrs x15, fflags, x0
srlw x13, x16, x20
c.addiw x18, -3
fnmadd.s f20, f20, f19, f17, rtz
csrrs x15, fflags, x0
li x11, 2415919056
amoor.w.aqrl x17, x14, (x11)
fence w, irw
fsgnjn.s f18, f15, f13
csrrs x19, fflags, x0
csrrs x14, fflags, x0
sra x14, x19, x13
fle.s x13, f19, f15
csrrs x16, fflags, x0
csrrsi x17, frm, 25
li x2, 2415919050
c.ldsp x18, 8(sp)
lui x16, 376832
li x12, 2415919048
fsh f20, 11(x12)
csrrs x16, fflags, x0
addw x17, x19, x17
fmax.h f14, f20, f18
csrrs x16, fflags, x0
sraw x19, x20, x13
c.addi x19, 31
fmax.h f13, f19, f20
csrrs x16, fflags, x0
li x10, 2415919061
sw x20, 1(x10)
bset x14, x20, x18
li x8, 2415919050
c.lw x13, 0(x8)
fmv.x.d x16, f16
csrrs x14, fflags, x0
fle.d x17, f13, f15
csrrs x13, fflags, x0
add x17, x20, x18
csrrs x17, fflags, x0
slliw x15, x19, 9
czero.nez x19, x15, x20
fcvt.lu.d x18, f19, rmm
csrrs x20, fflags, x0
li x11, 2415919037
amoswap.d x19, x16, (x11)
csrrs x18, fflags, x0
li x10, 2415919038
c.sw x14, 16(x10)
fsub.s f14, f19, f14, rdn
csrrs x13, fflags, x0
divu x18, x19, x18
srliw x20, x15, 28
sll x18, x13, x14
fsqrt.h f15, f19, rup
csrrs x14, fflags, x0
czero.eqz x15, x19, x18
slti x16, x13, -1595
fmv.x.w x20, f15
csrrs x13, fflags, x0
rem x13, x18, x13
cpop x16, x20
fmv.h.x f18, x20
csrrs x14, fflags, x0
c.slli x14, 60
fcvt.d.s f18, f20
csrrs x13, fflags, x0
c.srli x15, 27
divw x19, x13, x17
c.li x15, 31
li x10, 2415919032
c.sd x15, 16(x10)
fle.d x13, f15, f20
csrrs x20, fflags, x0
slli.uw x15, x18, 45
mul x15, x20, x19
fmsub.d f18, f13, f15, f14, dyn
csrrs x14, fflags, x0
ctzw x18, x14
csrrs x19, fflags, x0
fcvt.h.d f14, f16, rup
csrrs x20, fflags, x0
fnmsub.s f14, f20, f16, f17, rup
csrrs x13, fflags, x0
li x11, 2415919040
amoand.w.aq x13, x16, (x11)
fcvt.wu.s x13, f16, rup
csrrs x16, fflags, x0
sra x17, x14, x17
fadd.h f14, f13, f18, rtz
csrrs x16, fflags, x0
li x12, 2415919059
flw f18, 0(x12)
csrrs x13, fflags, x0
sra x19, x15, x13
feq.d x14, f20, f13
csrrs x16, fflags, x0
li x9, 2415919052
c.sd x13, 0(x9)
li x2, 2415919064
c.ldsp x18, 8(sp)
c.srli x13, 19
fdiv.h f17, f13, f14, rup
csrrs x17, fflags, x0
fclass.h x19, f20
csrrs x16, fflags, x0
li x10, 2415919036
c.sw x14, 0(x10)
sh1add x17, x19, x20
fsub.h f17, f19, f13, rtz
csrrs x16, fflags, x0
fcvt.d.wu f16, x14
csrrs x14, fflags, x0
fsgnj.s f18, f19, f20
csrrs x13, fflags, x0
li x12, 2415919036
fsw f14, 0(x12)
csrrs x20, fflags, x0
csrrs x17, fflags, x0
czero.eqz x17, x14, x19
sh3add x17, x19, x14
fcvt.w.h x17, f19, dyn
csrrs x17, fflags, x0
fcvt.l.h x13, f13, dyn
csrrs x15, fflags, x0
srl x17, x14, x13
csrrs x16, fflags, x0
li x12, 2415919041
amomin.w.aqrl x18, x14, (x12)
sext.b x18, x19
bclri x17, x19, 53
add.uw x20, x16, x16
fcvt.d.h f17, f20
csrrs x15, fflags, x0
fcvt.s.lu f14, x15, rtz
csrrs x16, fflags, x0
fmv.d.x f14, x19
csrrs x14, fflags, x0
li x9, 2415919054
amoand.w x18, x17, (x9)
slt x16, x18, x13
sraiw x16, x18, 20
fmv.x.d x14, f13
csrrs x17, fflags, x0
fence.i
fcvt.wu.d x16, f18, rtz
csrrs x15, fflags, x0
csrrs x17, fflags, x0
li x10, 2415919071
c.sd x13, 0(x10)
fmin.h f14, f13, f19
csrrs x17, fflags, x0
fcvt.s.wu f20, x16, rup
csrrs x18, fflags, x0
sraiw x20, x14, 28
csrrs x14, fflags, x0
mul x17, x15, x17
fence.i
li x8, 2415919054
lb x16, 8(x8)
slli.uw x13, x15, 16
fnmsub.h f17, f13, f15, f17, dyn
csrrs x14, fflags, x0
li x10, 2415919040
lh x14, 1(x10)
fsgnjx.d f15, f17, f14
csrrs x13, fflags, x0
minu x20, x15, x16
fnmsub.s f13, f19, f20, f13, rne
csrrs x19, fflags, x0
csrrs x16, fflags, x0
li x8, 2415919039
amoand.d.aq x18, x17, (x8)
csrrs x15, fflags, x0
fsub.s f15, f20, f13, rup
csrrs x14, fflags, x0
slti x15, x20, -816
fmadd.s f15, f19, f13, f14, dyn
csrrs x13, fflags, x0
sll x14, x17, x19
li x10, 2415919038
sb x17, 4(x10)
fcvt.d.l f15, x15, dyn
csrrs x16, fflags, x0
fmsub.h f15, f13, f14, f13, rmm
csrrs x15, fflags, x0
csrrs x20, fflags, x0
czero.nez x13, x16, x18
fsgnjn.h f16, f13, f14
csrrs x15, fflags, x0
min x14, x13, x19
add.uw x15, x20, x20
li x12, 2415919036
lbu x13, 14(x12)
csrrs x18, fflags, x0
csrrs x19, fflags, x0
fmul.d f13, f18, f17, dyn
csrrs x17, fflags, x0
c.or x15, x15
max x16, x13, x18
fmax.s f15, f20, f19
csrrs x20, fflags, x0
csrrs x13, fflags, x0
c.srli x15, 7
subw x16, x14, x19
fmsub.h f15, f20, f19, f18, rmm
csrrs x18, fflags, x0
li x12, 2415919043
amoxor.w.rl x13, x19, (x12)
fcvt.h.w f19, x16, rne
csrrs x18, fflags, x0
bset x20, x17, x16
ctz x19, x17
sext.b x17, x16
csrrs x17, fflags, x0
fnmsub.d f15, f20, f20, f14, rmm
csrrs x14, fflags, x0
fadd.h f17, f19, f18, rdn
csrrs x15, fflags, x0
c.nop
rem x19, x13, x16
c.subw x13, x15
fsgnjn.h f15, f14, f15
csrrs x14, fflags, x0
c.add x20, x14
cpop x15, x14
fcvt.h.s f14, f13, rne
csrrs x17, fflags, x0
li x2, 2415919050
c.sdsp x14, 8(sp)
csrrs x14, fflags, x0
fcvt.wu.h x14, f15, rmm
csrrs x16, fflags, x0
li x8, 2415919056
amoxor.w.rl x18, x17, (x8)
srli x13, x18, 51
li x11, 2415919038
amoxor.d.aqrl x13, x15, (x11)
c.addiw x18, 20
li x12, 2415919059
amoor.d.rl x20, x15, (x12)
li x10, 2415919064
amoadd.w.rl x19, x19, (x10)
fclass.h x20, f13
csrrs x17, fflags, x0
sll x13, x18, x19
sh3add x15, x14, x15
binvi x13, x15, 9
fmv.x.w x19, f16
csrrs x14, fflags, x0
c.srli x13, 60
fcvt.s.l f18, x17, rtz
csrrs x18, fflags, x0
sh2add x14, x16, x17
binvi x18, x15, 23
c.subw x13, x13
csrrs x15, fflags, x0
c.li x19, 28
sll x13, x17, x14
mulhsu x20, x17, x14
sext.b x14, x17
slliw x19, x19, 14
sext.b x17, x16
fmv.x.w x17, f13
csrrs x20, fflags, x0
mulw x18, x14, x19
csrrs x13, fflags, x0
sra x15, x14, x14
addiw x18, x17, 732
slli x17, x16, 52
li x12, 2415919071
c.sd x14, 16(x12)
feq.s x13, f15, f19
csrrs x15, fflags, x0
sext.h x18, x17
csrrs x13, fflags, x0
slli x15, x19, 16
li x18, -9223372036854775796
csrrc x13, mcause, x18
li x8, 2415919064
fsd f20, 5(x8)
csrrs x18, fflags, x0
fnmadd.s f18, f18, f19, f14, rdn
csrrs x20, fflags, x0
fcvt.d.s f15, f19
csrrs x16, fflags, x0
fle.h x20, f19, f15
csrrs x19, fflags, x0
fcvt.lu.d x14, f17, dyn
csrrs x15, fflags, x0
csrrs x15, fflags, x0
remu x19, x16, x15
mulw x18, x15, x16
fsgnjx.d f15, f13, f15
csrrs x17, fflags, x0
fmul.d f18, f18, f19, dyn
csrrs x16, fflags, x0
fcvt.wu.d x17, f13, dyn
csrrs x16, fflags, x0
li x11, 2415919064
amoxor.w.rl x15, x14, (x11)
fadd.d f19, f20, f17, dyn
csrrs x19, fflags, x0
csrrs x16, fflags, x0
c.addiw x19, -31
bclr x18, x14, x14
csrrs x13, fflags, x0
czero.nez x18, x19, x15
xor x16, x17, x17
fcvt.d.s f19, f15
csrrs x15, fflags, x0
fcvt.h.s f14, f13, rdn
csrrs x19, fflags, x0
csrrs x18, fflags, x0
c.xor x15, x13
addiw x13, x16, -26
xor x15, x20, x13
c.and x15, x13
li x8, 2415919060
amomin.w x15, x13, (x8)
li x11, 2415919054
flh f20, 1(x11)
csrrs x16, fflags, x0
li x12, 2415919060
sb x16, 7(x12)
csrrs x18, fflags, x0
fmv.h.x f14, x14
csrrs x17, fflags, x0
fcvt.h.wu f14, x16, dyn
csrrs x13, fflags, x0
bclr x19, x13, x17
fcvt.h.s f14, f14, rtz
csrrs x19, fflags, x0
fcvt.s.wu f13, x13, dyn
csrrs x15, fflags, x0
li x12, 2415919037
flh f20, 8(x12)
csrrs x19, fflags, x0
li x8, 2415919055
amomax.d.aqrl x20, x13, (x8)
fence.i
li x8, 2415919070
amominu.w.aq x14, x15, (x8)
sraiw x17, x20, 21
mulhsu x17, x19, x15
cpopw x17, x20
li x10, 2415919059
sh x16, 12(x10)
rem x20, x16, x16
fence.i
li x11, 2415919039
amoxor.w x15, x20, (x11)
rem x18, x17, x15
fmv.h.x f17, x20
csrrs x19, fflags, x0
csrrs x15, fflags, x0
fence.i
li x9, 2415919044
c.ld x14, 8(x9)
fcvt.d.w f17, x14
csrrs x14, fflags, x0
li x11, 2415919058
amoadd.d x13, x15, (x11)
fsgnj.h f13, f16, f15
csrrs x15, fflags, x0
addi x15, x16, -1475
fclass.s x18, f19
csrrs x14, fflags, x0
flt.d x18, f17, f18
csrrs x14, fflags, x0
binvi x15, x19, 40
feq.s x17, f15, f14
csrrs x16, fflags, x0
srl x20, x20, x14
fmadd.d f20, f20, f16, f15, dyn
csrrs x14, fflags, x0
fmsub.s f13, f14, f15, f17, dyn
csrrs x14, fflags, x0
mulhsu x14, x17, x18
csrrs x20, fflags, x0
fclass.d x18, f15
csrrs x13, fflags, x0
slli.uw x18, x19, 46
cpop x14, x17
li x8, 2415919070
lwu x14, 11(x8)
csrrs x15, fflags, x0
c.ebreak
fle.d x20, f14, f14
csrrs x19, fflags, x0
fmsub.h f16, f15, f20, f13, rup
csrrs x14, fflags, x0
li x8, 2415919058
c.sw x14, 16(x8)
sh1add x18, x13, x19
c.ebreak
li x11, 2415919070
c.sd x15, 8(x11)
fsgnjn.s f17, f16, f19
csrrs x19, fflags, x0
fmv.x.w x17, f17
csrrs x14, fflags, x0
fence.i
fsgnj.h f20, f13, f13
csrrs x20, fflags, x0
csrrs x15, fflags, x0
fence.i
li x9, 2415919068
fsd f19, 12(x9)
csrrs x17, fflags, x0
fclass.s x20, f20
csrrs x13, fflags, x0
fsub.d f18, f14, f20, dyn
csrrs x20, fflags, x0
csrrs x16, fflags, x0
li x10, 2415919041
amoswap.d.aq x16, x13, (x10)
fcvt.wu.s x16, f17, dyn
csrrs x16, fflags, x0
fsub.h f20, f19, f18, rne
csrrs x15, fflags, x0
fsgnjn.s f20, f14, f20
csrrs x17, fflags, x0
mul x16, x14, x17
srliw x13, x16, 25
czero.nez x17, x18, x13
li x12, 2415919035
sb x15, 9(x12)
csrrci x13, dscratch0, 28
li x9, 2415919057
c.sw x13, 8(x9)
fsgnjn.d f15, f18, f14
csrrs x20, fflags, x0
feq.s x16, f15, f14
csrrs x20, fflags, x0
li x9, 2415919067
amominu.w.aqrl x17, x18, (x9)
fclass.s x19, f15
csrrs x15, fflags, x0
csrrs x17, fflags, x0
li x12, 2415919060
sb x19, 6(x12)
div x17, x14, x17
fmv.x.w x14, f18
csrrs x13, fflags, x0
fdiv.h f13, f17, f13, rup
csrrs x14, fflags, x0
fcvt.lu.h x14, f17, rne
csrrs x18, fflags, x0
rem x19, x17, x14
clzw x17, x20
bset x15, x14, x13
li x11, 2415919037
fsd f16, 3(x11)
csrrs x17, fflags, x0
fsgnjx.h f17, f13, f13
csrrs x15, fflags, x0
fsgnjx.d f17, f17, f13
csrrs x18, fflags, x0
slli.uw x17, x16, 30
li x11, 2415919037
flh f16, 12(x11)
csrrs x20, fflags, x0
fmul.s f17, f16, f18, rdn
csrrs x20, fflags, x0
fadd.h f15, f14, f19, rmm
csrrs x16, fflags, x0
add.uw x20, x17, x13
addw x13, x20, x18
c.srli x13, 53
li x11, 2415919053
amoor.d.rl x18, x20, (x11)
c.mv x14, x15
min x14, x16, x14
li x11, 2415919045
amoadd.d.rl x14, x20, (x11)
c.addiw x16, -30
ctz x20, x15
binv x15, x15, x19
fsgnjn.s f20, f14, f15
csrrs x16, fflags, x0
li x12, 2415919033
sd x19, 13(x12)
fcvt.l.d x17, f17, rtz
csrrs x13, fflags, x0
fsub.s f20, f15, f14, dyn
csrrs x20, fflags, x0
fsgnjx.s f17, f15, f13
csrrs x17, fflags, x0
li x9, 2415919049
sb x19, 3(x9)
fmadd.d f14, f18, f20, f20, dyn
csrrs x16, fflags, x0
fclass.s x17, f19
csrrs x17, fflags, x0
fence.i
li x11, 2415919046
lb x20, 6(x11)
li x10, 2415919035
c.sd x13, 16(x10)
fmv.x.w x19, f16
csrrs x16, fflags, x0
csrrs x19, fflags, x0
sllw x18, x14, x17
fence i, rw
c.lui x16, 0xffff0
divuw x20, x16, x17
fmadd.d f17, f19, f17, f19, dyn
csrrs x17, fflags, x0
fmv.w.x f17, x13
csrrs x17, fflags, x0
li x10, 2415919055
amoswap.d x19, x19, (x10)
li x10, 2415919041
fsd f16, 13(x10)
csrrs x16, fflags, x0
c.li x16, 0
orc.b x13, x20
c.sub x14, x15
csrrs x15, fflags, x0
c.srai x14, 3
fence.i
divw x17, x19, x20
slliw x19, x14, 29
li x11, 2415919063
amomin.w.aq x20, x15, (x11)
fsqrt.s f14, f13, dyn
csrrs x15, fflags, x0
czero.eqz x16, x20, x18
cpopw x18, x20
srai x20, x19, 8
li x18, 7040482096176953443
csrrw x18, dscratch1, x18
fcvt.s.wu f16, x15, rdn
csrrs x13, fflags, x0
li x8, 2415919032
lwu x19, 7(x8)
csrrs x20, fflags, x0
fsqrt.d f19, f17, rne
csrrs x18, fflags, x0
li x10, 2415919033
amominu.w.aqrl x20, x17, (x10)
c.nop
sh2add x19, x14, x17
fsub.d f18, f20, f20, rne
csrrs x18, fflags, x0
fnmsub.d f15, f19, f19, f17, rtz
csrrs x14, fflags, x0
li x9, 2415919049
flh f13, 16(x9)
csrrs x15, fflags, x0
c.xor x13, x14
c.mv x15, x18
fcvt.h.w f20, x16, rmm
csrrs x13, fflags, x0
csrrs x15, fflags, x0
li x11, 2415919037
amoxor.w.aqrl x18, x13, (x11)
sltu x13, x19, x13
mul x19, x13, x16
fnmadd.s f16, f20, f18, f13, dyn
csrrs x16, fflags, x0
and x17, x19, x13
flt.s x15, f20, f19
csrrs x17, fflags, x0
fadd.s f17, f17, f16, dyn
csrrs x13, fflags, x0
li x8, 2415919044
amominu.w.rl x15, x14, (x8)
li x9, 2415919059
fld f14, 1(x9)
csrrs x14, fflags, x0
add x13, x13, x18
fcvt.d.h f15, f19
csrrs x14, fflags, x0
li x9, 2415919049
amoor.d x18, x14, (x9)
c.subw x14, x14
fnmadd.d f14, f15, f14, f16, dyn
csrrs x16, fflags, x0
fence.tso
fmul.s f16, f13, f17, rdn
csrrs x17, fflags, x0
sh2add.uw x18, x16, x20
fsgnjx.h f17, f20, f13
csrrs x15, fflags, x0
fdiv.s f16, f15, f13, rtz
csrrs x18, fflags, x0
li x9, 2415919062
amoand.w.rl x20, x13, (x9)
fmul.d f16, f17, f15, dyn
csrrs x15, fflags, x0
fmsub.d f17, f20, f18, f14, rmm
csrrs x13, fflags, x0
csrrs x20, fflags, x0
li x2, 2415919051
c.lwsp x14, 0(sp)
bexti x16, x20, 44
addi x20, x18, 1027
li x10, 2415919046
amoand.d.aq x15, x15, (x10)
c.li x17, 12
srlw x14, x15, x14
czero.eqz x16, x16, x15
czero.nez x13, x14, x16
clzw x14, x14
fmv.d.x f13, x15
csrrs x15, fflags, x0
feq.h x14, f19, f14
csrrs x14, fflags, x0
fle.h x16, f13, f17
csrrs x17, fflags, x0
csrrs x17, fflags, x0
ori x20, x20, 802
fmadd.d f17, f14, f15, f14, rup
csrrs x17, fflags, x0
czero.nez x17, x20, x13
csrrs x18, fflags, x0
fsqrt.d f13, f16, rup
csrrs x20, fflags, x0
fcvt.h.lu f13, x15, dyn
csrrs x17, fflags, x0
slliw x13, x18, 20
sra x17, x19, x19
feq.s x16, f18, f20
csrrs x19, fflags, x0
sraiw x15, x16, 0
c.add x13, x18
fclass.d x17, f17
csrrs x17, fflags, x0
fnmsub.d f20, f19, f19, f15, rmm
csrrs x19, fflags, x0
csrrs x17, fflags, x0
li x2, 2415919053
c.sdsp x20, 8(sp)
mulw x17, x14, x16
fnmsub.s f19, f13, f17, f16, rne
csrrs x15, fflags, x0
slti x20, x15, 524
fcvt.wu.h x17, f15, rup
csrrs x18, fflags, x0
orc.b x20, x19
li x11, 2415919065
lwu x19, 1(x11)
fmv.x.w x20, f20
csrrs x19, fflags, x0
csrrs x19, fflags, x0
li x8, 2415919063
flw f15, 12(x8)
csrrs x20, fflags, x0
li x9, 2415919056
flw f15, 0(x9)
csrrs x18, fflags, x0
feq.d x19, f19, f14
csrrs x14, fflags, x0
fsgnjn.s f17, f13, f14
csrrs x16, fflags, x0
fnmadd.h f16, f19, f14, f15, dyn
csrrs x16, fflags, x0
c.addi x15, 14
li x9, 2415919068
sd x16, 0(x9)
csrrs x20, fflags, x0
csrrs x14, fflags, x0
fdiv.h f16, f18, f17, rdn
csrrs x14, fflags, x0
fence.i
czero.nez x19, x20, x17
andi x14, x15, -1272
fclass.d x20, f16
csrrs x17, fflags, x0
slli.uw x15, x14, 59
orc.b x16, x19
binvi x19, x19, 27
li x11, 2415919055
amoswap.w.aqrl x19, x17, (x11)
li x9, 2415919052
amoxor.d x16, x18, (x9)
csrrs x14, fflags, x0
rem x13, x20, x18
fcvt.w.d x13, f19, rne
csrrs x18, fflags, x0
orc.b x15, x18
max x20, x20, x16
fmv.x.d x19, f17
csrrs x18, fflags, x0
fcvt.s.w f16, x17, dyn
csrrs x15, fflags, x0
remu x13, x16, x14
xor x18, x14, x13
fcvt.d.wu f15, x13
csrrs x17, fflags, x0
add.uw x15, x20, x20
li x20, 158
csrrs x16, fcsr, x20
and x15, x15, x16
c.subw x14, x14
fmul.h f14, f16, f19, rne
csrrs x14, fflags, x0
li x10, 2415919056
amoswap.d.aq x18, x19, (x10)
fsub.d f16, f19, f13, dyn
csrrs x16, fflags, x0
c.mv x15, x17
fcvt.wu.d x17, f19, rne
csrrs x15, fflags, x0
li x2, 2415919046
c.ldsp x18, 8(sp)
czero.eqz x18, x17, x17
csrrs x19, fflags, x0
li x10, 2415919070
flw f13, 9(x10)
csrrs x18, fflags, x0
li x9, 2415919059
lw x14, 10(x9)
fcvt.h.s f18, f17, rup
csrrs x17, fflags, x0
ctz x14, x13
div x14, x18, x20
div x20, x13, x18
li x9, 2415919059
ld x16, 14(x9)
fmax.s f19, f14, f16
csrrs x19, fflags, x0
csrrs x14, fflags, x0
or x13, x18, x16
li x11, 2415919064
lb x18, 2(x11)
fcvt.l.d x18, f15, dyn
csrrs x14, fflags, x0
fsgnj.s f19, f16, f18
csrrs x18, fflags, x0
li x8, 2415919064
amoswap.w.aqrl x17, x20, (x8)
csrrs x20, fflags, x0
csrrs x16, fflags, x0
fcvt.s.w f19, x17, rdn
csrrs x17, fflags, x0
fcvt.s.w f19, x13, dyn
csrrs x15, fflags, x0
addiw x15, x17, -1343
fsgnj.d f16, f18, f14
csrrs x17, fflags, x0
csrrs x15, fflags, x0
ctz x17, x20
fmin.h f20, f16, f16
csrrs x14, fflags, x0
xori x18, x19, 1374
li x12, 2415919041
amoand.w.aqrl x13, x16, (x12)
fmin.s f18, f13, f20
csrrs x15, fflags, x0
fcvt.h.l f20, x19, rup
csrrs x15, fflags, x0
feq.h x16, f13, f19
csrrs x17, fflags, x0
li x9, 2415919044
lbu x19, 16(x9)
fence.i
fsub.d f18, f17, f16, rmm
csrrs x15, fflags, x0
c.lui x20, 0x8
li x11, 2415919072
fsw f17, 3(x11)
csrrs x15, fflags, x0
fmin.h f20, f19, f13
csrrs x16, fflags, x0
fence ir, ir
fle.s x20, f14, f20
csrrs x13, fflags, x0
fmadd.h f17, f20, f14, f16, rne
csrrs x16, fflags, x0
fmadd.d f18, f16, f13, f19, dyn
csrrs x19, fflags, x0
fnmsub.d f18, f16, f15, f16, dyn
csrrs x18, fflags, x0
li x10, 2415919046
amoand.w.aq x18, x14, (x10)
bexti x18, x18, 23
fcvt.d.wu f19, x13
csrrs x13, fflags, x0
fcvt.s.l f19, x14, rtz
csrrs x19, fflags, x0
czero.nez x17, x20, x17
c.subw x13, x13
fsub.s f19, f18, f17, rtz
csrrs x13, fflags, x0
remw x20, x19, x15
fmul.s f18, f13, f16, rup
csrrs x14, fflags, x0
fmv.h.x f14, x19
csrrs x13, fflags, x0
li x10, 2415919067
amomaxu.d.aqrl x17, x16, (x10)
and x16, x19, x15
clzw x20, x20
clz x14, x16
fence.i
fmul.h f17, f17, f19, rup
csrrs x15, fflags, x0
fmv.x.d x14, f19
csrrs x19, fflags, x0
li x10, 2415919033
amoand.w.aq x18, x13, (x10)
fcvt.wu.s x15, f16, rmm
csrrs x18, fflags, x0
srli x18, x15, 27
fmax.h f15, f20, f17
csrrs x20, fflags, x0
fsgnjn.h f20, f19, f16
csrrs x15, fflags, x0
sraw x14, x20, x15
fsgnj.h f16, f14, f18
csrrs x19, fflags, x0
fsub.h f14, f19, f18, rne
csrrs x15, fflags, x0
and x15, x14, x19
binvi x16, x13, 2
mulw x17, x19, x16
add x16, x16, x19
li x9, 2415919049
lbu x13, 5(x9)
fmul.s f18, f14, f19, rtz
csrrs x17, fflags, x0
c.li x19, 11
li x2, 2415919056
c.ldsp x18, 16(sp)
fadd.s f15, f18, f13, rdn
csrrs x20, fflags, x0
flt.d x17, f15, f20
csrrs x17, fflags, x0
fadd.h f18, f15, f15, dyn
csrrs x13, fflags, x0
li x8, 2415919069
amomin.d.aqrl x15, x16, (x8)
c.addiw x14, -10
srliw x20, x17, 17
li x9, 2415919047
fsw f17, 8(x9)
csrrs x19, fflags, x0
div x18, x17, x20
li x9, 2415919042
lb x14, 15(x9)
czero.eqz x14, x17, x20
c.slli x19, 9
fsub.h f20, f19, f13, rup
csrrs x19, fflags, x0
remuw x20, x18, x14
li x12, 2415919048
lwu x17, 5(x12)
li x11, 2415919042
sd x14, 9(x11)
czero.eqz x17, x18, x13
clz x20, x17
fmax.s f20, f20, f15
csrrs x13, fflags, x0
srli x15, x14, 59
li x9, 2415919062
sh x19, 8(x9)
fadd.d f19, f17, f19, dyn
csrrs x20, fflags, x0
fnmsub.d f18, f15, f14, f13, rmm
csrrs x15, fflags, x0
fdiv.s f14, f13, f17, rtz
csrrs x16, fflags, x0
fclass.d x20, f17
csrrs x14, fflags, x0
fsub.h f20, f14, f15, rtz
csrrs x18, fflags, x0
c.subw x15, x15
fsgnj.s f20, f20, f15
csrrs x14, fflags, x0
li x9, 2415919034
fld f15, 1(x9)
csrrs x13, fflags, x0
fcvt.d.lu f20, x19, dyn
csrrs x20, fflags, x0
orc.b x17, x18
czero.nez x19, x15, x19
binvi x16, x17, 51
fmul.s f15, f18, f13, rmm
csrrs x17, fflags, x0
fcvt.s.w f14, x14, rdn
csrrs x17, fflags, x0
c.mv x16, x15
fsqrt.d f17, f19, rmm
csrrs x18, fflags, x0
fmadd.s f19, f18, f18, f13, dyn
csrrs x20, fflags, x0
sltiu x16, x14, 100
li x10, 2415919041
amoxor.d.aqrl x16, x13, (x10)
fmin.h f16, f15, f17
csrrs x15, fflags, x0
li x20, 8702305218609095838
csrrs x13, cycle, x20
csrrs x15, fflags, x0
fsgnjn.h f14, f16, f14
csrrs x17, fflags, x0
li x12, 2415919049
amoadd.d.aqrl x19, x13, (x12)
sh2add.uw x17, x14, x20
binvi x15, x15, 39
li x11, 2415919044
amominu.w.aq x13, x13, (x11)
czero.eqz x15, x15, x20
csrrs x16, fflags, x0
fsqrt.s f13, f15, dyn
csrrs x18, fflags, x0
fcvt.l.d x15, f17, dyn
csrrs x17, fflags, x0
csrrs x14, fflags, x0
rem x17, x15, x18
fmv.h.x f19, x16
csrrs x14, fflags, x0
fcvt.h.s f13, f20, rtz
csrrs x17, fflags, x0
li x10, 2415919043
fsw f13, 10(x10)
csrrs x14, fflags, x0
fnmadd.h f13, f18, f14, f20, dyn
csrrs x16, fflags, x0
li x12, 2415919039
sd x16, 11(x12)
fcvt.w.d x16, f20, dyn
csrrs x17, fflags, x0
fcvt.l.h x14, f14, dyn
csrrs x15, fflags, x0
li x10, 2415919046
c.sd x13, 0(x10)
li x2, 2415919063
c.swsp x15, 0(sp)
fadd.s f14, f13, f14, rne
csrrs x14, fflags, x0
c.slli x15, 26
add x15, x14, x13
binvi x16, x14, 50
sra x15, x14, x16
clzw x20, x20
fsgnj.s f14, f15, f18
csrrs x14, fflags, x0
divu x16, x17, x16
sraiw x16, x14, 31
srlw x20, x17, x20
fcvt.h.w f19, x20, rup
csrrs x20, fflags, x0

exit:
    li t0, 1 # report success
    la t1, tohost
    sd t0, 0(t1)
1:
    j 1b

    .align 2
trap_handler:
    csrr t0, mepc # faulting PC
    csrr t1, mcause # trap cause
    csrr t4, mtval

    slli t5, t1, 1 # strip interrupt bit
    srli t1, t5, 1

    li t2, 2 # default length assumes compressed
    li t3, 2 # illegal instruction -> mtval holds encoding
    beq t1, t3, use_mtval
    li t3, 1 # instruction access fault
    beq t1, t3, update_mepc
    li t3, 12 # instruction page fault
    beq t1, t3, update_mepc

    lhu t4, 0(t0)
    j decode_length

use_mtval:
    j decode_length

decode_length:
    andi t4, t4, 3
    li t3, 3
    bne t4, t3, compressed_len
    li t2, 4 # standard 32-bit instruction
    j update_mepc

compressed_len:
    li t2, 2 # compressed instruction

update_mepc:
    add t0, t0, t2 # skip offending instruction
    csrw mepc, t0
    csrw mcause, x0
    csrw mtval, x0
    mret

    .section .tohost,"aw",@progbits
    .align 6
    .globl tohost
    .globl fromhost
tohost:
    .dword 0
fromhost:
    .dword 0
