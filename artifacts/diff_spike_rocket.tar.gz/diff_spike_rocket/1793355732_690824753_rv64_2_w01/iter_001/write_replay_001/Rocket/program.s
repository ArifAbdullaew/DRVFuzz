# 0 "/home/fuzz/runs/diff_spike_rocket/1793355732_690824753_rv64_2_w01/iter_001/write_replay_001/Rocket/program.S"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/home/fuzz/runs/diff_spike_rocket/1793355732_690824753_rv64_2_w01/iter_001/write_replay_001/Rocket/program.S"
    .section .text
    .globl _start

_start:
    la t0, trap_handler
    csrw mtvec, t0

    csrr t0, mstatus
    li t1, 0x00003000 # set FS field to Dirty (0b11) so FP regs usable
    or t0, t0, t1
    csrw mstatus, t0
    csrw fcsr, x0 # clear floating-point status

    j user_code

user_code:
li x13, 0x9b3f54e642a07f60
li x14, 0xe021650b1ab431ac
li x15, 0xd6d95d17a31e8d98
li x16, 0x46b48dd2e96279b2
li x17, 0x75d087798ee559ab
li x18, 0xc4dadbfb64046053
li x19, 0x3fb0f93d67fa3811
li x20, 0xb1b9bae3a6386de6
li x8, 0x5b416fde800accac
fmv.d.x f13, x8
li x8, 0x152533645dc98538
fmv.d.x f14, x8
li x8, 0xc68809fcec5d3138
fmv.d.x f15, x8
li x8, 0xf15d4dee128a5f99
fmv.d.x f16, x8
li x8, 0xfc0c561bff784c17
fmv.d.x f17, x8
li x8, 0xa8cf763d0847b3ca
fmv.d.x f18, x8
li x8, 0x96515947ead337ff
fmv.d.x f19, x8
li x8, 0x6f3220525b6fad33
fmv.d.x f20, x8
li x9, 0x8fffffb8
li x10, 0x8ed555c8ae431533
sd x10, 0(x9)
li x10, 0xa285506981eeed60
sd x10, 8(x9)
li x10, 0xd8ddd7a6c278e321
sd x10, 16(x9)
li x10, 0x752318bdeb30eeb8
sd x10, 24(x9)
li x10, 0x9486cfd4dd70ff08
sd x10, 32(x9)
li x10, 0xcd6f33a4fcddf25d
sd x10, 40(x9)
li x10, 0xf610a547ff69e6be
sd x10, 48(x9)
li x10, 0xb7125dee69d4f252
sd x10, 56(x9)
li x8, 0
li x9, 0
li x10, 0
li x11, 0
li x12, 0
li x8, 0x8fffffb8
li x9, 0x33
sb x9, 0(x8)
li x8, 0x8fffffb9
li x9, 0x15
sb x9, 0(x8)
li x8, 0x8fffffba
li x9, 0x43
sb x9, 0(x8)
li x8, 0x8fffffbb
li x9, 0xffffffffffffffae
sb x9, 0(x8)
li x8, 0x8fffffbc
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffbd
li x9, 0x7e
sb x9, 0(x8)
li x8, 0x8fffffbe
li x9, 0xffffffffffffffff
sb x9, 0(x8)
li x8, 0x8fffffbf
li x9, 0xffffffffffffffff
sb x9, 0(x8)
li x8, 0x8fffffc0
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffc1
li x9, 0x7e
sb x9, 0(x8)
li x8, 0x8fffffc2
li x9, 0xffffffffffffffff
sb x9, 0(x8)
li x8, 0x8fffffc3
li x9, 0xffffffffffffffff
sb x9, 0(x8)
li x8, 0x8fffffc4
li x9, 0x11
sb x9, 0(x8)
li x8, 0x8fffffc5
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffc6
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffc7
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffc8
li x9, 0x1f
sb x9, 0(x8)
li x8, 0x8fffffc9
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffca
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffcb
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffcc
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffcd
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffce
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffcf
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffd0
li x9, 0xffffffffffffffa9
sb x9, 0(x8)
li x8, 0x8fffffd1
li x9, 0xffffffffffffffee
sb x9, 0(x8)
li x8, 0x8fffffd2
li x9, 0x30
sb x9, 0(x8)
li x8, 0x8fffffd3
li x9, 0xffffffffffffffeb
sb x9, 0(x8)
li x8, 0x8fffffd4
li x9, 0xffffffffffffffe6
sb x9, 0(x8)
li x8, 0x8fffffd5
li x9, 0xffffffffffffffff
sb x9, 0(x8)
li x8, 0x8fffffd6
li x9, 0xffffffffffffffff
sb x9, 0(x8)
li x8, 0x8fffffd7
li x9, 0xffffffffffffffff
sb x9, 0(x8)
li x8, 0x8fffffd8
li x9, 0xfffffffffffffff7
sb x9, 0(x8)
li x8, 0x8fffffd9
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffda
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffdb
li x9, 0x11
sb x9, 0(x8)
li x8, 0x8fffffdc
li x9, 0xffffffffffffffd4
sb x9, 0(x8)
li x8, 0x8fffffdd
li x9, 0xffffffffffffffcf
sb x9, 0(x8)
li x8, 0x8fffffde
li x9, 0xffffffffffffff86
sb x9, 0(x8)
li x8, 0x8fffffdf
li x9, 0xffffffffffffff94
sb x9, 0(x8)
li x8, 0x8fffffe0
li x9, 0x5d
sb x9, 0(x8)
li x8, 0x8fffffe1
li x9, 0xfffffffffffffff2
sb x9, 0(x8)
li x8, 0x8fffffe2
li x9, 0xffffffffffffffdd
sb x9, 0(x8)
li x8, 0x8fffffe3
li x9, 0xfffffffffffffffc
sb x9, 0(x8)
li x8, 0x8fffffe4
li x9, 0xffffffffffffffa4
sb x9, 0(x8)
li x8, 0x8fffffe5
li x9, 0x33
sb x9, 0(x8)
li x8, 0x8fffffe6
li x9, 0x6f
sb x9, 0(x8)
li x8, 0x8fffffe7
li x9, 0xffffffffffffffcd
sb x9, 0(x8)
li x8, 0x8fffffe8
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffe9
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffea
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffeb
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffec
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffed
li x9, 0x0
sb x9, 0(x8)
li x8, 0x8fffffee
li x9, 0xfffffffffffffff8
sb x9, 0(x8)
li x8, 0x8fffffef
li x9, 0x7f
sb x9, 0(x8)
li x8, 0x8ffffff0
li x9, 0x52
sb x9, 0(x8)
li x8, 0x8ffffff1
li x9, 0xfffffffffffffff2
sb x9, 0(x8)
li x8, 0x8ffffff2
li x9, 0xffffffffffffffd4
sb x9, 0(x8)
li x8, 0x8ffffff3
li x9, 0x69
sb x9, 0(x8)
li x8, 0x8ffffff4
li x9, 0xffffffffffffffee
sb x9, 0(x8)
li x8, 0x8ffffff5
li x9, 0x5d
sb x9, 0(x8)
li x8, 0x8ffffff6
li x9, 0x12
sb x9, 0(x8)
li x8, 0x8ffffff7
li x9, 0xffffffffffffffb7
sb x9, 0(x8)
li x8, 0xffffffffffff7e00
fmv.d.x f13, x8
li x8, 0xffffffff7fc00000
fmv.d.x f14, x8
li x8, 0x7ff8000000000000
fmv.d.x f15, x8
li x8, 0xffffffff7fc00000
fmv.d.x f16, x8
li x8, 0xffffffff7fc00000
fmv.d.x f17, x8
li x8, 0x7ff8000000000000
fmv.d.x f18, x8
li x8, 0x7ff8000000000000
fmv.d.x f19, x8
li x8, 0xffffffffffff7c00
fmv.d.x f20, x8
li x8, 0x8fffffc4
li x9, 0x8fffffc9
li x10, 0x8fffffb9
li x11, 0x8fffffbd
li x12, 0x8fffffb9
li x13, 0x15
li x14, 0x11
li x15, 0xffffffffffffffff
li x16, 0x15
li x17, 0x15
li x18, 0x11
li x19, 0xf0f0000
li x20, 0x11
rem x14, x18, x14

exit:
    li t0, 1 # report success
    la t1, tohost
    sd t0, 0(t1)
1:
    j 1b

    .align 2
trap_handler:
    csrr t0, mepc # faulting PC
    csrr t1, mcause # trap cause
    csrr t4, mtval

    slli t5, t1, 1 # strip interrupt bit
    srli t1, t5, 1

    li t2, 2 # default length assumes compressed
    li t3, 2 # illegal instruction -> mtval holds encoding
    beq t1, t3, use_mtval
    li t3, 1 # instruction access fault
    beq t1, t3, update_mepc
    li t3, 12 # instruction page fault
    beq t1, t3, update_mepc

    lhu t4, 0(t0)
    j decode_length

use_mtval:
    j decode_length

decode_length:
    andi t4, t4, 3
    li t3, 3
    bne t4, t3, compressed_len
    li t2, 4 # standard 32-bit instruction
    j update_mepc

compressed_len:
    li t2, 2 # compressed instruction

update_mepc:
    add t0, t0, t2 # skip offending instruction
    csrw mepc, t0
    csrw mcause, x0
    csrw mtval, x0
    mret

    .section .tohost,"aw",@progbits
    .align 6
    .globl tohost
    .globl fromhost
tohost:
    .dword 0
fromhost:
    .dword 0
