# 0 "/home/fuzz/runs/diff_spike_rocket/1793355722_536719846_rv64_1_w00/iter_000/Spike/program.S"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/home/fuzz/runs/diff_spike_rocket/1793355722_536719846_rv64_1_w00/iter_000/Spike/program.S"
    .section .text
    .globl _start

_start:
    la t0, trap_handler
    csrw mtvec, t0

    csrr t0, mstatus
    li t1, 0x00003000 # set FS field to Dirty (0b11) so FP regs usable
    or t0, t0, t1
    csrw mstatus, t0
    csrw fcsr, x0 # clear floating-point status

    # Relax PMP: one NAPOT entry covers the full address space to allow S-mode fetch/load/store
    li t0, -1
    csrw pmpaddr0, t0
    li t0, 0x1f # R|W|X | A=NAPOT
    csrw pmpcfg0, t0

    j user_code

user_code:
li x13, 0x864fcd8a3215d18b
li x14, 0x1cfad908fd1bd3ee
li x15, 0xeddf1055509e332d
li x16, 0x8d7fe21c8a648e01
li x17, 0x83e8eb2b0c7c94a
li x18, 0x42829f1a1b069b91
li x19, 0x35a5c6f56c364745
li x20, 0xc4665f0bf4b87793
li x8, 0xc9764b9252a434d
fmv.d.x f13, x8
li x8, 0xf46197b0c27a615a
fmv.d.x f14, x8
li x8, 0xe2f8ccc81808f4a6
fmv.d.x f15, x8
li x8, 0x76dc14e73739fa01
fmv.d.x f16, x8
li x8, 0xbd981c18507d2e33
fmv.d.x f17, x8
li x8, 0xacc96bac5af0edee
fmv.d.x f18, x8
li x8, 0x2dfad393aafadb9b
fmv.d.x f19, x8
li x8, 0x64da522e2cccc4df
fmv.d.x f20, x8
li x9, 0x8fffffb8
li x10, 0x23e0e01fb9803b9b
sd x10, 0(x9)
li x10, 0xab3db91a6e806ed5
sd x10, 8(x9)
li x10, 0xbcf22d001403a046
sd x10, 16(x9)
li x10, 0xd53b8962c819abf2
sd x10, 24(x9)
li x10, 0xd11dad1814be56df
sd x10, 32(x9)
li x10, 0xc6e6ee1eb2102847
sd x10, 40(x9)
li x10, 0x83980eebd2f6fca6
sd x10, 48(x9)
li x10, 0xa8476eeaada7ecc1
sd x10, 56(x9)
li x8, 0
li x9, 0
li x10, 0
li x11, 0
li x12, 0
remuw x17, x17, x19
c.sub x15, x15
fmv.x.h x16, f20
csrrs x20, fflags, x0
mulhsu x19, x17, x19
sraiw x19, x13, 26
feq.d x19, f14, f13
csrrs x19, fflags, x0
fmv.x.h x15, f14
csrrs x13, fflags, x0
addi x15, x13, 1204
czero.eqz x19, x18, x17
sraw x16, x16, x15
fmv.w.x f14, x20
csrrs x14, fflags, x0
fcvt.s.d f13, f19, dyn
csrrs x20, fflags, x0
fence.i
fcvt.w.d x15, f20, dyn
csrrs x13, fflags, x0
fli.h f18, 16.0
csrrs x13, fflags, x0
fcvt.d.wu f15, x20
csrrs x20, fflags, x0
li x12, 2415919050
sh x18, 14(x12)
srlw x18, x17, x19
feq.s x14, f19, f17
csrrs x13, fflags, x0
fcvt.wu.d x15, f15, rup
csrrs x18, fflags, x0
fmaxm.d f17, f18, f16
csrrs x14, fflags, x0
fli.h f16, 0x1.0p-15
csrrs x15, fflags, x0
bclri x18, x15, 43
fcvt.lu.s x13, f19, dyn
csrrs x13, fflags, x0
fltq.h x20, f15, f13
csrrs x18, fflags, x0
sh3add x14, x19, x16
li x11, 2415919056
ld x14, 14(x11)
minu x16, x20, x16
fli.d f20, -1.0
csrrs x18, fflags, x0
czero.nez x17, x16, x18
fmv.x.h x13, f19
csrrs x17, fflags, x0
addiw x19, x13, -1405
li x8, 2415919068
amomin.w.aq x15, x13, (x8)
sraw x20, x13, x18
fsqrt.s f17, f20, rne
csrrs x19, fflags, x0
fltq.h x16, f16, f19
csrrs x18, fflags, x0
or x14, x13, x20
fmaxm.h f15, f13, f15
csrrs x13, fflags, x0
li x2, 2415919038
c.lwsp x17, 16(sp)
mulh x14, x15, x19
fnmadd.s f15, f20, f16, f19, rtz
csrrs x15, fflags, x0
fli.h f15, 16.0
csrrs x13, fflags, x0
fli.s f14, 1.75
csrrs x18, fflags, x0
fence.i
binvi x20, x15, 44
fleq.h x13, f13, f14
csrrs x13, fflags, x0
sra x19, x15, x20
fmsub.s f16, f16, f17, f13, rup
csrrs x16, fflags, x0
czero.nez x16, x13, x13
fcvt.d.s f20, f13
csrrs x17, fflags, x0
li x8, 2415919066
amoadd.d.rl x16, x16, (x8)
czero.nez x20, x17, x14
fsub.d f13, f17, f14, dyn
csrrs x19, fflags, x0
feq.h x17, f15, f20
csrrs x20, fflags, x0
sltiu x14, x20, -1060
bclri x18, x13, 19
li x9, 2415919038
sb x19, 9(x9)
add.uw x20, x17, x18
slliw x15, x18, 19
li x10, 2415919047
amoor.d.rl x16, x16, (x10)
li x10, 2415919048
c.lw x13, 16(x10)
csrrsi x14, frm, 5
li x9, 2415919056
sb x13, 1(x9)
czero.eqz x13, x15, x20
fadd.s f18, f20, f18, rtz
csrrs x19, fflags, x0
fmv.x.h x19, f19
csrrs x16, fflags, x0
fcvt.s.h f16, f20
csrrs x13, fflags, x0
fmaxm.s f18, f14, f20
csrrs x19, fflags, x0
li x11, 2415919059
lhu x18, 4(x11)
c.lui x19, 0xfffeb
fminm.d f17, f14, f17
csrrs x17, fflags, x0
sub x15, x13, x14
fsgnj.s f13, f18, f19
csrrs x19, fflags, x0
fminm.h f14, f18, f17
csrrs x13, fflags, x0
fltq.h x20, f14, f13
csrrs x14, fflags, x0
fleq.d x13, f16, f17
csrrs x20, fflags, x0
xor x15, x14, x15
froundnx.s f16, f20, dyn
csrrs x20, fflags, x0
li x11, 2415919058
fsw f16, 13(x11)
csrrs x14, fflags, x0
li x9, 2415919059
amomin.w.aq x20, x13, (x9)
fcvt.s.wu f18, x18, rtz
csrrs x13, fflags, x0
c.subw x13, x14
fcvt.h.d f15, f17, rmm
csrrs x15, fflags, x0
li x11, 2415919052
lhu x15, 7(x11)
fsgnjn.h f17, f16, f16
csrrs x20, fflags, x0
fleq.d x19, f17, f16
csrrs x17, fflags, x0
li x12, 2415919044
sw x19, 1(x12)
mul x20, x17, x16
fcvt.d.h f18, f14
csrrs x14, fflags, x0
c.addi x13, 24
fminm.d f14, f17, f18
csrrs x14, fflags, x0
fmaxm.d f18, f19, f19
csrrs x17, fflags, x0
fmadd.h f14, f18, f17, f14, rne
csrrs x18, fflags, x0
li x9, 2415919052
amoadd.d.aq x15, x16, (x9)
cpopw x17, x20
fcvt.h.wu f20, x20, dyn
csrrs x17, fflags, x0
divw x15, x17, x14
sllw x19, x17, x19
li x8, 2415919036
amomax.w x13, x13, (x8)
c.nop
c.addw x13, x14
li x11, 2415919065
fld f17, 3(x11)
csrrs x19, fflags, x0
fsub.h f16, f16, f16, rdn
csrrs x19, fflags, x0
fdiv.h f13, f19, f18, rmm
csrrs x15, fflags, x0
c.xor x13, x13
li x9, 2415919068
fld f18, 14(x9)
csrrs x18, fflags, x0
or x17, x13, x16
mulhu x13, x17, x15
fclass.s x20, f19
csrrs x19, fflags, x0
fmaxm.d f17, f14, f17
csrrs x20, fflags, x0
mulhsu x15, x20, x14
sext.b x19, x20
fmax.h f15, f19, f19
csrrs x17, fflags, x0
fsgnjx.d f20, f14, f20
csrrs x13, fflags, x0
clz x17, x14
sub x18, x15, x13
clz x18, x15
addi x18, x16, 1832
fsqrt.s f13, f20, rdn
csrrs x13, fflags, x0
li x9, 2415919055
amoand.w.rl x20, x19, (x9)
fmax.s f15, f18, f14
csrrs x19, fflags, x0
fcvt.d.s f15, f20
csrrs x15, fflags, x0
czero.nez x15, x19, x18
li x8, 2415919039
sw x15, 12(x8)
xor x17, x18, x16
fence.i
ctzw x13, x14
fcvt.d.wu f20, x17
csrrs x19, fflags, x0
czero.nez x16, x17, x15
li x9, 2415919063
amomin.d.aq x16, x16, (x9)
fsub.d f13, f19, f20, dyn
csrrs x18, fflags, x0
sext.h x18, x17
fadd.s f19, f18, f20, rtz
csrrs x19, fflags, x0
fcvt.h.s f14, f15, rup
csrrs x17, fflags, x0
minu x18, x20, x17
fmv.x.h x19, f13
csrrs x19, fflags, x0
cpopw x19, x18
lui x19, 856064
li x12, 2415919059
amoxor.w.rl x20, x18, (x12)
sh3add.uw x15, x13, x18
feq.d x14, f14, f18
csrrs x18, fflags, x0
c.li x15, 16
sext.h x13, x15
fminm.d f13, f14, f13
csrrs x17, fflags, x0
czero.eqz x20, x14, x14
fcvt.d.lu f18, x14, rmm
csrrs x16, fflags, x0
fle.d x14, f13, f14
csrrs x19, fflags, x0
li x9, 2415919056
fld f14, 9(x9)
csrrs x18, fflags, x0
fmin.d f17, f15, f20
csrrs x18, fflags, x0
li x12, 2415919052
amomaxu.d.rl x16, x16, (x12)
rem x16, x13, x17
fcvt.l.d x19, f19, dyn
csrrs x15, fflags, x0
srai x16, x18, 46
flt.s x15, f20, f19
csrrs x15, fflags, x0
fminm.s f19, f16, f20
csrrs x16, fflags, x0
fsqrt.d f19, f17, dyn
csrrs x16, fflags, x0
flt.s x20, f17, f20
csrrs x14, fflags, x0
fleq.h x15, f13, f18
csrrs x20, fflags, x0
fltq.s x18, f18, f14
csrrs x20, fflags, x0
sltiu x15, x20, -2010
fcvt.h.lu f16, x14, dyn
csrrs x19, fflags, x0
bclri x16, x15, 52
minu x20, x16, x17
bseti x19, x15, 32
fmsub.h f14, f19, f13, f20, rmm
csrrs x18, fflags, x0
divw x19, x18, x14
sh3add.uw x15, x13, x13
mul x19, x19, x16
slt x18, x16, x15
or x13, x14, x16
li x10, 2415919058
amominu.d.rl x15, x16, (x10)
xor x17, x18, x16
fsgnj.d f13, f19, f13
csrrs x18, fflags, x0
binv x18, x17, x15
orc.b x20, x14
fround.h f16, f17, rtz
csrrs x19, fflags, x0
sext.b x17, x15
addiw x13, x13, -1107
fmul.d f18, f18, f16, rmm
csrrs x15, fflags, x0
sext.b x19, x20
remw x15, x15, x14
clz x18, x20
clzw x13, x20
li x2, 2415919061
c.sdsp x17, 8(sp)
bclr x20, x16, x19
fdiv.h f16, f18, f18, rup
csrrs x13, fflags, x0
sh3add.uw x19, x15, x18
fadd.h f18, f19, f20, rmm
csrrs x14, fflags, x0
fminm.h f15, f14, f15
csrrs x17, fflags, x0
li x9, 2415919064
c.sw x14, 16(x9)
fadd.d f14, f16, f20, rtz
csrrs x15, fflags, x0
addw x17, x14, x18
fnmadd.s f13, f18, f13, f13, rup
csrrs x14, fflags, x0
fmax.d f19, f18, f17
csrrs x16, fflags, x0
csrrwi x13, dscratch0, 21
ori x18, x14, -73
fnmsub.s f17, f18, f15, f14, dyn
csrrs x18, fflags, x0
c.srai x15, 13
fsub.s f20, f15, f19, rmm
csrrs x17, fflags, x0
fadd.h f17, f15, f17, rne
csrrs x20, fflags, x0
fmsub.s f18, f18, f19, f19, rup
csrrs x20, fflags, x0
fcvt.wu.h x19, f19, rmm
csrrs x13, fflags, x0
fcvt.w.d x16, f13, dyn
csrrs x14, fflags, x0
fence.i
sub x20, x18, x20
fmax.s f18, f14, f16
csrrs x16, fflags, x0
fclass.h x18, f14
csrrs x15, fflags, x0
fsgnjx.s f17, f13, f16
csrrs x16, fflags, x0
fcvt.lu.d x14, f14, rne
csrrs x19, fflags, x0
fround.d f14, f20, rup
csrrs x19, fflags, x0
fmadd.h f17, f13, f15, f16, dyn
csrrs x15, fflags, x0
fsub.d f19, f17, f15, rtz
csrrs x14, fflags, x0
bexti x20, x15, 48
fadd.d f13, f15, f18, rne
csrrs x16, fflags, x0
add.uw x19, x14, x18
flt.h x13, f14, f16
csrrs x20, fflags, x0
li x11, 2415919032
amomax.w.aqrl x18, x18, (x11)
li x12, 2415919065
sh x17, 16(x12)
fround.d f20, f14, rmm
csrrs x17, fflags, x0
fli.h f14, 0x1.0p-15
csrrs x19, fflags, x0
fround.s f13, f20, rup
csrrs x17, fflags, x0
srli x15, x16, 3
fmaxm.d f18, f14, f13
csrrs x16, fflags, x0
fcvt.lu.d x18, f20, rtz
csrrs x13, fflags, x0
fcvt.h.w f15, x17, rup
csrrs x13, fflags, x0
binvi x15, x13, 3
sh2add x17, x15, x17
fltq.h x16, f19, f18
csrrs x18, fflags, x0
fcvt.wu.d x15, f19, rtz
csrrs x20, fflags, x0
fnmsub.d f18, f20, f20, f15, dyn
csrrs x14, fflags, x0
li x12, 2415919061
amomaxu.d.aq x20, x15, (x12)
fence.i
li x11, 2415919061
amoswap.d.aqrl x18, x13, (x11)
li x9, 2415919040
lhu x16, 15(x9)
fadd.s f14, f14, f14, rmm
csrrs x15, fflags, x0
c.addi x15, -19
fltq.d x13, f19, f20
csrrs x20, fflags, x0
andi x17, x20, 1151
li x11, 2415919063
lh x15, 12(x11)
srai x13, x19, 36
fmax.d f20, f19, f20
csrrs x13, fflags, x0
c.srli x15, 21
fclass.h x19, f18
csrrs x17, fflags, x0
srliw x17, x20, 23
fcvt.lu.d x16, f20, rne
csrrs x14, fflags, x0
divuw x14, x16, x14
c.mv x20, x13
bext x15, x19, x18
srl x13, x15, x19
li x11, 2415919035
sw x19, 13(x11)
mulhsu x16, x20, x15
li x8, 2415919042
lb x17, 11(x8)
fcvt.wu.d x19, f17, rdn
csrrs x19, fflags, x0
froundnx.s f13, f19, rtz
csrrs x18, fflags, x0
fmsub.d f17, f20, f20, f16, rtz
csrrs x18, fflags, x0
fcvt.wu.h x13, f16, dyn
csrrs x20, fflags, x0
li x11, 2415919033
fsh f18, 0(x11)
csrrs x19, fflags, x0
fminm.s f14, f13, f16
csrrs x13, fflags, x0
fsub.h f17, f13, f14, rne
csrrs x17, fflags, x0
csrrwi x19, dpc, 23
sh1add.uw x20, x15, x20
froundnx.d f20, f16, rtz
csrrs x20, fflags, x0
li x11, 2415919063
amoadd.w.aq x18, x17, (x11)
c.lui x17, 0x16
li x12, 2415919057
sd x19, 16(x12)
fcvt.s.h f18, f15
csrrs x17, fflags, x0
mul x19, x14, x15
li x11, 2415919048
fld f15, 16(x11)
csrrs x17, fflags, x0
li x11, 2415919043
sd x19, 2(x11)
fcvt.s.d f20, f16, rtz
csrrs x13, fflags, x0
fsgnjn.h f19, f18, f13
csrrs x13, fflags, x0
li x18, -9223372036854775793
csrrc x14, mcause, x18
fcvt.w.s x16, f14, rtz
csrrs x20, fflags, x0
fle.s x19, f15, f19
csrrs x20, fflags, x0
sext.h x16, x13
czero.nez x18, x19, x19
fcvt.lu.s x17, f17, rup
csrrs x20, fflags, x0
remuw x15, x15, x20
fsgnj.h f15, f15, f13
csrrs x13, fflags, x0
divuw x19, x15, x18
and x16, x15, x17
slt x17, x13, x15
li x2, 2415919066
c.ldsp x14, 16(sp)
fcvtmod.w.d x20, f14, rtz
csrrs x17, fflags, x0
li x10, 2415919040
amoor.d x20, x15, (x10)
fsqrt.s f13, f15, rne
csrrs x18, fflags, x0
srai x17, x20, 29
fmv.d.x f19, x18
csrrs x14, fflags, x0
fcvt.h.d f20, f20, dyn
csrrs x17, fflags, x0
c.nop
fadd.h f13, f14, f18, rtz
csrrs x14, fflags, x0
fmul.s f15, f17, f19, rne
csrrs x20, fflags, x0
fmv.h.x f19, x18
csrrs x18, fflags, x0
fence.i
sext.h x16, x14
addi x18, x13, -995
orc.b x18, x18
fle.d x14, f14, f14
csrrs x14, fflags, x0
fcvt.l.s x16, f16, rtz
csrrs x16, fflags, x0
sub x15, x13, x13
li x8, 2415919071
c.sw x13, 12(x8)
binvi x13, x14, 50
li x10, 2415919070
ld x13, 2(x10)
c.or x14, x13
fmadd.h f14, f14, f19, f17, rmm
csrrs x20, fflags, x0
li x12, 2415919052
c.sd x14, 16(x12)
li x12, 2415919056
amoor.w x19, x14, (x12)
fcvt.h.lu f15, x18, rmm
csrrs x16, fflags, x0
fmsub.h f13, f19, f19, f15, rmm
csrrs x18, fflags, x0
fsqrt.h f17, f16, rup
csrrs x13, fflags, x0
li x8, 2415919062
amoswap.d x15, x19, (x8)
li x16, 1282502748940356332
csrrs x13, instret, x16
slliw x17, x20, 29
fsub.d f19, f15, f13, rne
csrrs x14, fflags, x0
li x10, 2415919066
fsw f16, 16(x10)
csrrs x17, fflags, x0
fence.i
mul x16, x13, x17
li x12, 2415919032
amoor.w x13, x16, (x12)
sh2add x15, x15, x19
fcvt.l.h x17, f13, dyn
csrrs x17, fflags, x0
fcvt.l.d x16, f19, rmm
csrrs x14, fflags, x0
fmv.x.w x20, f13
csrrs x14, fflags, x0
fround.h f16, f14, rtz
csrrs x18, fflags, x0
sh1add x15, x19, x13
li x9, 2415919042
amomin.w.aq x18, x16, (x9)
sext.h x14, x17
fence.i
li x12, 2415919063
amoxor.w.aq x18, x13, (x12)
fadd.s f13, f16, f16, dyn
csrrs x18, fflags, x0
srl x17, x14, x17
slti x20, x18, -156
fence.i
fminm.h f18, f18, f18
csrrs x13, fflags, x0
fmul.s f20, f19, f13, rtz
csrrs x17, fflags, x0
lui x20, 966656
bseti x13, x13, 47
fcvt.d.l f13, x20, dyn
csrrs x15, fflags, x0
flt.h x20, f15, f17
csrrs x17, fflags, x0
fmaxm.d f15, f20, f19
csrrs x20, fflags, x0
lui x13, 307200
mulh x16, x13, x15
c.sub x13, x15
ori x13, x13, 61
li x9, 2415919057
amomin.d x20, x18, (x9)
fcvt.w.s x20, f14, dyn
csrrs x16, fflags, x0
fnmsub.s f18, f18, f19, f14, rdn
csrrs x13, fflags, x0
czero.nez x19, x18, x16
li x8, 2415919049
ld x20, 14(x8)
czero.nez x18, x16, x13
sh3add.uw x14, x15, x15
binv x14, x16, x15
fcvt.h.s f18, f13, dyn
csrrs x18, fflags, x0
fsqrt.s f13, f15, rne
csrrs x13, fflags, x0
li x8, 2415919058
amomaxu.d.aq x17, x18, (x8)
c.or x15, x14
fcvt.l.s x17, f14, dyn
csrrs x18, fflags, x0
cpopw x14, x13
fsgnjx.s f19, f15, f15
csrrs x14, fflags, x0
fcvt.d.wu f18, x15
csrrs x14, fflags, x0
sltiu x14, x19, 1203
li x12, 2415919066
fsw f13, 12(x12)
csrrs x15, fflags, x0
li x12, 2415919058
ld x20, 5(x12)
divuw x18, x20, x17
fsgnjx.d f14, f18, f20
csrrs x20, fflags, x0
fcvt.h.d f13, f15, rdn
csrrs x18, fflags, x0
fcvt.w.h x13, f19, dyn
csrrs x20, fflags, x0
li x10, 2415919038
fld f15, 6(x10)
csrrs x18, fflags, x0
li x12, 2415919035
c.sd x15, 0(x12)
fround.d f19, f18, rne
csrrs x13, fflags, x0
li x9, 2415919062
amomin.d.aqrl x20, x19, (x9)
fmv.h.x f19, x20
csrrs x20, fflags, x0
froundnx.h f20, f15, rtz
csrrs x13, fflags, x0
li x8, 2415919043
amoxor.d.aq x13, x16, (x8)
fcvtmod.w.d x20, f19, rtz
csrrs x13, fflags, x0
li x11, 2415919042
fsd f16, 14(x11)
csrrs x18, fflags, x0
c.slli x14, 52
sll x19, x13, x19
li x9, 2415919072
amoadd.d.aq x20, x13, (x9)
li x9, 2415919068
lbu x14, 10(x9)
fmadd.d f13, f20, f19, f14, rne
csrrs x20, fflags, x0
fmin.d f14, f20, f18
csrrs x20, fflags, x0
li x11, 2415919042
amoor.w.aqrl x13, x18, (x11)
fdiv.h f20, f14, f15, dyn
csrrs x20, fflags, x0
c.subw x13, x14
fcvt.s.lu f18, x20, dyn
csrrs x20, fflags, x0
li x11, 2415919035
amomax.w.rl x13, x14, (x11)
orc.b x19, x14
flt.s x19, f20, f20
csrrs x15, fflags, x0
fmv.w.x f15, x17
csrrs x17, fflags, x0
li x2, 2415919047
c.lwsp x16, 4(sp)
fcvt.s.l f19, x20, rne
csrrs x15, fflags, x0
c.srai x15, 58
divw x19, x20, x17
li x12, 2415919033
sd x20, 6(x12)
c.sub x15, x15
fcvt.s.wu f15, x15, rdn
csrrs x14, fflags, x0
fsgnjn.h f15, f17, f16
csrrs x14, fflags, x0
fmaxm.s f14, f17, f19
csrrs x19, fflags, x0
fmadd.s f17, f17, f17, f14, rmm
csrrs x15, fflags, x0
xor x15, x19, x16
minu x13, x15, x15
feq.s x19, f15, f17
csrrs x18, fflags, x0
fcvt.h.d f20, f15, rmm
csrrs x16, fflags, x0
fminm.h f18, f16, f18
csrrs x15, fflags, x0
remuw x20, x17, x15
c.slli x17, 43
c.li x15, 13
sext.b x18, x17
czero.nez x14, x20, x13
binvi x18, x13, 55
divw x20, x17, x13
fsgnj.h f15, f16, f13
csrrs x15, fflags, x0
c.addi x16, 29
bclri x20, x13, 27
fltq.h x13, f14, f18
csrrs x15, fflags, x0
fadd.d f15, f13, f13, rtz
csrrs x15, fflags, x0
c.mv x16, x19
li x9, 2415919042
amomaxu.w.aqrl x17, x17, (x9)
li x12, 2415919059
fld f14, 7(x12)
csrrs x20, fflags, x0
fence.i
fnmadd.s f13, f19, f13, f18, rmm
csrrs x13, fflags, x0
li x10, 2415919038
lhu x19, 3(x10)
fsgnjx.s f13, f17, f18
csrrs x20, fflags, x0
li x8, 2415919042
amoswap.d.aqrl x19, x13, (x8)
li x12, 2415919070
fld f17, 6(x12)
csrrs x14, fflags, x0
fmv.h.x f13, x18
csrrs x17, fflags, x0
cpop x17, x19
c.ebreak
fminm.h f19, f14, f19
csrrs x19, fflags, x0
binv x19, x16, x16
c.slli x15, 27
sraiw x13, x16, 30
div x18, x16, x15
c.addi16sp sp, 16
fclass.s x18, f19
csrrs x13, fflags, x0
sltu x16, x14, x19
remu x13, x18, x13
c.subw x15, x15
feq.d x14, f13, f13
csrrs x17, fflags, x0
fcvt.s.h f20, f14
csrrs x20, fflags, x0
li x2, 2415919055
c.ldsp x18, 0(sp)
fdiv.d f16, f18, f15, dyn
csrrs x15, fflags, x0
remu x17, x16, x16
fmaxm.s f19, f17, f15
csrrs x14, fflags, x0
li x10, 2415919071
lw x14, 15(x10)
sh2add.uw x14, x18, x18
fcvt.d.wu f15, x13
csrrs x19, fflags, x0
fcvt.w.d x17, f19, rup
csrrs x13, fflags, x0
fcvt.wu.d x20, f15, dyn
csrrs x19, fflags, x0
li x12, 2415919052
c.sd x13, 8(x12)
li x9, 2415919033
c.ld x13, 0(x9)
slti x14, x15, 1403
fcvt.lu.s x16, f17, rdn
csrrs x15, fflags, x0
li x12, 2415919051
amomin.d x17, x17, (x12)
sh2add x17, x18, x20
bset x18, x19, x15
c.addiw x13, 10
fence.i
fli.h f14, 32768.0
csrrs x20, fflags, x0
divuw x19, x19, x20
c.ebreak
fmax.d f19, f15, f15
csrrs x18, fflags, x0
sh2add.uw x19, x15, x18
zext.h x20, x14
fmadd.h f16, f13, f16, f15, dyn
csrrs x16, fflags, x0
slli.uw x20, x13, 63
li x10, 2415919052
lw x18, 12(x10)
li x12, 2415919038
amoadd.d x17, x17, (x12)
fnmadd.h f17, f14, f14, f14, rne
csrrs x18, fflags, x0
li x9, 2415919046
amoxor.d.aqrl x19, x13, (x9)
fleq.h x14, f17, f17
csrrs x14, fflags, x0
sltu x17, x13, x17
fcvt.h.lu f17, x18, dyn
csrrs x20, fflags, x0
li x12, 2415919064
sd x18, 15(x12)
li x10, 2415919052
lwu x16, 16(x10)
c.srai x15, 28
li x2, 2415919066
c.sdsp x16, 16(sp)
fmaxm.d f18, f14, f18
csrrs x14, fflags, x0
remw x15, x13, x19
slti x20, x15, -307
sh3add x17, x13, x18
c.srli x13, 61
fclass.d x19, f20
csrrs x13, fflags, x0
fminm.s f14, f14, f15
csrrs x20, fflags, x0
sra x19, x20, x16
li x11, 2415919047
amoxor.w.rl x19, x18, (x11)
li x10, 2415919047
lhu x13, 9(x10)
fclass.d x13, f17
csrrs x14, fflags, x0
bseti x14, x20, 37
divuw x14, x14, x18
fcvt.lu.h x19, f15, rne
csrrs x13, fflags, x0
add.uw x15, x18, x18
fminm.s f17, f20, f16
csrrs x16, fflags, x0
feq.s x16, f17, f15
csrrs x13, fflags, x0
ctzw x15, x13
li x12, 2415919035
sh x19, 9(x12)
fnmadd.h f16, f13, f19, f16, dyn
csrrs x18, fflags, x0
fltq.h x15, f13, f16
csrrs x18, fflags, x0
srli x20, x15, 23
sraw x13, x19, x13
fclass.d x14, f19
csrrs x17, fflags, x0
fmul.h f16, f16, f19, rdn
csrrs x16, fflags, x0
czero.eqz x19, x18, x15
li x9, 2415919054
amomin.d.aq x13, x17, (x9)
li x9, 2415919057
amomin.w.aqrl x17, x18, (x9)
cpop x16, x14
max x18, x18, x16
fcvt.s.lu f14, x17, dyn
csrrs x14, fflags, x0
c.srai x14, 23
fmv.h.x f19, x13
csrrs x13, fflags, x0
div x13, x14, x19
fsub.d f14, f17, f14, dyn
csrrs x14, fflags, x0
fmv.d.x f17, x17
csrrs x18, fflags, x0
fminm.s f16, f19, f14
csrrs x20, fflags, x0
fence.i
sllw x16, x17, x17
li x10, 2415919054
amominu.w.aq x13, x15, (x10)
fcvt.s.wu f16, x13, rup
csrrs x14, fflags, x0
fmv.x.h x18, f16
csrrs x14, fflags, x0
fsub.d f15, f13, f20, rup
csrrs x14, fflags, x0
c.and x14, x15
fmadd.d f19, f17, f18, f14, dyn
csrrs x20, fflags, x0
fcvt.d.l f16, x19, rtz
csrrs x17, fflags, x0
fmul.s f14, f17, f15, dyn
csrrs x14, fflags, x0
flt.h x15, f16, f13
csrrs x19, fflags, x0
fsqrt.s f18, f20, dyn
csrrs x13, fflags, x0
li x9, 2415919059
c.ld x14, 16(x9)
li x12, 2415919060
amoadd.w.aqrl x14, x15, (x12)
sh1add x20, x16, x17
czero.eqz x14, x14, x15
or x14, x20, x14
sh3add.uw x14, x14, x13
fli.d f18, 1.75
csrrs x16, fflags, x0
bclri x19, x15, 63
fsub.h f20, f17, f19, rup
csrrs x14, fflags, x0
c.add x20, x14
li x11, 2415919066
amominu.w x14, x16, (x11)
c.add x15, x18
fcvt.d.l f17, x14, rtz
csrrs x19, fflags, x0
c.add x15, x20
li x10, 2415919051
fsh f17, 12(x10)
csrrs x13, fflags, x0
fround.s f18, f17, dyn
csrrs x20, fflags, x0
c.nop
minu x15, x19, x19
c.andi x14, -17
fnmsub.s f17, f19, f16, f20, dyn
csrrs x16, fflags, x0
remw x20, x18, x14
addiw x17, x13, 1409
sraiw x19, x19, 17
li x10, 2415919060
amomin.d.aq x15, x20, (x10)
li x9, 2415919043
c.lw x13, 8(x9)
fsgnjx.s f15, f17, f20
csrrs x16, fflags, x0
fmv.h.x f15, x13
csrrs x17, fflags, x0
fmv.x.h x15, f19
csrrs x15, fflags, x0
c.ebreak
li x11, 2415919068
fsh f20, 1(x11)
csrrs x13, fflags, x0
li x11, 2415919055
lw x19, 9(x11)
lui x20, 126976
binv x20, x15, x20
li x12, 2415919042
amominu.w x16, x13, (x12)
srli x20, x13, 62
fsub.s f17, f18, f20, rdn
csrrs x13, fflags, x0
fminm.h f19, f19, f20
csrrs x16, fflags, x0
li x8, 2415919068
fsw f20, 16(x8)
csrrs x15, fflags, x0
fcvt.h.l f20, x13, rdn
csrrs x20, fflags, x0
xori x16, x19, -1695
li x9, 2415919037
sd x17, 5(x9)
froundnx.h f15, f20, dyn
csrrs x14, fflags, x0
c.li x15, -22
li x10, 2415919067
sd x20, 9(x10)
feq.h x18, f13, f16
csrrs x19, fflags, x0
mulh x15, x19, x13
fsgnjn.d f15, f16, f20
csrrs x20, fflags, x0
fsgnjx.d f18, f17, f13
csrrs x20, fflags, x0
zext.h x16, x16
fmaxm.h f17, f13, f19
csrrs x14, fflags, x0
czero.nez x18, x19, x14
fmsub.d f14, f14, f17, f13, rdn
csrrs x19, fflags, x0
fsgnjn.d f17, f17, f20
csrrs x14, fflags, x0
li x8, 2415919035
flw f15, 1(x8)
csrrs x14, fflags, x0
li x10, 2415919071
amomin.d x18, x13, (x10)
fcvt.w.h x15, f18, dyn
csrrs x15, fflags, x0
minu x18, x13, x14
fnmadd.d f17, f13, f20, f15, rdn
csrrs x18, fflags, x0
froundnx.h f16, f15, rtz
csrrs x14, fflags, x0
li x10, 2415919065
lhu x13, 3(x10)
bext x13, x14, x15
mulh x14, x15, x16
remu x18, x19, x17
or x19, x19, x19
fsqrt.s f16, f15, rtz
csrrs x15, fflags, x0
fmin.d f20, f14, f16
csrrs x14, fflags, x0
fcvt.h.s f19, f20, rmm
csrrs x13, fflags, x0
li x18, -9172395561500459229
csrrw x14, mtval, x18
fdiv.s f17, f20, f15, dyn
csrrs x18, fflags, x0
sllw x15, x15, x20
srli x16, x16, 58
c.addiw x17, 18
andi x19, x20, 729
flt.d x16, f19, f19
csrrs x20, fflags, x0
sltiu x16, x14, -317
c.lui x14, 0xfffe0
li x12, 2415919066
flh f19, 12(x12)
csrrs x18, fflags, x0
sltu x16, x19, x18
fdiv.s f13, f17, f16, rmm
csrrs x16, fflags, x0
li x12, 2415919067
lbu x18, 4(x12)
c.srai x13, 23
li x10, 2415919070
amomaxu.w.aqrl x14, x20, (x10)
fround.h f18, f18, rdn
csrrs x17, fflags, x0
li x18, 17
csrrs x14, fcsr, x18
sh3add.uw x15, x13, x20
fcvt.h.d f16, f20, dyn
csrrs x16, fflags, x0
li x12, 2415919066
fsw f17, 7(x12)
csrrs x20, fflags, x0
minu x13, x17, x15
fli.s f20, 8.0
csrrs x14, fflags, x0
slliw x19, x18, 11
fsgnj.s f20, f14, f14
csrrs x17, fflags, x0
fsqrt.h f19, f17, rtz
csrrs x16, fflags, x0
cpop x13, x20
mulw x19, x16, x13
sh3add x13, x19, x16
fsgnjn.d f17, f18, f19
csrrs x13, fflags, x0
fli.d f14, 2.0
csrrs x17, fflags, x0
li x2, 2415919043
c.ldsp x14, 16(sp)
sllw x18, x20, x14
fcvt.l.d x17, f14, rne
csrrs x17, fflags, x0
fcvt.s.wu f20, x13, rmm
csrrs x13, fflags, x0
li x12, 2415919048
lw x18, 12(x12)
li x2, 2415919049
c.lwsp x14, 4(sp)
fmadd.h f15, f13, f13, f13, rup
csrrs x19, fflags, x0
sh3add.uw x15, x19, x18
fmadd.s f17, f18, f20, f19, dyn
csrrs x17, fflags, x0
sh2add x19, x15, x17
fltq.h x20, f15, f14
csrrs x19, fflags, x0
lui x13, 905216
remu x15, x16, x18
c.and x15, x13
ctzw x19, x17
fsqrt.h f16, f19, rup
csrrs x19, fflags, x0
fclass.d x14, f13
csrrs x19, fflags, x0
divu x18, x17, x14
fcvt.l.h x13, f20, dyn
csrrs x19, fflags, x0
fclass.s x16, f15
csrrs x13, fflags, x0
fence.i
fcvt.d.h f13, f16
csrrs x16, fflags, x0
fle.h x20, f20, f15
csrrs x14, fflags, x0
fence.i
fround.d f20, f14, rmm
csrrs x17, fflags, x0
c.andi x15, 14
fmin.s f14, f14, f19
csrrs x15, fflags, x0
li x11, 2415919059
amoxor.d.aq x13, x19, (x11)
sh1add x13, x15, x16
cpopw x15, x20
cpopw x13, x20
fence.i
czero.eqz x14, x20, x19
fmv.d.x f13, x19
csrrs x17, fflags, x0
fcvt.d.w f20, x14
csrrs x15, fflags, x0
fmv.w.x f15, x20
csrrs x13, fflags, x0
fsgnjx.s f19, f19, f14
csrrs x13, fflags, x0
c.addi x16, -26
addw x16, x19, x19
fcvt.s.d f14, f20, dyn
csrrs x16, fflags, x0
fmadd.d f14, f14, f13, f16, rtz
csrrs x20, fflags, x0
li x12, 2415919068
amoadd.d.aqrl x17, x15, (x12)
fcvt.d.lu f13, x16, rmm
csrrs x17, fflags, x0
fcvt.l.s x14, f15, rmm
csrrs x14, fflags, x0
slli x13, x20, 26
fcvt.lu.s x19, f19, rdn
csrrs x19, fflags, x0
fcvt.h.lu f18, x15, dyn
csrrs x17, fflags, x0
li x2, 2415919072
c.sdsp x18, 8(sp)
li x11, 2415919061
sw x13, 3(x11)
fleq.s x14, f19, f17
csrrs x16, fflags, x0
fmaxm.s f17, f13, f20
csrrs x13, fflags, x0
czero.nez x19, x20, x20
fence.i
fence.i
mulhsu x16, x20, x18
fsgnj.s f18, f13, f19
csrrs x17, fflags, x0
fcvt.d.l f20, x13, rmm
csrrs x17, fflags, x0
fnmadd.h f15, f20, f20, f14, rtz
csrrs x18, fflags, x0
fmadd.s f15, f13, f15, f13, dyn
csrrs x17, fflags, x0
minu x16, x17, x19
fcvt.s.l f15, x15, rne
csrrs x19, fflags, x0
fence.i
fmaxm.d f17, f18, f14
csrrs x19, fflags, x0
fmsub.h f14, f19, f16, f14, rup
csrrs x17, fflags, x0
fminm.d f14, f20, f19
csrrs x14, fflags, x0
fsgnjx.s f15, f17, f18
csrrs x17, fflags, x0
li x8, 2415919044
lwu x13, 4(x8)
c.nop
fli.s f15, 0.5
csrrs x13, fflags, x0
sllw x14, x16, x13
fli.s f13, 0x1.0p-7
csrrs x17, fflags, x0
fcvt.lu.s x19, f14, rup
csrrs x15, fflags, x0
sra x17, x20, x16
fmax.h f17, f13, f19
csrrs x19, fflags, x0
c.or x14, x13
sltiu x15, x20, 1762
fence io, io
c.add x14, x16
mulhsu x13, x20, x19
fminm.s f17, f16, f17
csrrs x13, fflags, x0
bext x14, x20, x16
fleq.d x16, f17, f16
csrrs x14, fflags, x0
bext x18, x15, x13
fleq.s x14, f20, f16
csrrs x20, fflags, x0
c.xor x13, x15
li x11, 2415919042
amominu.w x17, x13, (x11)
froundnx.d f15, f16, rdn
csrrs x17, fflags, x0
li x11, 2415919040
amoswap.w.rl x17, x17, (x11)
fsgnj.s f20, f19, f16
csrrs x16, fflags, x0
li x9, 2415919070
amomin.w x19, x15, (x9)
andi x14, x15, 1066
addi x16, x14, 823
c.srai x15, 21
fadd.d f19, f13, f14, dyn
csrrs x14, fflags, x0
fleq.h x17, f13, f16
csrrs x19, fflags, x0
li x12, 2415919067
amoor.w.rl x15, x18, (x12)
feq.h x15, f15, f19
csrrs x16, fflags, x0
mulhsu x18, x16, x16
fmin.s f18, f13, f15
csrrs x18, fflags, x0
li x11, 2415919056
amomaxu.d x19, x17, (x11)
fence orw, iw
fmul.d f18, f20, f16, dyn
csrrs x14, fflags, x0
fnmsub.h f20, f19, f17, f15, rne
csrrs x16, fflags, x0
fmadd.h f20, f13, f18, f17, rdn
csrrs x17, fflags, x0
sll x14, x17, x20
fclass.d x14, f14
csrrs x18, fflags, x0
addw x20, x16, x14
fsqrt.h f17, f20, dyn
csrrs x15, fflags, x0
bseti x15, x20, 7
c.lui x18, 0x17
c.srli x13, 20
fcvt.s.wu f19, x14, rmm
csrrs x15, fflags, x0
fli.d f18, 1.75
csrrs x19, fflags, x0
ctz x15, x19
czero.eqz x17, x15, x14
slliw x20, x18, 8
c.add x17, x16
fsub.h f15, f20, f14, dyn
csrrs x16, fflags, x0
flt.s x18, f14, f16
csrrs x14, fflags, x0
fmul.s f20, f13, f20, dyn
csrrs x15, fflags, x0
fmsub.d f19, f16, f17, f15, rne
csrrs x16, fflags, x0
li x10, 2415919060
lb x15, 5(x10)
fcvt.s.wu f16, x15, rdn
csrrs x17, fflags, x0
srai x20, x20, 41
fsgnjx.h f20, f17, f19
csrrs x19, fflags, x0
li x10, 2415919034
sw x16, 16(x10)
fcvt.h.w f14, x20, rtz
csrrs x18, fflags, x0
fsgnj.d f17, f19, f15
csrrs x18, fflags, x0
c.addi x17, -23
fcvt.h.wu f18, x18, rtz
csrrs x20, fflags, x0
li x11, 2415919072
amoswap.d.aq x15, x18, (x11)
sext.h x19, x13
li x2, 2415919038
c.ldsp x14, 0(sp)
fadd.s f18, f19, f19, dyn
csrrs x14, fflags, x0
fadd.d f13, f19, f17, rne
csrrs x13, fflags, x0
lui x13, 700416
srliw x17, x18, 31
srl x13, x20, x19
sltu x17, x16, x13
feq.d x18, f16, f14
csrrs x14, fflags, x0
fdiv.s f16, f17, f15, rtz
csrrs x20, fflags, x0
czero.eqz x16, x18, x18
srl x18, x18, x19
li x11, 2415919034
amoadd.d.aq x16, x15, (x11)
cpop x18, x16
fcvt.wu.d x18, f15, dyn
csrrs x18, fflags, x0
fmul.d f20, f15, f16, rmm
csrrs x13, fflags, x0
fadd.d f18, f19, f15, dyn
csrrs x14, fflags, x0
li x8, 2415919064
c.ld x13, 0(x8)
fdiv.s f19, f20, f17, rdn
csrrs x19, fflags, x0
ctzw x16, x13
fnmadd.s f19, f14, f17, f19, dyn
csrrs x15, fflags, x0
fclass.d x14, f17
csrrs x20, fflags, x0
fsub.s f20, f14, f19, rne
csrrs x13, fflags, x0
li x8, 2415919071
amoxor.w.aqrl x14, x16, (x8)
fsqrt.h f17, f15, dyn
csrrs x19, fflags, x0
fsgnj.s f17, f15, f17
csrrs x17, fflags, x0
li x11, 2415919048
lbu x20, 9(x11)
fence.i
c.addiw x14, -21
czero.eqz x20, x19, x14
fcvt.h.wu f19, x16, dyn
csrrs x15, fflags, x0
fence.i
sltu x16, x13, x20
li x10, 2415919035
amomaxu.w x17, x19, (x10)
fcvt.s.h f20, f14
csrrs x17, fflags, x0

exit:
    li t0, 1 # report success
    la t1, tohost
    sd t0, 0(t1)
1:
    j 1b


.align 2
switch_to_s_mode:
    # Set up the page table: identity-map the 1GB region containing 0x80000000
    la t0, pgtbl
    li t1, (0x80000 << 10) | 0xCF # PPN=0x80000, full permissions
    sd t1, 16(t0)

    # Write satp to enable paging (Sv39)
    li t2, 8
    slli t2, t2, 60
    srli t1, t0, 12
    or t2, t2, t1
    csrw satp, t2
    sfence.vma

    # Set MPP to S-mode (1) and prepare for mret
    li t0, ~(3 << 11)
    csrr t1, mstatus
    and t1, t1, t0
    li t2, (1 << 11)
    or t1, t1, t2
    csrw mstatus, t1

    csrw mepc, ra
    mret

.align 2
exit_s_mode:
    ecall # Trigger Environment Call (Cause 9)
    ret # Handler will actually adjust mepc to skip this spot


    .align 2
trap_handler:
    csrr t0, mepc # faulting PC
    csrr t1, mcause # trap cause
    csrr t4, mtval

    # Extract the exception code
    slli t5, t1, 1
    srli t1, t5, 1

    # --- Added: handle requests to return to M-mode ---
    li t3, 9 # Ecall from S-mode
    bne t1, t3, check_page_fault
    # If it is an ecall, set MPP so mret returns to M-mode
    li t2, 3 << 11
    csrs mstatus, t2 # Set MPP to 3 (Machine)
    li t2, 4 # Skip the ecall instruction
    j update_mepc

check_page_fault:
    # --- Added: detect page faults (13 or 15) ---
    li t3, 13
    beq t1, t3, handle_as_normal_fault
    li t3, 15
    beq t1, t3, handle_as_normal_fault

    # If it's neither a page fault nor an ecall, fall back to the original logic
    j original_logic

handle_as_normal_fault:
    # Page faults still need instruction-length decoding and skipping; reuse the original logic
    j original_logic

original_logic:
    # Original logic: decode instruction length
    li t2, 2
    li t3, 2
    beq t1, t3, illegal_len
    li t3, 1
    beq t1, t3, instr_fault_len
    li t3, 12
    beq t1, t3, instr_fault_len

    lhu t4, 0(t0)
    j decode_length

other_len:
    lhu t4, 0(t0)
    j decode_length

illegal_len:
    beqz t4, other_len
    j decode_length

instr_fault_len:
    li t2, 4
    j update_mepc

decode_length:
    andi t4, t4, 3
    li t3, 3
    bne t4, t3, compressed_len
    li t2, 4
    j update_mepc

compressed_len:
    li t2, 2

update_mepc:
    add t0, t0, t2
    csrw mepc, t0
    csrw mcause, x0
    csrw mtval, x0
    mret

    .section .data
    .balign 4096
pgtbl:
    .zero 4096


    .section .tohost,"aw",@progbits
    .align 6
    .globl tohost
    .globl fromhost
tohost:
    .dword 0
fromhost:
    .dword 0
