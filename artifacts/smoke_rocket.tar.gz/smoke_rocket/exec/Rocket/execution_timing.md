# Execution Timing

| Implementation | Duration (s) |
| --- | --- |
| Rocket | 0.716 |
